package ui;

import auth.Login;
import db.DBConnection;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class Menu extends JFrame {
    private static final long serialVersionUID = 1L;
    private static final Color NAVY        = new Color(32, 96, 61);
    private static final Color ACTIVE      = new Color(133, 187, 101);
    private static final Color ACTIVE_DARK = new Color(102, 187, 106);
    private static final Color HEADER_BLUE = new Color(232, 245, 233);
    private static final Color HEADER_LINE = new Color(210, 230, 205);
    private static final Color ROW_BLUE    = new Color(241, 248, 233);
    private static final Color BG          = new Color(248, 249, 250);
    private static final Color INK         = new Color(27, 94, 32);
    private static final Color MUTED       = new Color(51, 105, 30);
    private static final Color BORDER      = new Color(220, 232, 214);
    private static final Color DANGER      = new Color(190, 45, 55);
    private static final Color GOOD        = new Color(35, 135, 80);
    private static final String LOGO       = "knhs_logo.png";
    private static final String CARMEN_LOGO= "carmen_logo.png";

    private JTextField    txtUsername;
    private JPasswordField txtPassword;
    private JPanel        mainPanel;
    private CardLayout    cards;
    private transient final Map<String, JButton> navButtons = new LinkedHashMap<>();

    @SuppressWarnings("this-escape")
    public Menu() {
        applyFontDefaults();
        migrateDatabaseSchema();
        seedRequiredUsers();
        buildLogin();
    }

    // =========================================================
    //  SCHEMA MIGRATION
    // =========================================================

    private void migrateDatabaseSchema() {
        try (Connection conn = DBConnection.getConnection()) {
            // users table columns
            if (!hasColumn(conn, "users", "full_name"))
                executeUpdate(conn, "ALTER TABLE users ADD COLUMN full_name VARCHAR(150) NOT NULL DEFAULT '' AFTER user_id");
            if (!hasColumn(conn, "users", "account_status"))
                executeUpdate(conn, "ALTER TABLE users ADD COLUMN account_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' AFTER teacher_id");
            if (!hasColumn(conn, "users", "admin_permission"))
                executeUpdate(conn, "ALTER TABLE users ADD COLUMN admin_permission VARCHAR(20) NOT NULL DEFAULT 'AUTHORIZED' AFTER account_status");
            if (!hasColumn(conn, "users", "profile_picture"))
                executeUpdate(conn, "ALTER TABLE users ADD COLUMN profile_picture LONGBLOB AFTER admin_permission");
            if (!hasColumn(conn, "users", "user_type"))
                executeUpdate(conn, "ALTER TABLE users ADD COLUMN user_type VARCHAR(20) NULL AFTER profile_picture");
            // student LRN columns
            if (!hasColumn(conn, "jhs_students", "student_no"))
                executeUpdate(conn, "ALTER TABLE jhs_students ADD COLUMN student_no VARCHAR(50) NOT NULL DEFAULT '' AFTER student_id");
            if (!hasColumn(conn, "jhs_students", "LRN"))
                executeUpdate(conn, "ALTER TABLE jhs_students ADD COLUMN LRN VARCHAR(12) NOT NULL DEFAULT '' AFTER student_id");
            if (!hasColumn(conn, "shs_students", "student_no"))
                executeUpdate(conn, "ALTER TABLE shs_students ADD COLUMN student_no VARCHAR(50) NOT NULL DEFAULT '' AFTER student_id");
            if (!hasColumn(conn, "shs_students", "LRN"))
                executeUpdate(conn, "ALTER TABLE shs_students ADD COLUMN LRN VARCHAR(12) NOT NULL DEFAULT '' AFTER student_id");
            // section room_number
            if (!hasColumn(conn, "jhs_sections", "room_number"))
                executeUpdate(conn, "ALTER TABLE jhs_sections ADD COLUMN room_number VARCHAR(50) NOT NULL DEFAULT '' AFTER adviser_name");
            if (!hasColumn(conn, "shs_sections", "room_number"))
                executeUpdate(conn, "ALTER TABLE shs_sections ADD COLUMN room_number VARCHAR(50) NOT NULL DEFAULT '' AFTER adviser_name");
            // enrollment LRN columns
            if (hasColumn(conn, "jhs_enrollment", "student_no") && !hasColumn(conn, "jhs_enrollment", "LRN"))
                executeUpdate(conn, "ALTER TABLE jhs_enrollment ADD COLUMN LRN VARCHAR(12) NOT NULL DEFAULT '' AFTER student_no");
            if (!hasColumn(conn, "jhs_enrollment", "semester"))
                executeUpdate(conn, "ALTER TABLE jhs_enrollment ADD COLUMN semester VARCHAR(20) NOT NULL DEFAULT '1st Semester' AFTER school_year");
            if (!hasColumn(conn, "jhs_enrollment", "sy_id"))
                executeUpdate(conn, "ALTER TABLE jhs_enrollment ADD COLUMN sy_id INT NOT NULL DEFAULT 1 AFTER student_id");
            if (hasColumn(conn, "shs_enrollment", "student_no") && !hasColumn(conn, "shs_enrollment", "LRN"))
                executeUpdate(conn, "ALTER TABLE shs_enrollment ADD COLUMN LRN VARCHAR(12) NOT NULL DEFAULT '' AFTER student_no");
            if (!hasColumn(conn, "shs_enrollment", "sy_id"))
                executeUpdate(conn, "ALTER TABLE shs_enrollment ADD COLUMN sy_id INT NOT NULL DEFAULT 1 AFTER student_id");
            executeUpdate(conn, "UPDATE jhs_enrollment e JOIN jhs_students s ON s.student_id=e.student_id SET e.LRN=s.LRN WHERE e.LRN='' OR e.LRN IS NULL");
            executeUpdate(conn, "UPDATE shs_enrollment e JOIN shs_students s ON s.student_id=e.student_id SET e.LRN=s.LRN WHERE e.LRN='' OR e.LRN IS NULL");
            // fill defaults
            executeUpdate(conn, "UPDATE users SET admin_permission='SUPER_ADMIN' WHERE user_id=1 AND (admin_permission='' OR admin_permission IS NULL OR admin_permission IN ('PENDING','AUTHORIZED'))");
            executeUpdate(conn, "UPDATE users SET full_name=COALESCE(NULLIF(full_name,''),username) WHERE full_name='' OR full_name IS NULL");
        } catch (SQLException ignored) {}
    }

    private static void executeUpdate(Connection conn, String sql) throws SQLException {
        try (Statement stmt = conn.createStatement()) { stmt.executeUpdate(sql); }
    }

    // =========================================================
    //  LOGIN UI
    // =========================================================

    private void buildLogin() {
        setTitle("KNHS Student Information & Grading System");
        setSize(520, 610);
        setMinimumSize(new Dimension(520, 610));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        getContentPane().setBackground(BG);
        setLayout(new GridBagLayout());
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { confirmExit(Menu.this); }
        });

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(28, 42, 28, 42)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx  = 0;
        gbc.fill   = GridBagConstraints.HORIZONTAL;
        gbc.weightx= 1;

        JLabel logo = logoLabel(96);
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(logo, gbc);

        gbc.gridy = 1;
        JLabel title = label("KNHS", 28, Font.BOLD, NAVY);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(title, gbc);

        gbc.gridy = 2;
        JLabel sub = label("Student Information & Grading System", 14, Font.PLAIN, MUTED);
        sub.setHorizontalAlignment(SwingConstants.CENTER);
        sub.setBorder(BorderFactory.createEmptyBorder(6, 0, 24, 0));
        panel.add(sub, gbc);

        gbc.gridy = 3; panel.add(formLabel("\uD83D\uDC64 Username"), gbc);
        gbc.gridy = 4;
        txtUsername = new JTextField(); styleInput(txtUsername);
        panel.add(txtUsername, gbc);

        gbc.gridy = 5; panel.add(formLabel("\uD83D\uDD12 Password"), gbc);
        gbc.gridy = 6;
        txtPassword = new JPasswordField();
        char passwordMask = txtPassword.getEchoChar();
        txtPassword.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 8));
        txtPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        JPanel passwordWrap = new JPanel(new BorderLayout(0, 0));
        passwordWrap.setBackground(Color.WHITE);
        passwordWrap.setBorder(BorderFactory.createLineBorder(BORDER));
        passwordWrap.setPreferredSize(new Dimension(260, 38));
        JButton eye = iconButton(new EyeIcon(false, MUTED));
        eye.setToolTipText("Show password");
        eye.addActionListener(e -> {
            boolean show = txtPassword.getEchoChar() != 0;
            txtPassword.setEchoChar(show ? (char) 0 : passwordMask);
            eye.setIcon(new EyeIcon(show, MUTED));
            eye.setToolTipText(show ? "Hide password" : "Show password");
        });
        passwordWrap.add(txtPassword, BorderLayout.CENTER);
        passwordWrap.add(eye, BorderLayout.EAST);
        panel.add(passwordWrap, gbc);

        gbc.gridy = 7;
        JButton forgot = linkButton("Forgot your password?");
        forgot.addActionListener(e -> forgotPasswordDialog());
        panel.add(forgot, gbc);

        gbc.gridy = 8;
        JButton signUp = linkButton("Sign-Up");
        signUp.addActionListener(e -> signUpDialog());
        panel.add(signUp, gbc);

        gbc.gridy = 9; panel.add(Box.createVerticalStrut(18), gbc);
        gbc.gridy = 10;
        JButton login = button("Login", ACTIVE);
        login.setPreferredSize(new Dimension(360, 42));
        login.addActionListener(e -> loginAction());
        panel.add(login, gbc);

        gbc.gridy = 11;
        JLabel footer = label("KATIPUNAN NATIONAL HIGH SCHOOL", 12, Font.PLAIN, NAVY);
        footer.setHorizontalAlignment(SwingConstants.CENTER);
        footer.setBorder(BorderFactory.createEmptyBorder(18, 0, 0, 0));
        panel.add(footer, gbc);

        add(panel, new GridBagConstraints());
        getRootPane().setDefaultButton(login);
        SwingUtilities.invokeLater(() -> txtUsername.requestFocusInWindow());
    }

    private void loginAction() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        if (username.isEmpty() || password.isEmpty()) {
            warn(this, "Please enter username and password.");
            return;
        }
        Login login = new Login();
        if (!login.authenticate(username, password)) {
            error(this, login.getFailureMessage());
            return;
        }
        dispose();
        buildDashboard(login);
    }

    // =========================================================
    //  FORGOT PASSWORD
    // =========================================================

    private void forgotPasswordDialog() {
        JTextField email = new JTextField();
        JPanel emailForm = smallForm(new String[]{"Email Address"}, new JComponent[]{email});
        if (JOptionPane.showConfirmDialog(this, emailForm, "Forgot Password", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
            return;
        try (Connection conn = DBConnection.getConnection()) {
            int userId = findUserIdByEmail(conn, email.getText().trim());
            if (userId == 0) { warn(this, "No account found for that email address."); return; }
            JPasswordField next    = new JPasswordField();
            JPasswordField confirm = new JPasswordField();
            JPanel passwordForm = smallForm(new String[]{"New Password", "Confirm New Password"}, new JComponent[]{next, confirm});
            if (JOptionPane.showConfirmDialog(this, passwordForm, "Reset Password", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
                return;
            String newPassword     = new String(next.getPassword()).trim();
            String confirmPassword = new String(confirm.getPassword()).trim();
            if (newPassword.isEmpty())              { warn(this, "Please enter a new password."); return; }
            if (!newPassword.equals(confirmPassword)) { warn(this, "Passwords do not match."); return; }
            try (PreparedStatement pst = conn.prepareStatement("UPDATE users SET password=? WHERE user_id=?")) {
                pst.setString(1, hashPassword(newPassword));
                pst.setInt(2, userId);
                pst.executeUpdate();
            }
            info(this, "Password updated successfully! You can login now.");
        } catch (SQLException ex) { error(this, ex.getMessage()); }
    }

    // =========================================================
    //  SIGN-UP
    //  Rules:
    //  - All fields required (Full Name, Username, Password, Email, Role, Contact)
    //  - Full Name: min 2 words, must be unique across all users
    //  - Role dropdown: blank default, options Admin/Teacher/Student
    //  - ALL new accounts → admin_permission = PENDING
    //  - Success/error messages only after clicking OK
    // =========================================================

    private void signUpDialog() {
        JTextField fldUsername = new JTextField();
        JPasswordField fldPassword = new JPasswordField();
        JTextField fldEmail = new JTextField();
        JComboBox<String> fldRole = new JComboBox<>(new String[]{"Student", "Teacher", "Regular Admin", "Super Admin"});
        fldRole.setSelectedItem(null);

        JPanel form = smallForm(
            new String[]{"Username", "Password", "Email Address", "Role"},
            new JComponent[]{fldUsername, fldPassword, fldEmail, fldRole});

        if (JOptionPane.showConfirmDialog(this, dialogScroll(form), "Sign-Up",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
            return;

        String username  = fldUsername.getText().trim();
        String password  = new String(fldPassword.getPassword()).trim();
        String email     = fldEmail.getText().trim();
        String selectedRole = fldRole.getSelectedItem() == null ? "" : fldRole.getSelectedItem().toString().trim();

        if (username.isEmpty() || password.isEmpty()
                || email.isEmpty() || selectedRole.isEmpty()) {
            error(this, "Please fill up all fields and select a Role!");
            return;
        }
        String fullName = username;
        String normalizedSignupRole = normalizeSignupRole(selectedRole);
        String roleLower = signupRoleToDbRole(normalizedSignupRole);
        String accountStatus   = "PENDING";
        String adminPermission = signupAdminPermission(normalizedSignupRole);

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                Integer teacherId = null;
                if ("teacher".equals(roleLower)) {
                    teacherId = createTeacher(conn, fullName, "", email);
                }
                int userId = createUser(conn, fullName, username, password, roleLower,
                           email, "", teacherId, accountStatus, adminPermission, null);
                if ("student".equals(roleLower)) {
                    info(this, "Your account has been successfully created and saved! Please complete the enrollment form below to finish your registration.");
                    submitInitialStudentEnrollment(conn, userId, username, email);
                    conn.commit();
                    info(this, "Enrollment form submitted successfully! All your details have been saved and sent for approval. You may login to your account once it has been activated.");
                } else {
                    conn.commit();
                    info(this, "Your account has been successfully created and saved! Please wait for authorization and approval from the administrator before logging in.");
                }
            } catch (SQLException ex) {
                conn.rollback();
                error(this, ex.getMessage());
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException ex) { error(this, ex.getMessage()); }
    }

    // =========================================================
    //  DASHBOARD
    // =========================================================

    private void buildDashboard(Login user) {
        JFrame frame = new JFrame("KNHS - " + titleCase(user.getRole()));
        frame.setSize(1180, 720);
        frame.setMinimumSize(new Dimension(980, 620));
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { confirmExit(frame); }
        });

        cards     = new CardLayout();
        mainPanel = new JPanel(cards);
        mainPanel.setBackground(BG);

        JPanel shell = new JPanel(new BorderLayout());
        shell.add(sidebar(user, frame), BorderLayout.WEST);
        shell.add(topAndMain(user),     BorderLayout.CENTER);
        frame.setContentPane(shell);

        registerPages(user);
        showPage("Dashboard");
        frame.setVisible(true);
    }

    private JPanel topAndMain(Login user) {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setBackground(BG);
        JTextField search = new PromptField("Search here...");
        search.setToolTipText("Search here...");
        styleInput(search);
        JButton find = button("\uD83D\uDD0D Search", ACTIVE);
        find.addActionListener(e -> globalSearch(search.getText()));

        JPanel top = new JPanel(new BorderLayout(10, 0));
        top.setBackground(HEADER_BLUE);
        top.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, HEADER_LINE),
            BorderFactory.createEmptyBorder(14, 18, 14, 18)));
        JLabel who = label(titleCase(user.getRole()) + " - " + user.getUserName(), 14, Font.BOLD, INK);

        JPanel searchPanel = new JPanel(new BorderLayout(6, 0));
        searchPanel.setOpaque(false);
        searchPanel.setPreferredSize(new Dimension(520, 40));
        JLabel searchIcon = label("\uD83D\uDD0D", 14, Font.PLAIN, MUTED);
        searchIcon.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 4));
        JPanel searchWrap = new JPanel(new BorderLayout(4, 0));
        searchWrap.setOpaque(false);
        searchWrap.add(searchIcon, BorderLayout.WEST);
        searchWrap.add(search, BorderLayout.CENTER);
        JPanel searchButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        searchButtons.setOpaque(false);
        searchButtons.add(find);
        // Profile Account button available to ALL users (not just admin)
        JButton profileBtn = button("\u25BC Profile Account", new Color(144, 238, 144));
        profileBtn.setFont(profileBtn.getFont().deriveFont(Font.PLAIN));
        profileBtn.addActionListener(e -> profileAccountPopup(user).show(profileBtn, 0, profileBtn.getHeight()));
        searchButtons.add(profileBtn);
        searchPanel.add(searchWrap,   BorderLayout.CENTER);
        searchPanel.add(searchButtons, BorderLayout.EAST);
        top.add(who,         BorderLayout.WEST);
        top.add(searchPanel, BorderLayout.EAST);

        wrap.add(top,       BorderLayout.NORTH);
        wrap.add(mainPanel, BorderLayout.CENTER);
        SwingUtilities.invokeLater(() -> search.requestFocusInWindow());
        return wrap;
    }

    private JPopupMenu profileAccountPopup(Login user) {
        JPopupMenu popup = new JPopupMenu();
        popup.setBorder(BorderFactory.createLineBorder(BORDER));
        JPanel content = new JPanel(new GridBagLayout());
        content.setBackground(Color.WHITE);
        content.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(6, 6, 6, 6);

        Map<String, String> profile = loadUserProfile(user);
        content.add(label(profile.getOrDefault("username", user.getUserName()), 14, Font.BOLD, INK), gbc);
        gbc.gridy++;

        // Profile picture label — load from DB if stored
        JLabel picture = new JLabel("No Profile Picture", SwingConstants.CENTER);
        picture.setBorder(BorderFactory.createLineBorder(MUTED));
        picture.setPreferredSize(new Dimension(150, 150));
        picture.setVerticalAlignment(SwingConstants.CENTER);
        // Try to load stored picture
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(
                 "SELECT profile_picture FROM users WHERE user_id=?")) {
            pst.setInt(1, user.getUserId());
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    byte[] imgBytes = rs.getBytes("profile_picture");
                    if (imgBytes != null && imgBytes.length > 0) {
                        picture.setIcon(profileIcon(imgBytes, 150));
                        picture.setText("");
                    }
                }
            }
        } catch (SQLException ignored) {}
        content.add(picture, gbc);
        gbc.gridy++;

        // TAKE PHOTO / OPEN CAMERA — using Java Robot/AWT capture workaround
        JButton takePicture = button("\uD83D\uDCF7 Take Photo / Open Camera", ACTIVE);
        takePicture.setFont(takePicture.getFont().deriveFont(Font.PLAIN));
        takePicture.addActionListener(e -> openSystemCameraIfAvailable(user, picture, popup));
        content.add(takePicture, gbc);
        gbc.gridy++;

        // BROWSE FILES / UPLOAD IMAGE
        JButton upload = button("\uD83D\uDCC1 Browse Files / Upload Image", ACTIVE);
        upload.setFont(upload.getFont().deriveFont(Font.PLAIN));
        upload.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Upload Profile Picture");
            chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "Image files", "jpg", "jpeg", "png", "gif", "bmp"));
            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                uploadProfilePictureWithConfirmation(user, picture, popup, chooser.getSelectedFile());
            }
        });
        content.add(upload, gbc);
        gbc.gridy++;
        content.add(label("Full Name: "    + profile.getOrDefault("full_name", "-"), 12, Font.PLAIN, INK), gbc);
        gbc.gridy++;
        content.add(label("Email: "        + profile.getOrDefault("email", "-"),     12, Font.PLAIN, INK), gbc);
        gbc.gridy++;
        content.add(label("Role: " + titleCase(user.getRole()), 12, Font.PLAIN, INK), gbc);

        popup.add(content);
        return popup;
    }

    private void openSystemCameraIfAvailable(Login user, JLabel picture, JPopupMenu popup) {
     try {
         String os = System.getProperty("os.name").toLowerCase();
         Instant openedAt = Instant.now();
         
         if (os.contains("win")) {
             new ProcessBuilder("cmd", "/c", "start", "", "microsoft.windows.camera:").start();
         } else if (os.contains("mac")) {
             new ProcessBuilder("open", "/Applications/Photo Booth.app").start();
         } else {
             showFilePickerForImage(user, picture, popup);
             return;
         }
         javax.swing.JOptionPane.showMessageDialog(null, 
             "Camera app opened successfully!\n"
             + "Capture and save your photo.\n"
             + "The system will automatically look for your latest photo.", 
             "Camera Opened", 
             javax.swing.JOptionPane.INFORMATION_MESSAGE);
         waitForRecentCameraPhoto(user, picture, popup, openedAt);
     } catch (Exception e) {
         javax.swing.JOptionPane.showMessageDialog(null, 
             "Camera could not be opened.\nPlease use the 'Browse Files' option instead.", 
             "Camera Error", 
             javax.swing.JOptionPane.WARNING_MESSAGE);
         
         showFilePickerForImage(user, picture, popup);
      }
  }

    private void waitForRecentCameraPhoto(Login user, JLabel picture, JPopupMenu popup, Instant openedAt) {
        final int[] attempts = {0};
        Timer timer = new Timer(2000, null);
        timer.addActionListener(e -> {
            attempts[0]++;
            File latestPhoto = findLatestCapturedPhoto(openedAt);
            if (latestPhoto != null) {
                timer.stop();
                promptUseCapturedPhoto(user, picture, popup, latestPhoto);
                return;
            }
            if (attempts[0] >= 60) {
                timer.stop();
            }
        });
        timer.setInitialDelay(2500);
        timer.start();
    }

    private void promptUseCapturedPhoto(Login user, JLabel picture, JPopupMenu popup, File file) {
        if (file == null || !file.isFile()) return;
        try {
            byte[] imgBytes = Files.readAllBytes(file.toPath());
            JLabel preview = new JLabel(profileIcon(imgBytes, 180));
            preview.setHorizontalAlignment(SwingConstants.CENTER);
            JPanel confirmPanel = new JPanel(new BorderLayout(8, 8));
            confirmPanel.setBackground(Color.WHITE);
            confirmPanel.add(preview, BorderLayout.CENTER);
            confirmPanel.add(label("Do you want this photo to be your profile picture?", 12, Font.PLAIN, INK), BorderLayout.SOUTH);
            int choice = JOptionPane.showConfirmDialog(this, confirmPanel,
                "Confirm Captured Photo", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (choice == JOptionPane.YES_OPTION) {
                saveProfilePicture(user.getUserId(), imgBytes);
                picture.setIcon(profileIcon(imgBytes, 150));
                picture.setText("");
                popup.revalidate();
                popup.repaint();
                info(this, "Profile picture updated successfully.");
            }
        } catch (IOException ex) {
            error(this, "Failed to read captured image: " + ex.getMessage());
        } catch (IllegalArgumentException ex) {
            error(this, "The captured photo is not a valid image.");
        }
    }

    private File findLatestCapturedPhoto(Instant openedAt) {
        File latest = null;
        long latestTime = Long.MIN_VALUE;
        for (Path folder : cameraPhotoFolders()) {
            if (!Files.isDirectory(folder)) continue;
            try (java.util.stream.Stream<Path> stream = Files.list(folder)) {
                for (Path path : (Iterable<Path>) stream::iterator) {
                    if (!Files.isRegularFile(path) || !isImageFile(path)) continue;
                    long modified = Files.getLastModifiedTime(path).toMillis();
                    if (modified < openedAt.toEpochMilli()) continue;
                    if (modified > latestTime) {
                        latestTime = modified;
                        latest = path.toFile();
                    }
                }
            } catch (IOException ignored) {}
        }
        return latest;
    }

    private static List<Path> cameraPhotoFolders() {
        String home = System.getProperty("user.home", "");
        return Arrays.asList(
            Paths.get(home, "Pictures", "Camera Roll"),
            Paths.get(home, "Pictures", "Saved Pictures"),
            Paths.get(home, "Pictures"),
            Paths.get(home, "OneDrive", "Pictures", "Camera Roll"),
            Paths.get(home, "OneDrive", "Pictures", "Saved Pictures"),
            Paths.get(home, "OneDrive", "Pictures"));
    }

    private static boolean isImageFile(Path path) {
        String name = path.getFileName().toString().toLowerCase();
        return name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png")
            || name.endsWith(".gif") || name.endsWith(".bmp") || name.endsWith(".webp");
    }

 private void showFilePickerForImage(Login user, JLabel picture, JPopupMenu popup) {
     javax.swing.JFileChooser fileChooser = new javax.swing.JFileChooser();
     fileChooser.setDialogTitle("Select Profile Picture");
     
     fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
         "Image Files (JPG, PNG, GIF)", "jpg", "png", "gif"));
     int result = fileChooser.showOpenDialog(null);
     if (result == javax.swing.JFileChooser.APPROVE_OPTION) {
         File selectedFile = fileChooser.getSelectedFile();
         uploadProfilePictureWithConfirmation(user, picture, popup, selectedFile);
     }
 }

    private void uploadProfilePictureWithConfirmation(Login user, JLabel picture, JPopupMenu popup, File file) {
        if (file == null) return;
        try {
            byte[] imgBytes = java.nio.file.Files.readAllBytes(file.toPath());
            JLabel preview = new JLabel(profileIcon(imgBytes, 180));
            preview.setHorizontalAlignment(SwingConstants.CENTER);
            JPanel confirmPanel = new JPanel(new BorderLayout(8, 8));
            confirmPanel.setBackground(Color.WHITE);
            confirmPanel.add(preview, BorderLayout.CENTER);
            confirmPanel.add(label("Are you sure you want to upload this photo in your profile picture?", 12, Font.PLAIN, INK), BorderLayout.SOUTH);
            int choice = JOptionPane.showConfirmDialog(this, confirmPanel,
                "Confirm Profile Picture", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (choice != JOptionPane.YES_OPTION) return;

            saveProfilePicture(user.getUserId(), imgBytes);
            picture.setIcon(profileIcon(imgBytes, 150));
            picture.setText("");
            popup.revalidate();
            popup.repaint();
            info(this, "Profile picture updated successfully.");
        } catch (IOException ex) {
            error(this, "Failed to read image: " + ex.getMessage());
        } catch (IllegalArgumentException ex) {
            error(this, "Please select a valid image file.");
        }
    }

    private static ImageIcon profileIcon(byte[] imgBytes, int size) {
        ImageIcon raw = new ImageIcon(imgBytes);
        if (raw.getIconWidth() <= 0 || raw.getIconHeight() <= 0)
            throw new IllegalArgumentException("Invalid image");
        double scale = Math.max(
            size / (double) raw.getIconWidth(),
            size / (double) raw.getIconHeight());
        int scaledW = Math.max(size, (int) Math.round(raw.getIconWidth() * scale));
        int scaledH = Math.max(size, (int) Math.round(raw.getIconHeight() * scale));

        java.awt.image.BufferedImage canvas = new java.awt.image.BufferedImage(
            size, size, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = canvas.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int x = (size - scaledW) / 2;
        int y = (size - scaledH) / 2;
        g2.drawImage(raw.getImage(), x, y, scaledW, scaledH, null);
        g2.dispose();
        return new ImageIcon(canvas);
    }

    /** Save profile picture bytes to users table (adds column if missing) */
    private void saveProfilePicture(int userId, byte[] imgBytes) {
        try (Connection conn = DBConnection.getConnection()) {
            if (!hasColumn(conn, "users", "profile_picture")) {
                executeUpdate(conn, "ALTER TABLE users ADD COLUMN profile_picture LONGBLOB");
            }
            try (PreparedStatement pst = conn.prepareStatement(
                    "UPDATE users SET profile_picture=? WHERE user_id=?")) {
                pst.setBytes(1, imgBytes);
                pst.setInt(2, userId);
                pst.executeUpdate();
            }
        } catch (SQLException ex) {
            error(null, "Could not save picture: " + ex.getMessage());
        }
    }

    private Map<String, String> loadUserProfile(Login user) {
        Map<String, String> profile = new LinkedHashMap<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(
                 "SELECT full_name, username, email FROM users WHERE user_id=?")) {
            pst.setInt(1, user.getUserId());
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    profile.put("full_name", safe(rs.getString("full_name")));
                    profile.put("username",  safe(rs.getString("username")));
                    profile.put("email",     safe(rs.getString("email")));
                }
            }
        } catch (SQLException ignored) {}
        return profile;
    }

    // =========================================================
    //  SIDEBAR / NAV
    // =========================================================

    private JPanel sidebar(Login user, JFrame frame) {
        JPanel nav = new JPanel();
        nav.setLayout(new BoxLayout(nav, BoxLayout.Y_AXIS));
        nav.setPreferredSize(new Dimension(236, 1));
        nav.setBackground(NAVY);
        nav.setBorder(BorderFactory.createEmptyBorder(28, 20, 18, 20));
        navButtons.clear();

        JPanel brand = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        brand.setOpaque(false);
        brand.setMaximumSize(new Dimension(196, 46));
        brand.add(logoLabel(36));
        brand.add(label("KNHS", 24, Font.BOLD, Color.WHITE));
        nav.add(brand);
        nav.add(Box.createVerticalStrut(24));

        for (String item : menuItems(user)) {
            JButton b = navButton(item);
            b.addActionListener(e -> showPage(item));
            navButtons.put(item, b);
            nav.add(b);
            nav.add(Box.createVerticalStrut(8));
        }
        nav.add(Box.createVerticalGlue());
        JButton logout = navButton("Logout");
        logout.addActionListener(e -> { frame.dispose(); new Menu().setVisible(true); });
        nav.add(logout);
        return nav;
    }

    private void registerPages(Login user) {
        String role = user.getRole() == null ? "" : user.getRole().toLowerCase();
        mainPanel.add(moduleScroll(homePage(user)), "Dashboard");
        if ("admin".equals(role)) {
            mainPanel.add(moduleScroll(userManagementPage(user)),         "User Management");
            mainPanel.add(moduleScroll(schoolManagementPage(user)),       "School Management");
            mainPanel.add(moduleScroll(subjectsAdminPage(user)),          "Subject Management");
            mainPanel.add(moduleScroll(sectionManagementPage(user)),      "Section Management");
            mainPanel.add(moduleScroll(tabbed("Enrollment Management",
                crudPage(TABLES.get("jhs_enrollment"), null, true, user),
                crudPage(TABLES.get("shs_enrollment"), null, true, user))), "Enrollment Management");
            mainPanel.add(moduleScroll(corManagementPage(user, role)),    "COR Management");
            mainPanel.add(moduleScroll(reportCardManagementPage(user, true)), "Report Card Management");
            mainPanel.add(moduleScroll(accountPage(user)),                "Settings");
        } else if ("teacher".equals(role)) {
            mainPanel.add(moduleScroll(teacherClassesPage(user)),         "My Classes");
            mainPanel.add(moduleScroll(teacherSubjectsPage(user)),        "My Subjects");
            mainPanel.add(moduleScroll(corManagementPage(user, role)),    "COR");
            mainPanel.add(moduleScroll(reportCardManagementPage(user, false)), "Report Card");
        } else {
            if (isEnrollmentOpen())
                mainPanel.add(moduleScroll(studentEnrollmentPage(user)),  "Enrollment");
            mainPanel.add(moduleScroll(corManagementPage(user, role)),    "My COR");
            mainPanel.add(moduleScroll(studentReportCardPage(user)),      "My Report Card");
            mainPanel.add(moduleScroll(accountPage(user)),                "Personal Information");
        }
    }

    // =========================================================
    //  HOME / DASHBOARD
    // =========================================================

    private JPanel homePage(Login user) {
        JPanel page = page("Dashboard");
        JPanel cardsPanel = new JPanel(new GridLayout(1, 4, 14, 14));
        cardsPanel.setOpaque(false);
        String role = user.getRole() == null ? "" : user.getRole().toLowerCase();
        if ("admin".equals(role)) {
            cardsPanel.add(stat("Total Students",     scalar("SELECT (SELECT COUNT(*) FROM jhs_students)+(SELECT COUNT(*) FROM shs_students)")));
            cardsPanel.add(stat("Active Sections",    scalar("SELECT (SELECT COUNT(*) FROM jhs_sections)+(SELECT COUNT(*) FROM shs_sections)")));
            cardsPanel.add(stat("Total Teachers",     scalar("SELECT COUNT(*) FROM teachers")));
            cardsPanel.add(stat("Average Performance",averageAll()));
        } else if ("teacher".equals(role)) {
            cardsPanel.add(stat("My Students", scalar("SELECT COUNT(DISTINCT s.student_id) FROM jhs_students s JOIN jhs_subjects_offerings o ON o.section_id=s.section_id WHERE o.teacher_id=" + user.getTeacherId())));
            cardsPanel.add(stat("My Subjects", scalar("SELECT COUNT(*) FROM jhs_subjects_offerings WHERE teacher_id=" + user.getTeacherId())));
            cardsPanel.add(stat("My Sections", scalar("SELECT COUNT(DISTINCT section_id) FROM jhs_subjects_offerings WHERE teacher_id=" + user.getTeacherId())));
            cardsPanel.add(stat("Class Average", averageTeacher(user.getTeacherId())));
        } else {
            String actualLrn = studentLrnForUser(user.getUserId());
            String lrn = sql(actualLrn);
            cardsPanel.add(stat("My Profile",       actualLrn.isBlank() ? user.getUserName() : actualLrn));
            cardsPanel.add(stat("Enrollment Status", scalarText("SELECT status FROM jhs_students WHERE LRN='" + lrn + "' UNION SELECT status FROM shs_students WHERE LRN='" + lrn + "' LIMIT 1")));
            cardsPanel.add(stat("Current Average",  averageStudentByLrn(actualLrn)));
            cardsPanel.add(stat("Subjects Taken",   scalar("SELECT COUNT(*) FROM jhs_grades g JOIN jhs_students s ON s.student_id=g.student_id WHERE s.LRN='" + lrn + "' UNION ALL SELECT COUNT(*) FROM shs_grades g JOIN shs_students s ON s.student_id=g.student_id WHERE s.LRN='" + lrn + "'")));
        }
        page.add(cardsPanel,           BorderLayout.NORTH);
        page.add(new BarChartPanel(role), BorderLayout.CENTER);
        page.add(recentActivityPanel(role, user), BorderLayout.EAST);
        return page;
    }

    private JPanel recentActivityPanel(String role, Login user) {
        JPanel panel = page("Recent Activity");
        JTable table = new JTable();
        loadTable(table, recentActivitySql(role, user));
        panel.add(tableScroll(table), BorderLayout.CENTER);
        if ("admin".equalsIgnoreCase(role))
            new Timer(8000, e -> loadTable(table, recentActivitySql(role, user))).start();
        return panel;
    }

    // =========================================================
    //  USER MANAGEMENT PAGE
    //  - Sorted: Super Admin, Admins, Teachers, Students
    //  - Columns: Role, Full Name, Email, Contact No, Teacher ID,
    //             Account Status, Admin Permission
    //  - Super Admin (id=1) cannot be deleted
    //  - Regular Admin cannot edit/delete other admins or super admin
    //  - Add button guard: if row selected → show warning
    // =========================================================

    private JPanel userManagementPage(Login user) {
        boolean isSuperAdmin = user.isSuperAdmin();

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JPanel top = new JPanel(new BorderLayout(8, 8));
        top.setOpaque(false);
        top.add(label("User Management", 16, Font.BOLD, INK), BorderLayout.NORTH);
        JLabel hierarchyInfo = label("", 12, Font.PLAIN, MUTED);
        hierarchyInfo.setVerticalAlignment(SwingConstants.TOP);
        top.add(hierarchyInfo, BorderLayout.CENTER);
        panel.add(top, BorderLayout.NORTH);

        JTable table = new JTable();
        // Sorted: super admin first, then admins, then teachers, then students
        String userSql = "SELECT " +
            "CASE WHEN role='admin' AND (admin_permission='SUPER_ADMIN' OR user_id=1) THEN 1 " +
            "WHEN role='admin' THEN 2 WHEN role='teacher' THEN 3 WHEN role='student' THEN 4 ELSE 5 END hierarchy_sort, " +
            "CASE WHEN role='admin' AND (admin_permission='SUPER_ADMIN' OR user_id=1) THEN '1 - Super Admin' " +
            "WHEN role='admin' THEN '2 - Admin' WHEN role='teacher' THEN '3 - Teacher' " +
            "WHEN role='student' THEN '4 - Student' ELSE '5 - Other' END AS 'Hierarchy', " +
            "user_id, role AS 'Role', full_name AS 'Full Name', email AS 'Email', " +
            "contact_no AS 'Contact No', teacher_id AS 'Teacher ID', " +
            "account_status AS 'Account Status', admin_permission AS 'Admin Permission' " +
            "FROM users ORDER BY hierarchy_sort, user_id";
        loadTable(table, userSql);
        updateHierarchyLabel(hierarchyInfo);
        // Hide the sort helper column
        hideColumn(table, 0);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);

        JButton add = button("\u2795 Add User", ACTIVE);
        JButton edit = button("\u270F\uFE0F Edit User", ACTIVE);
        JButton del = button("\uD83D\uDDD1\uFE0F Delete User", DANGER);
        JButton refresh = button("\uD83D\uDD04 Refresh", ACTIVE);
        boolean canManageUsers = user.isSuperAdmin();

        add.addActionListener(e -> {
            if (table.getSelectedRow() >= 0) {
                warn(panel, "Please unselect any user first before adding a new one.");
                return;
            }
            addUserDialog(user, table, userSql);
            updateHierarchyLabel(hierarchyInfo);
        });

        edit.addActionListener(e -> {
            editUserDialog(user, table, userSql, isSuperAdmin);
            updateHierarchyLabel(hierarchyInfo);
        });
        del.addActionListener(e -> {
            deleteUserRecord(user, table, userSql, isSuperAdmin);
            updateHierarchyLabel(hierarchyInfo);
        });
        refresh.addActionListener(e -> {
            loadTable(table, userSql);
            updateHierarchyLabel(hierarchyInfo);
        });

        if (canManageUsers) actions.add(add);
        if (canManageUsers) actions.add(edit);
        if (canManageUsers) actions.add(del);
        actions.add(refresh);

        panel.add(tableScroll(table), BorderLayout.CENTER);
        panel.add(actions,            BorderLayout.SOUTH);
        return panel;
    }

    // =========================================================
    //  ADD USER DIALOG
    //  - Full Name: 2+ words, unique
    //  - Role: blank default, Admin/Teacher/Student
    //  - Admin Permission: PENDING default, PENDING/AUTHORIZED
    //  - Teacher ID: shown for all but hidden after role logic in save
    // =========================================================

    private void addUserDialog(Login currentUser, JTable table, String refreshSql) {
        JTextField     fldFullName  = new JTextField();
        JTextField     fldUsername  = new JTextField();
        JPasswordField fldPassword  = new JPasswordField();
        JTextField     fldEmail     = new JTextField();
        JTextField     fldContact   = new JTextField();
        JComboBox<String> fldRole   = new JComboBox<>(allowedRoleOptions(currentUser));
        fldRole.setSelectedItem(null);
        JComboBox<String> fldPerm   = new JComboBox<>(new String[]{"PENDING", "AUTHORIZED"});
        fldPerm.setSelectedIndex(0);  // PENDING default, no blank
        JComboBox<String> fldStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE", "PENDING"});
        fldStatus.setSelectedItem("PENDING");
        JTextField     fldTeacherId = new JTextField();

        JPanel form = smallForm(
            new String[]{"Full Name", "Username", "Password", "Email", "Role",
                         "Contact No.", "Admin Permission", "Account Status", "Teacher ID (Optional)"},
            new JComponent[]{fldFullName, fldUsername, fldPassword, fldEmail, fldRole,
                             fldContact, fldPerm, fldStatus, fldTeacherId});

        if (JOptionPane.showConfirmDialog(this, dialogScroll(form), "Add User",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
            return;

        String fullName = fldFullName.getText().trim();
        String username = fldUsername.getText().trim();
        String password = new String(fldPassword.getPassword()).trim();
        String email    = fldEmail.getText().trim();
        String contact  = fldContact.getText().trim();
        String selRole  = fldRole.getSelectedItem() == null ? "" : fldRole.getSelectedItem().toString().trim();
        String perm     = fldPerm.getSelectedItem() == null ? "PENDING" : fldPerm.getSelectedItem().toString();
        String status   = fldStatus.getSelectedItem() == null ? "PENDING" : fldStatus.getSelectedItem().toString();
        String teacherIdTxt = fldTeacherId.getText().trim();

        if (fullName.isEmpty() || username.isEmpty() || password.isEmpty()
                || email.isEmpty() || contact.isEmpty() || selRole.isEmpty()) {
            error(this, "Please fill up all fields and select a Role!");
            return;
        }
        if (fullName.split("\\s+").length < 2) {
            error(this, "Full Name must include at least First Name and Last Name.");
            return;
        }
        String normalizedRole = selRole.toLowerCase();
        if (!canManageUserRole(currentUser, normalizedRole)) {
            error(this, authorizationMessageForRole(currentUser, normalizedRole));
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            if (fullNameExists(conn, fullName, 0)) {
                error(this, "That Full Name is already taken.");
                return;
            }
            Integer teacherId = null;
            if (!teacherIdTxt.isEmpty()) {
                try { teacherId = Integer.parseInt(teacherIdTxt); } catch (NumberFormatException ignored) {}
            }
            createUser(conn, fullName, username, password, normalizedRole,
                       email, contact, teacherId, status, roleScopedPermission(normalizedRole, perm), null);
            loadTable(table, refreshSql);
            info(this, "User added successfully!");
        } catch (SQLException ex) { error(this, ex.getMessage()); }
    }

    // =========================================================
    //  EDIT USER DIALOG
    //  - Role: read-only (fixed)
    //  - Full Name, Username: read-only
    //  - Editable: Email, Contact No, Admin Permission, Account Status
    //  - Teacher ID: shown only if role = teacher
    //  - Super Admin cannot be edited by regular admin
    //  - Regular admin cannot edit other admins
    // =========================================================

    private void editUserDialog(Login currentUser, JTable table, String refreshSql, boolean isSuperAdmin) {
        if (table.getSelectedRow() < 0) {
            warn(this, "Please select a user to edit.");
            return;
        }
        int modelRow = table.convertRowIndexToModel(table.getSelectedRow());
        // user_id is at column index 2 (after 2 hidden sort columns)
        int targetUserId = getIntCell(table, modelRow, 2);
        String targetRole = String.valueOf(table.getModel().getValueAt(modelRow, 3)).toLowerCase();

        // Regular admin restrictions
        if (!isSuperAdmin) {
            if (targetUserId == 1) {
                error(this, "You cannot edit the Super Admin account.");
                return;
            }
            if ("admin".equals(targetRole)) {
                error(this, "Regular admins cannot edit other admin accounts.");
                return;
            }
        }
        if (!canManageUserRole(currentUser, targetRole)) {
            error(this, authorizationMessageForRole(currentUser, targetRole));
            return;
        }

        String currentFullName = String.valueOf(table.getModel().getValueAt(modelRow, 4));
        String currentUsername = getStringCell(table, modelRow, 2); // username col after sort cols — re-query
        String currentEmail    = getStringCell(table, modelRow, 5);
        String currentContact  = getStringCell(table, modelRow, 6);
        String currentTeacherId= getStringCell(table, modelRow, 7);
        String currentStatus   = getStringCell(table, modelRow, 8);
        String currentPerm     = getStringCell(table, modelRow, 9);

        // Read-only display fields
        JLabel lblFullName = label(currentFullName, 13, Font.PLAIN, INK);
        JLabel lblRole     = label(targetRole.substring(0,1).toUpperCase() + targetRole.substring(1), 13, Font.PLAIN, INK);

        JLabel         fldEmail   = label(currentEmail, 13, Font.PLAIN, INK);
        JLabel         fldContact = label(currentContact, 13, Font.PLAIN, INK);
        JComboBox<String> fldPerm = new JComboBox<>(new String[]{"PENDING", "AUTHORIZED"});
        setComboValue(fldPerm, currentPerm);
        JComboBox<String> fldStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE", "PENDING"});
        setComboValue(fldStatus, currentStatus);

        List<String> labels = new ArrayList<>(Arrays.asList(
            "Full Name (read-only)", "Role (read-only)", "Email (read-only)", "Contact No. (read-only)", "Admin Permission", "Account Status"));
        List<JComponent> inputs = new ArrayList<>(Arrays.asList(
            lblFullName, lblRole, fldEmail, fldContact, fldPerm, fldStatus));

        JTextField fldTeacherId = null;
        if ("teacher".equals(targetRole)) {
            fldTeacherId = new JTextField(currentTeacherId);
            labels.add("Teacher ID (Optional)");
            inputs.add(fldTeacherId);
        }
        if (!"admin".equals(targetRole)) {
            int permIndex = labels.indexOf("Admin Permission");
            if (permIndex >= 0) {
                labels.remove(permIndex);
                inputs.remove(permIndex);
            }
        }

        JPanel form = smallForm(labels.toArray(new String[0]), inputs.toArray(new JComponent[0]));
        if (JOptionPane.showConfirmDialog(this, dialogScroll(form), "Edit User",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
            return;

        String newEmail   = fldEmail.getText().trim();
        String newContact = fldContact.getText().trim();
        String newPerm    = fldPerm.getSelectedItem() == null ? "PENDING" : fldPerm.getSelectedItem().toString();
        String newStatus  = fldStatus.getSelectedItem() == null ? "ACTIVE" : fldStatus.getSelectedItem().toString();

        try (Connection conn = DBConnection.getConnection()) {
            StringBuilder sql = new StringBuilder("UPDATE users SET email=?, contact_no=?, admin_permission=?, account_status=?");
            List<Object> params = new ArrayList<>(Arrays.asList(newEmail, newContact, newPerm, newStatus));

            if (fldTeacherId != null) {
                sql.append(", teacher_id=?");
                String tidTxt = fldTeacherId.getText().trim();
                if (tidTxt.isEmpty()) params.add(null);
                else { try { params.add(Integer.parseInt(tidTxt)); } catch (NumberFormatException ex) { params.add(null); } }
            }
            sql.append(" WHERE user_id=?");
            params.add(targetUserId);

            try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    if (params.get(i) == null) pst.setNull(i + 1, Types.NULL);
                    else pst.setObject(i + 1, params.get(i));
                }
                pst.executeUpdate();
            }
            syncUserStatus(conn, targetUserId);
            loadTable(table, refreshSql);
            info(this, "User updated successfully!");
        } catch (SQLException ex) { error(this, ex.getMessage()); }
    }

    // =========================================================
    //  DELETE USER
    //  - Super Admin (id=1) cannot be deleted
    //  - Regular admin cannot delete Super Admin or other admins
    // =========================================================

    private void deleteUserRecord(Login currentUser, JTable table, String refreshSql, boolean isSuperAdmin) {
        if (table.getSelectedRow() < 0) {
            warn(this, "Please select a user to delete.");
            return;
        }
        int modelRow     = table.convertRowIndexToModel(table.getSelectedRow());
        int targetUserId = getIntCell(table, modelRow, 2);
        String targetRole= String.valueOf(table.getModel().getValueAt(modelRow, 3)).toLowerCase();

        if (targetUserId == 1) {
            error(this, "You cannot delete your own account! You are the Super Admin.");
            return;
        }
        if (!isSuperAdmin) {
            if ("admin".equals(targetRole)) {
                error(this, "Regular admins cannot delete other admin accounts.");
                return;
            }
        }
        if (JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this user?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION)
            return;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM users WHERE user_id=?")) {
            pst.setInt(1, targetUserId);
            pst.executeUpdate();
            loadTable(table, refreshSql);
            info(this, "User deleted successfully!");
        } catch (SQLException ex) {
            if ("23000".equals(ex.getSQLState()) || ex.getMessage().toLowerCase().contains("foreign key"))
                error(this, "Cannot delete: User is currently in use.");
            else
                error(this, ex.getMessage());
        }
    }

    // =========================================================
    //  SCHOOL MANAGEMENT (LRN-based, no student_no)
    // =========================================================

    private JPanel schoolManagementPage(Login currentUser) {
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Teachers",    crudPage(TABLES.get("teachers"),     null, true,  currentUser));
        tabs.addTab("JHS Students",crudPage(TABLES.get("jhs_students"), null, true,  currentUser));
        tabs.addTab("SHS Students",crudPage(TABLES.get("shs_students"), null, true,  currentUser));
        JPanel page = page("School Management");
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel subjectsAdminPage(Login currentUser) {
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("JHS Subjects",  crudPage(TABLES.get("jhs_subjects"),          null, true, currentUser));
        tabs.addTab("SHS Subjects",  crudPage(TABLES.get("shs_subjects"),          null, true, currentUser));
        tabs.addTab("JHS Offerings", crudPage(TABLES.get("jhs_subjects_offerings"),null, true, currentUser));
        tabs.addTab("SHS Offerings", crudPage(TABLES.get("shs_subjects_offerings"),null, true, currentUser));
        JPanel page = page("Subject Management");
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel sectionManagementPage(Login currentUser) {
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("JHS Sections", crudPage(TABLES.get("jhs_sections"), null, true, currentUser));
        tabs.addTab("SHS Sections", crudPage(TABLES.get("shs_sections"), null, true, currentUser));
        JPanel page = page("Section Management");
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel teacherClassesPage(Login user) {
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Assigned Classes", tabbed("Assigned Classes",
            readOnlyPage("JHS Assigned Classes",
                "SELECT DISTINCT sec.section_id, sec.section_name, sec.grade_level, sec.adviser_name, sec.room_number " +
                "FROM jhs_sections sec JOIN jhs_subjects_offerings o ON o.section_id=sec.section_id WHERE o.teacher_id=" + user.getTeacherId()),
            readOnlyPage("SHS Assigned Classes",
                "SELECT DISTINCT sec.section_id, sec.section_name, sec.grade_level, sec.track, sec.strand, sec.adviser_name, sec.room_number " +
                "FROM shs_sections sec JOIN shs_subjects_offerings o ON o.section_id=sec.section_id WHERE o.teacher_id=" + user.getTeacherId())));
        tabs.addTab("Students in Class", tabbed("Students in Class",
            crudPage(TABLES.get("jhs_students"), "section_id IN (SELECT section_id FROM jhs_subjects_offerings WHERE teacher_id=" + user.getTeacherId() + ")", false, user),
            crudPage(TABLES.get("shs_students"), "section_id IN (SELECT section_id FROM shs_subjects_offerings WHERE teacher_id=" + user.getTeacherId() + ")", false, user)));
        JPanel page = page("My Classes");
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel teacherSubjectsPage(Login user) {
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("JHS Subjects", crudPage(TABLES.get("jhs_subjects_offerings"), "teacher_id=" + user.getTeacherId(), false, user));
        tabs.addTab("SHS Subjects", crudPage(TABLES.get("shs_subjects_offerings"), "teacher_id=" + user.getTeacherId(), false, user));
        JPanel page = page("My Subjects");
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel reportCardManagementPage(Login user, boolean admin) {
        JTabbedPane tabs = new JTabbedPane();
        if (admin) {
            tabs.addTab("Create Report Card",  reportCardPage(user));
            tabs.addTab("View All Report Cards", reportCardPage(user));
            tabs.addTab("Enter Grades",        adminGradingPage(user));
            tabs.addTab("Print Report Card",   reportCardPage(user));
            tabs.addTab("Generate Reports",    adminGradingPage(user));
        } else {
            tabs.addTab("Enter Grades",            gradingPage(user));
            tabs.addTab("Generate Report Card",    reportCardPage(user));
            tabs.addTab("Print Report Card",       reportCardPage(user));
            tabs.addTab("View My Class Records",   gradingPage(user));
        }
        JPanel page = page(admin ? "Report Card Management" : "Report Card");
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel studentReportCardPage(Login user) {
        String lrn = "LRN='" + sql(studentLrnForUser(user.getUserId())) + "'";
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("View Report Card",  reportCardPage(user));
        tabs.addTab("Print Report Card", reportCardPage(user));
        tabs.addTab("View Grades History", tabbed("Grades History",
            readOnlyPage("JHS Grades History",
                "SELECT g.* FROM jhs_grades g JOIN jhs_students s ON s.student_id=g.student_id WHERE s." + lrn),
            readOnlyPage("SHS Grades History",
                "SELECT g.* FROM shs_grades g JOIN shs_students s ON s.student_id=g.student_id WHERE s." + lrn)));
        JPanel page = page("My Report Card");
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel studentEnrollmentPage(Login user) {
        JPanel page = page("Enrollment");
        String lrn = sql(studentLrnForUser(user.getUserId()));
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("JHS Enrollment", readOnlyPage("JHS Enrollment",
            "SELECT e.* FROM jhs_enrollment e JOIN jhs_students s ON s.student_id=e.student_id WHERE s.LRN='" + lrn + "'"));
        tabs.addTab("SHS Enrollment", readOnlyPage("SHS Enrollment",
            "SELECT e.* FROM shs_enrollment e JOIN shs_students s ON s.student_id=e.student_id WHERE s.LRN='" + lrn + "'"));
        page.add(tabs, BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        JButton submit = button("\uD83D\uDCDD Submit Enrollment Form", ACTIVE);
        submit.addActionListener(e -> submitEnrollmentForm(user));
        actions.add(submit);
        page.add(actions, BorderLayout.SOUTH);
        return page;
    }

    private void submitEnrollmentForm(Login user) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                submitNextTermEnrollment(conn, user.getUserId());
                conn.commit();
                info(this, "Enrollment for the selected term has been submitted successfully and is pending approval.");
            } catch (SQLException ex) {
                conn.rollback();
                error(this, ex.getMessage());
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException ex) { error(this, ex.getMessage()); }
    }

    private JPanel gradingPage(Login user) {
        JPanel page = page("Grading");
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("JHS Grading", excelGradingPanel(user, true));
        tabs.addTab("SHS Grading", excelGradingPanel(user, false));
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    /**
     * Excel-style grading panel.
     * DepEd Formula: Written Works=30% | Performance Tasks=50% | Quarterly Assessment=20%
     * Period Grade = (WW_avg × 0.30) + (PT_avg × 0.50) + (QA × 0.20)
     * Final Subject Grade = (Q1+Q2+Q3+Q4)/4  or  (Prelim+Midterm+Finals)/3
     */
    private JPanel excelGradingPanel(Login user, boolean jhs) {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Formula info label
        JLabel formulaLabel = label(
            "DepEd Formula: Written Works 30% + Performance Tasks 50% + Quarterly Assessment 20% = Period Grade  |  " +
            (jhs ? "Final = (Q1+Q2+Q3+Q4)÷4" : "Final = (Prelim+Midterm+Finals)÷3"),
            11, Font.PLAIN, MUTED);
        formulaLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));
        panel.add(formulaLabel, BorderLayout.NORTH);

        // Build the grading table
        JTable table = new JTable();
        String[] jhsCols  = {"Grade ID","LRN","Student Name","Subject",
            "Q1-Written","Q1-Perf","Q1-Exam","Q1 Grade",
            "Q2-Written","Q2-Perf","Q2-Exam","Q2 Grade",
            "Q3-Written","Q3-Perf","Q3-Exam","Q3 Grade",
            "Q4-Written","Q4-Perf","Q4-Exam","Q4 Grade",
            "Final Average","Remarks"};
        String[] shsCols  = {"Grade ID","LRN","Student Name","Subject",
            "P-Written","P-Perf","P-Exam","Prelim",
            "M-Written","M-Perf","M-Exam","Midterm",
            "F-Written","F-Perf","F-Exam","Finals",
            "Final Average","Remarks"};

        String jhsGradeSql =
            "SELECT g.grade_id, s.LRN, CONCAT(s.last_name,', ',s.first_name) AS student_name, sub.subj_name, " +
            "g.q1_written, g.q1_performance, g.q1_assessment, g.first_grading, " +
            "g.q2_written, g.q2_performance, g.q2_assessment, g.second_grading, " +
            "g.q3_written, g.q3_performance, g.q3_assessment, g.third_grading, " +
            "g.q4_written, g.q4_performance, g.q4_assessment, g.fourth_grading, " +
            "g.average, g.remarks " +
            "FROM jhs_grades g " +
            "JOIN jhs_students s ON s.student_id=g.student_id " +
            "JOIN jhs_subjects sub ON sub.subj_id=g.subj_id " +
            "WHERE g.subj_id IN (SELECT subj_id FROM jhs_subjects_offerings WHERE teacher_id=" + user.getTeacherId() + ") " +
            "ORDER BY s.last_name, sub.subj_name";

        String shsGradeSql =
            "SELECT g.grade_id, s.LRN, CONCAT(s.last_name,', ',s.first_name) AS student_name, sub.subj_name, " +
            "g.p_written, g.p_performance, g.p_assessment, g.prelim, " +
            "g.m_written, g.m_performance, g.m_assessment, g.midterm, " +
            "g.f_written, g.f_performance, g.f_assessment, g.finals, " +
            "g.average, g.remarks " +
            "FROM shs_grades g " +
            "JOIN shs_students s ON s.student_id=g.student_id " +
            "JOIN shs_subjects_offerings o ON o.offering_id=g.offering_id " +
            "JOIN shs_subjects sub ON sub.subj_id=o.subj_id " +
            "WHERE o.teacher_id=" + user.getTeacherId() + " " +
            "ORDER BY s.last_name, sub.subj_name";

        String sql = jhs ? jhsGradeSql : shsGradeSql;
        String[] colNames = jhs ? jhsCols : shsCols;

        // Custom editable table model — only score columns editable
        // Locked cols: 0(GradeID),1(LRN),2(Name),3(Subject),calculated period/final/remarks
        int[] lockedCols = jhs
            ? new int[]{0,1,2,3,7,11,15,19,20,21}    // period grades, final, remarks locked
            : new int[]{0,1,2,3,7,11,15,16,17};        // period, final, remarks locked

        java.util.Set<Integer> lockedSet = new java.util.HashSet<>();
        for (int c : lockedCols) lockedSet.add(c);

        DefaultTableModel model = new DefaultTableModel(colNames, 0) {
            private static final long serialVersionUID = 1L;
            public boolean isCellEditable(int row, int col) {
                return !lockedSet.contains(col);  // only score columns editable
            }
        };

        // Load data
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            ResultSetMetaData md = rs.getMetaData();
            while (rs.next()) {
                Object[] row = new Object[md.getColumnCount()];
                for (int i = 1; i <= md.getColumnCount(); i++) row[i-1] = rs.getObject(i);
                model.addRow(row);
            }
        } catch (SQLException ex) {
            model.addRow(new Object[]{ex.getMessage()});
        }
        table.setModel(model);

        // Style — editable cells slightly different bg
        styleTable(table, null);
        table.setRowHeight(28);

        // Color locked cells grey, editable white
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;
            public Component getTableCellRendererComponent(JTable t, Object val,
                    boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                if (!sel) {
                    if (lockedSet.contains(col)) {
                        c.setBackground(new Color(240, 240, 240));
                        c.setForeground(new Color(80, 80, 80));
                    } else {
                        c.setBackground(row % 2 == 0 ? Color.WHITE : ROW_BLUE);
                        c.setForeground(INK);
                    }
                }
                setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
                setHorizontalAlignment(SwingConstants.CENTER);
                return c;
            }
        });

        // Auto-calculate when user edits a score cell
        model.addTableModelListener(e -> {
            if (e.getType() != javax.swing.event.TableModelEvent.UPDATE) return;
            int row = e.getFirstRow();
            if (row < 0 || row >= model.getRowCount()) return;
            int col = e.getColumn();
            if (lockedSet.contains(col)) return;  // ignore locked col events

            SwingUtilities.invokeLater(() -> {
                try {
                    int gradeId = Integer.parseInt(String.valueOf(model.getValueAt(row, 0)));
                    if (jhs) {
                        double q1w = dblCell(model,row,4), q1p = dblCell(model,row,5), q1e = dblCell(model,row,6);
                        double q2w = dblCell(model,row,8), q2p = dblCell(model,row,9), q2e = dblCell(model,row,10);
                        double q3w = dblCell(model,row,12), q3p = dblCell(model,row,13), q3e = dblCell(model,row,14);
                        double q4w = dblCell(model,row,16), q4p = dblCell(model,row,17), q4e = dblCell(model,row,18);
                        // DepEd: Written=30%, Performance=50%, Assessment=20%
                        double q1 = roundG(q1w*0.30 + q1p*0.50 + q1e*0.20);
                        double q2 = roundG(q2w*0.30 + q2p*0.50 + q2e*0.20);
                        double q3 = roundG(q3w*0.30 + q3p*0.50 + q3e*0.20);
                        double q4 = roundG(q4w*0.30 + q4p*0.50 + q4e*0.20);
                        double avg = roundG((q1+q2+q3+q4)/4.0);
                        String rem = avg >= 75 ? "Passed" : "Failed";
                        model.setValueAt(q1, row, 7);
                        model.setValueAt(q2, row, 11);
                        model.setValueAt(q3, row, 15);
                        model.setValueAt(q4, row, 19);
                        model.setValueAt(avg, row, 20);
                        model.setValueAt(rem, row, 21);
                        // Save to DB
                        try (Connection conn = DBConnection.getConnection();
                             PreparedStatement ps = conn.prepareStatement(
                                 "UPDATE jhs_grades SET " +
                                 "q1_written=?,q1_performance=?,q1_assessment=?,first_grading=?," +
                                 "q2_written=?,q2_performance=?,q2_assessment=?,second_grading=?," +
                                 "q3_written=?,q3_performance=?,q3_assessment=?,third_grading=?," +
                                 "q4_written=?,q4_performance=?,q4_assessment=?,fourth_grading=?," +
                                 "average=?,remarks=? WHERE grade_id=?")) {
                            ps.setDouble(1,q1w);ps.setDouble(2,q1p);ps.setDouble(3,q1e);ps.setDouble(4,q1);
                            ps.setDouble(5,q2w);ps.setDouble(6,q2p);ps.setDouble(7,q2e);ps.setDouble(8,q2);
                            ps.setDouble(9,q3w);ps.setDouble(10,q3p);ps.setDouble(11,q3e);ps.setDouble(12,q3);
                            ps.setDouble(13,q4w);ps.setDouble(14,q4p);ps.setDouble(15,q4e);ps.setDouble(16,q4);
                            ps.setDouble(17,avg);ps.setString(18,rem);ps.setInt(19,gradeId);
                            ps.executeUpdate();
                        }
                    } else {
                        double pw = dblCell(model,row,4), pp = dblCell(model,row,5), pe = dblCell(model,row,6);
                        double mw = dblCell(model,row,8), mp = dblCell(model,row,9), me = dblCell(model,row,10);
                        double fw = dblCell(model,row,12), fp = dblCell(model,row,13), fe = dblCell(model,row,14);
                        double prelim  = roundG(pw*0.30 + pp*0.50 + pe*0.20);
                        double midterm = roundG(mw*0.30 + mp*0.50 + me*0.20);
                        double finals  = roundG(fw*0.30 + fp*0.50 + fe*0.20);
                        double avg = roundG((prelim+midterm+finals)/3.0);
                        String rem = avg >= 75 ? "Passed" : "Failed";
                        model.setValueAt(prelim,  row, 7);
                        model.setValueAt(midterm, row, 11);
                        model.setValueAt(finals,  row, 15);
                        model.setValueAt(avg, row, 16);
                        model.setValueAt(rem, row, 17);
                        try (Connection conn = DBConnection.getConnection();
                             PreparedStatement ps = conn.prepareStatement(
                                 "UPDATE shs_grades SET " +
                                 "p_written=?,p_performance=?,p_assessment=?,prelim=?," +
                                 "m_written=?,m_performance=?,m_assessment=?,midterm=?," +
                                 "f_written=?,f_performance=?,f_assessment=?,finals=?," +
                                 "average=?,remarks=? WHERE grade_id=?")) {
                            ps.setDouble(1,pw);ps.setDouble(2,pp);ps.setDouble(3,pe);ps.setDouble(4,prelim);
                            ps.setDouble(5,mw);ps.setDouble(6,mp);ps.setDouble(7,me);ps.setDouble(8,midterm);
                            ps.setDouble(9,fw);ps.setDouble(10,fp);ps.setDouble(11,fe);ps.setDouble(12,finals);
                            ps.setDouble(13,avg);ps.setString(14,rem);ps.setInt(15,gradeId);
                            ps.executeUpdate();
                        }
                    }
                } catch (Exception ex) {
                    // Silently ignore parse errors while user is mid-typing
                }
            });
        });

        JScrollPane scroll = tableScroll(table);
        panel.add(scroll, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        JButton refresh = button("\uD83D\uDD04 Refresh", ACTIVE);
        refresh.addActionListener(e -> {
            DefaultTableModel m2 = (DefaultTableModel) table.getModel();
            m2.setRowCount(0);
            try (Connection conn = DBConnection.getConnection();
                 Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {
                ResultSetMetaData md = rs.getMetaData();
                while (rs.next()) {
                    Object[] row = new Object[md.getColumnCount()];
                    for (int i = 1; i <= md.getColumnCount(); i++) row[i-1] = rs.getObject(i);
                    m2.addRow(row);
                }
            } catch (SQLException ex) { error(panel, ex.getMessage()); }
        });
        actions.add(refresh);
        panel.add(actions, BorderLayout.SOUTH);
        return panel;
    }

    private static double dblCell(DefaultTableModel m, int row, int col) {
        Object v = m.getValueAt(row, col);
        if (v == null || v.toString().isEmpty()) return 0;
        try { return Double.parseDouble(v.toString()); } catch (NumberFormatException e) { return 0; }
    }

    private static double roundG(double v) { return Math.round(v * 100.0) / 100.0; }

    private JPanel adminGradingPage(Login user) {
        JPanel page = page("Grading");
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("JHS Grading", crudPage(TABLES.get("jhs_grades"), null, true, user));
        tabs.addTab("SHS Grading", crudPage(TABLES.get("shs_grades"), null, true, user));
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel corPage(Login user) {
        JPanel page = page("Certificate of Registration");
        JTabbedPane tabs = new JTabbedPane();
        String role = user.getRole() == null ? "" : user.getRole().toLowerCase();
        String currentStudentLrn = studentLrnForUser(user.getUserId());
        String lrn    = "student".equals(role) ? currentStudentLrn : "108123456789";
        String shsLrn = "student".equals(role) ? currentStudentLrn : "109112233445";
        tabs.addTab("JHS COR", corPrintableDocument("JHS COR", false, lrn));
        tabs.addTab("SHS COR", corPrintableDocument("SHS COR", true,  shsLrn));
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel corManagementPage(Login user, String role) {
        JTabbedPane tabs = new JTabbedPane();
        if ("admin".equals(role)) {
            tabs.addTab("Create COR",   corPage(user));
            tabs.addTab("View All COR", corPage(user));
            tabs.addTab("Print COR",    corPage(user));
            tabs.addTab("Publish COR",  corPage(user));
            JPanel page = page("COR Management");
            page.add(tabs, BorderLayout.CENTER);
            return page;
        }
        if ("teacher".equals(role)) {
            tabs.addTab("Create Class COR",   corPage(user));
            tabs.addTab("Print Student COR",  corPage(user));
            tabs.addTab("View My Class COR",  corPage(user));
            JPanel page = page("COR");
            page.add(tabs, BorderLayout.CENTER);
            return page;
        }
        tabs.addTab("View COR",          corPage(user));
        tabs.addTab("Print COR",         corPage(user));
        JPanel page = page("My COR");
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    private JPanel reportCardPage(Login user) {
        JPanel page = page("Report Card");
        JTabbedPane tabs = new JTabbedPane();
        String role   = user.getRole() == null ? "" : user.getRole().toLowerCase();
        String currentStudentLrn = studentLrnForUser(user.getUserId());
        String lrn    = "student".equals(role) ? currentStudentLrn : "108123456789";
        String shsLrn = "student".equals(role) ? currentStudentLrn : "109112233445";
        tabs.addTab("JHS Report Card", printableDocument("JHS Report Card", reportCardText(false, lrn,    user)));
        tabs.addTab("SHS Report Card", printableDocument("SHS Report Card", reportCardText(true,  shsLrn, user)));
        page.add(tabs, BorderLayout.CENTER);
        return page;
    }

    // =========================================================
    //  ACCOUNT / SETTINGS PAGE
    //  Profile shows ALL details including plain-text password
    // =========================================================

    private JPanel accountPage(Login user) {
        JPanel page = page("Account");
        JPanel profile = new JPanel(new BorderLayout(10, 10));
        profile.setBackground(BG);
        JTextAreaLike details = new JTextAreaLike(profileText(user));
        profile.add(contentScroll(details), BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        JButton edit = button("Edit Profile", ACTIVE);
        edit.addActionListener(e -> editProfile(user));
        JButton pass = button("Change Password", GOOD);
        pass.addActionListener(e -> changePassword(user));
        actions.add(edit);
        actions.add(pass);
        profile.add(actions, BorderLayout.SOUTH);
        if ("admin".equalsIgnoreCase(user.getRole())) {
            JTabbedPane tabs = new JTabbedPane();
            tabs.addTab("Profile", profile);
            tabs.addTab("Users",   userManagementPage(user));
            JPanel pg = page("Settings");
            pg.add(tabs, BorderLayout.CENTER);
            return pg;
        }
        page.add(profile, BorderLayout.CENTER);
        return page;
    }

    // Profile text now includes password (visible as stored in DB)
    private String profileText(Login user) {
        String role = user.getRole() == null ? "" : user.getRole().toLowerCase();
        if ("teacher".equals(role)) {
            return rowsAsText("SELECT t.teacher_id AS 'Teacher ID', t.name AS 'Full Name', " +
                "u.username AS 'Username', u.password AS 'Password', " +
                "t.contact_no AS 'Contact No', t.email AS 'Email', u.role AS 'Role', " +
                "t.subject_taught AS 'Assigned Subject', t.level AS 'Assigned Level' " +
                "FROM users u JOIN teachers t ON t.teacher_id=u.teacher_id WHERE u.user_id=" + user.getUserId());
        }
        if ("student".equals(role)) {
            String lrn = sql(studentLrnForUser(user.getUserId()));
            String jhs = rowsAsText(
                "SELECT s.LRN, CONCAT(s.last_name, ', ', s.first_name, ' ', IFNULL(s.middle_name,'')) AS 'Full Name', " +
                "u.username AS 'Username', u.password AS 'Password', " +
                "s.gender AS Gender, s.birthdate AS Birthdate, s.address AS Address, " +
                "s.contact_no AS 'Contact No', s.guardian_name AS 'Guardian Name', " +
                "s.guardian_contact AS 'Guardian Contact', s.grade_level AS 'Grade Level', " +
                "sec.section_name AS Section, s.date_enrolled AS 'Date Enrolled', s.status AS Status, " +
                "u.role AS Role FROM jhs_students s " +
                "LEFT JOIN jhs_sections sec ON sec.section_id=s.section_id " +
                "JOIN users u ON u.user_id=s.student_id WHERE s.LRN='" + lrn + "'");
            String shs = rowsAsText(
                "SELECT s.LRN, CONCAT(s.last_name, ', ', s.first_name, ' ', IFNULL(s.middle_name,'')) AS 'Full Name', " +
                "u.username AS 'Username', u.password AS 'Password', " +
                "s.gender AS Gender, s.birthdate AS Birthdate, s.address AS Address, " +
                "s.contact_no AS 'Contact No', s.guardian_name AS 'Guardian Name', " +
                "s.guardian_contact AS 'Guardian Contact', s.grade_level AS 'Grade Level', " +
                "s.track AS Track, s.strand AS Strand, sec.section_name AS Section, " +
                "s.date_enrolled AS 'Date Enrolled', s.status AS Status, u.role AS Role " +
                "FROM shs_students s " +
                "LEFT JOIN shs_sections sec ON sec.section_id=s.section_id " +
                "JOIN users u ON u.user_id=s.student_id WHERE s.LRN='" + lrn + "'");
            return "JHS PROFILE\n" + jhs + "\nSHS PROFILE\n" + shs;
        }
        return rowsAsText(
            "SELECT full_name AS 'Full Name', username AS Username, password AS Password, " +
            "contact_no AS 'Contact No', email AS Email, role AS Role, user_id AS 'User ID' " +
            "FROM users WHERE user_id=" + user.getUserId());
    }

    private void editProfile(Login user) {
        String role = user.getRole() == null ? "" : user.getRole().toLowerCase();
        JTextField email = new JTextField(), username = new JTextField(user.getUserName()),
            contact = new JTextField(), address = new JTextField(),
            guardian = new JTextField(), guardianContact = new JTextField();
        JPanel form = "student".equals(role)
            ? smallForm(new String[]{"Email"},
                new JComponent[]{email})
            : smallForm(new String[]{"Username", "Email", "Contact No."},
                new JComponent[]{username, email, contact});
        if (JOptionPane.showConfirmDialog(this, form, "Edit Profile", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
            return;
        try (Connection conn = DBConnection.getConnection()) {
            if ("teacher".equals(role)) {
                try (PreparedStatement pst = conn.prepareStatement(
                        "UPDATE teachers SET email=?, contact_no=? WHERE teacher_id=?")) {
                    pst.setString(1, email.getText().trim());
                    pst.setString(2, contact.getText().trim());
                    pst.setInt(3, user.getTeacherId());
                    pst.executeUpdate();
                }
                updateUserProfile(conn, user.getUserId(), username.getText().trim(), email.getText().trim(), contact.getText().trim());
            } else if ("student".equals(role)) {
                try (PreparedStatement pst = conn.prepareStatement("UPDATE users SET email=? WHERE user_id=?")) {
                    pst.setString(1, email.getText().trim());
                    pst.setInt(2, user.getUserId());
                    pst.executeUpdate();
                }
            } else {
                updateUserProfile(conn, user.getUserId(), username.getText().trim(), email.getText().trim(), contact.getText().trim());
            }
            info(this, "Profile updated.");
        } catch (SQLException ex) { error(this, ex.getMessage()); }
    }

    private void changePassword(Login user) {
        JPasswordField current = new JPasswordField(), next = new JPasswordField();
        JPanel form = smallForm(new String[]{"Current Password", "New Password"}, new JComponent[]{current, next});
        if (JOptionPane.showConfirmDialog(this, form, "Change Password", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
            return;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement check = conn.prepareStatement("SELECT password FROM users WHERE user_id=?")) {
            check.setInt(1, user.getUserId());
            try (ResultSet rs = check.executeQuery()) {
                if (!rs.next() || !passwordMatches(new String(current.getPassword()), rs.getString("password"))) {
                    error(this, "Current password is incorrect.");
                    return;
                }
            }
            try (PreparedStatement pst = conn.prepareStatement("UPDATE users SET password=? WHERE user_id=?")) {
                pst.setString(1, hashPassword(new String(next.getPassword())));
                pst.setInt(2, user.getUserId());
                pst.executeUpdate();
            }
            info(this, "Password changed.");
        } catch (SQLException ex) { error(this, ex.getMessage()); }
    }

    // =========================================================
    //  GENERIC CRUD PAGE
    // =========================================================

    private JPanel crudPage(TableConfig config, String where, boolean editable, Login currentUser) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        panel.add(label(config.title, 16, Font.BOLD, INK), BorderLayout.NORTH);
        JTable table = new JTable();
        loadTable(table, config.selectSql(where), config);
        panel.add(tableScroll(table), BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        boolean allowAdd = editable && canUseAction(currentUser, config, "add");
        boolean allowEdit = editable && canUseAction(currentUser, config, "edit");
        boolean allowDelete = editable && canUseAction(currentUser, config, "delete");
        if (allowAdd || allowEdit || allowDelete) {
            JButton add  = button("\u2795 Add",             ACTIVE);
            JButton edit = button("\u270F\uFE0F Edit",      ACTIVE);
            JButton del  = button("\uD83D\uDDD1\uFE0F Delete", DANGER);
            add.setVisible(allowAdd);
            edit.setVisible(allowEdit);
            del.setVisible(allowDelete);
            add.addActionListener(e  -> recordDialog(config, table, false, where, currentUser));
            edit.addActionListener(e -> recordDialog(config, table, true,  where, currentUser));
            del.addActionListener(e  -> deleteRecord(config, table, where, currentUser));
            if (allowAdd) actions.add(add);
            if (allowEdit) actions.add(edit);
            if (allowDelete) actions.add(del);
        }
        JButton refresh = button("\uD83D\uDD04 Refresh", ACTIVE);
        refresh.addActionListener(e -> SwingUtilities.invokeLater(() -> loadTable(table, config.selectSql(where), config)));
        actions.add(refresh);
        panel.add(actions, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel readOnlyPage(String title, String sql) {
        JPanel panel = page(title);
        JTable table = new JTable();
        loadTable(table, sql);
        panel.add(tableScroll(table), BorderLayout.CENTER);
        return panel;
    }

    private void recordDialog(TableConfig config, JTable table, boolean edit, String where, Login currentUser) {
        if (edit && table.getSelectedRow() < 0) { warn(table, "Please select a record."); return; }
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        Map<FieldDef, JComponent> inputs = new LinkedHashMap<>();
        GridBagConstraints gbc = formGbc();
        for (FieldDef f : config.fields) {
            if (f.calculated) continue;
            Object currentValue = edit
                ? table.getValueAt(table.getSelectedRow(), table.getColumnModel().getColumnIndex(f.column))
                : null;
            JComponent input = edit && isReadOnlyField(currentUser, config.table, f.column)
                ? label(currentValue == null ? "" : String.valueOf(currentValue), 13, Font.PLAIN, INK)
                : inputFor(config, f);
            if (edit && !(input instanceof JLabel))
                setInputValue(input, currentValue);
            else if ("date_enrolled".equals(f.column))
                setInputValue(input, Date.valueOf(LocalDate.now()));
            addFormRow(form, gbc, formLabelText(config, f), input);
            inputs.put(f, input);
        }
        if (JOptionPane.showConfirmDialog(this, dialogScroll(form),
                (edit ? "Edit " : "Add ") + config.singular, JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
            return;

        // LRN validation for student tables
        if (config.table.endsWith("_students")) {
            String lrnVal = "";
            for (Map.Entry<FieldDef, JComponent> entry : inputs.entrySet()) {
                if ("LRN".equals(entry.getKey().column)) {
                    lrnVal = inputText(entry.getValue()).trim();
                    break;
                }
            }
            if (!lrnVal.matches("\\d{12}")) {
                error(this, "LRN must be exactly 12 numbers only (no letters, symbols, or spaces).");
                return;
            }
        }

        try {
            String message;
            if (edit) {
                Object id = table.getValueAt(table.getSelectedRow(), table.getColumnModel().getColumnIndex(config.primaryKey));
                update(config, inputs, id);
                message = "Record updated successfully!";
            } else {
                insert(config, inputs);
                message = "Record added successfully!";
            }
            loadTable(table, config.selectSql(where), config);
            info(this, message);
        } catch (Exception ex) { error(this, ex.getMessage()); }
    }

    private void insert(TableConfig config, Map<FieldDef, JComponent> inputs) throws SQLException {
        List<String> cols = new ArrayList<>();
        List<Object> vals = new ArrayList<>();
        for (Map.Entry<FieldDef, JComponent> e : inputs.entrySet()) {
            cols.add(e.getKey().column);
            vals.add(value(e.getKey(), inputText(e.getValue())));
        }
        if ("jhs_grades".equals(config.table)) computeJhs(vals, cols);
        if ("shs_grades".equals(config.table)) computeShs(vals, cols);
        validateForeignKeys(config, cols, vals);
        String marks = String.join(",", java.util.Collections.nCopies(cols.size(), "?"));
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(
                 "INSERT INTO " + config.table + "(" + String.join(",", cols) + ") VALUES (" + marks + ")")) {
            bind(pst, vals);
            pst.executeUpdate();
            syncStatusAfterMutation(conn, config.table, cols, vals, null);
        }
    }

    private void update(TableConfig config, Map<FieldDef, JComponent> inputs, Object id) throws SQLException {
        List<String> sets = new ArrayList<>(), cols = new ArrayList<>();
        List<Object> vals = new ArrayList<>();
        for (Map.Entry<FieldDef, JComponent> e : inputs.entrySet()) {
            cols.add(e.getKey().column);
            sets.add(e.getKey().column + "=?");
            vals.add(value(e.getKey(), inputText(e.getValue())));
        }
        if ("jhs_grades".equals(config.table)) { computeJhs(vals, cols); sets.add("average=?"); sets.add("remarks=?"); }
        if ("shs_grades".equals(config.table)) { computeShs(vals, cols); sets.add("average=?"); sets.add("remarks=?"); }
        validateForeignKeys(config, cols, vals);
        vals.add(id);
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(
                 "UPDATE " + config.table + " SET " + String.join(",", sets) + " WHERE " + config.primaryKey + "=?")) {
            bind(pst, vals);
            pst.executeUpdate();
            syncStatusAfterMutation(conn, config.table, cols, vals.subList(0, cols.size()), id);
        }
    }

    private void deleteRecord(TableConfig config, JTable table, String where, Login currentUser) {
        if (!canUseAction(currentUser, config, "delete")) {
            warn(table, "You do not have permission to delete records here.");
            return;
        }
        if (table.getSelectedRow() < 0) { warn(table, "Please select a record."); return; }
        if (JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this record?",
                "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION)
            return;
        Object id = table.getValueAt(table.getSelectedRow(), table.getColumnModel().getColumnIndex(config.primaryKey));
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(
                 "DELETE FROM " + config.table + " WHERE " + config.primaryKey + "=?")) {
            pst.setObject(1, id);
            pst.executeUpdate();
            loadTable(table, config.selectSql(where), config);
            info(this, "Record deleted successfully!");
        } catch (SQLException ex) {
            if ("23000".equals(ex.getSQLState()) || ex.getMessage().toLowerCase().contains("foreign key"))
                error(this, "Cannot delete: Record is currently in use.");
            else
                error(this, ex.getMessage());
        }
    }

    private void loadTable(JTable table, String sql) { loadTable(table, sql, null); }

    private void loadTable(JTable table, String sql, TableConfig config) {
        DefaultTableModel model = new DefaultTableModel();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            ResultSetMetaData md = rs.getMetaData();
            for (int i = 1; i <= md.getColumnCount(); i++) model.addColumn(md.getColumnLabel(i));
            while (rs.next()) {
                Object[] row = new Object[md.getColumnCount()];
                for (int i = 1; i <= md.getColumnCount(); i++) row[i - 1] = rs.getObject(i);
                model.addRow(row);
            }
        } catch (SQLException ex) {
            model.addColumn("Database Error");
            model.addRow(new Object[]{ex.getMessage()});
        }
        table.setModel(model);
        styleTable(table, config);
    }

    // =========================================================
    //  COR / REPORT CARD / PRINT (unchanged from original)
    // =========================================================

    private JPanel printableDocument(String title, String text) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        JPanel document = new JPanel(new BorderLayout(10, 10));
        document.setBackground(Color.WHITE);
        document.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        header.setBackground(Color.WHITE);
        header.add(logoLabel(54));
        header.add(label("KATIPUNAN NATIONAL HIGH SCHOOL", 16, Font.BOLD, INK));
        document.add(header, BorderLayout.NORTH);
        document.add(new JTextAreaLike(text), BorderLayout.CENTER);
        panel.add(contentScroll(document), BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        JButton print = button("\uD83D\uDDA8 Print / Save PDF", ACTIVE);
        print.addActionListener(e -> printDocument(document, title));
        actions.add(print);
        panel.add(actions, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel corPrintableDocument(String title, boolean shs, String lrn) {
        try {
            CorData data = loadCorData(shs, lrn);
            JPanel panel = new JPanel(new BorderLayout(10, 10));
            panel.setBackground(BG);
            final JPanel[] document = {corCertificatePanel(data, 1.0)};
            JScrollPane scroll = contentScroll(document[0]);
            panel.add(scroll, BorderLayout.CENTER);
            JPanel actions = new JPanel(new BorderLayout(12, 0));
            actions.setOpaque(false);
            JPanel sizeControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            sizeControls.setOpaque(false);
            sizeControls.add(label("Adjust Document Size:", 13, Font.PLAIN, Color.DARK_GRAY));
            JComboBox<String> size = combo(new String[]{"Small", "Medium", "Large"});
            size.setSelectedItem("Medium");
            size.addActionListener(e -> {
                double scale = "Small".equals(size.getSelectedItem()) ? 0.82 : "Large".equals(size.getSelectedItem()) ? 1.08 : 1.0;
                document[0] = corCertificatePanel(data, scale);
                scroll.setViewportView(document[0]);
                scroll.revalidate(); scroll.repaint();
            });
            sizeControls.add(size);
            JPanel printControls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            printControls.setOpaque(false);
            JButton print = button("\uD83D\uDDA8 Print / Save PDF", ACTIVE);
            print.addActionListener(e -> printDocument(document[0], title));
            printControls.add(print);
            actions.add(sizeControls,  BorderLayout.WEST);
            actions.add(printControls, BorderLayout.EAST);
            panel.add(actions, BorderLayout.SOUTH);
            return panel;
        } catch (SQLException ex) {
            return printableDocument(title, "COR cannot be loaded.\n\n" + ex.getMessage());
        }
    }

    private void printDocument(JPanel document, String title) {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName(title);
        job.setPrintable((graphics, pageFormat, pageIndex) -> {
            if (pageIndex > 0) return Printable.NO_SUCH_PAGE;
            Graphics2D g2 = (Graphics2D) graphics.create();
            double scaleX = pageFormat.getImageableWidth()  / document.getWidth();
            double scaleY = pageFormat.getImageableHeight() / document.getHeight();
            double scale  = Math.min(scaleX, scaleY);
            g2.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
            g2.scale(scale, scale);
            document.printAll(g2);
            g2.dispose();
            return Printable.PAGE_EXISTS;
        });
        try {
            if (job.printDialog()) {
                job.print();
                info(this, title + " sent to printer.");
            }
        } catch (PrinterException ex) { error(this, "Printing failed: " + ex.getMessage()); }
    }

    // loadCorData now uses LRN instead of student_no
    private CorData loadCorData(boolean shs, String lrn) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            Map<String, String> settings = corSettings(conn);
            String studentTable = shs ? "shs_students" : "jhs_students";
            String studentSql = shs
                ? "SELECT s.LRN,s.last_name,s.first_name,s.middle_name,s.grade_level,s.track,s.strand," +
                  "sec.section_name,e.enroll_id,e.school_year FROM shs_students s " +
                  "JOIN shs_sections sec ON sec.section_id=s.section_id " +
                  "JOIN shs_enrollment e ON e.student_id=s.student_id WHERE s.LRN=? LIMIT 1"
                : "SELECT s.LRN,s.last_name,s.first_name,s.middle_name,s.grade_level,'' track,'' strand," +
                  "sec.section_name,e.enroll_id,e.school_year FROM jhs_students s " +
                  "JOIN jhs_sections sec ON sec.section_id=s.section_id " +
                  "JOIN jhs_enrollment e ON e.student_id=s.student_id WHERE s.LRN=? LIMIT 1";
            String enrollSubTable = shs ? "shs_enrollment_subjects" : "jhs_enrollment_subjects";
            String unitsSelect = hasColumn(conn, enrollSubTable, "units") ? "es.units" : "'' AS units";
            String subjectSql = shs
                ? "SELECT sub.subj_name,t.name,es.schedule," + unitsSelect +
                  " FROM shs_enrollment_subjects es JOIN shs_subjects sub ON sub.subj_id=es.subj_id " +
                  "JOIN teachers t ON t.teacher_id=es.teacher_id WHERE es.enroll_id=? ORDER BY es.enroll_subject_id"
                : "SELECT sub.subj_name,t.name,es.schedule," + unitsSelect +
                  " FROM jhs_enrollment_subjects es JOIN jhs_subjects sub ON sub.subj_id=es.subj_id " +
                  "JOIN teachers t ON t.teacher_id=es.teacher_id WHERE es.enroll_id=? ORDER BY es.enroll_subject_id";
            try (PreparedStatement student = conn.prepareStatement(studentSql)) {
                student.setString(1, lrn);
                try (ResultSet rs = student.executeQuery()) {
                    if (!rs.next()) return CorData.message("No COR record found for LRN " + lrn + ".");
                    CorData data = new CorData();
                    data.shs = shs;
                    data.schoolYear  = safe(rs.getString("school_year"));
                    data.studentName = fullName(rs.getString("first_name"), rs.getString("middle_name"), rs.getString("last_name"));
                    data.gradeLevel  = "Grade " + rs.getInt("grade_level");
                    data.section     = safe(rs.getString("section_name"));
                    data.track       = safe(rs.getString("track"));
                    data.strand      = safe(rs.getString("strand"));
                    data.lrn         = safe(rs.getString("LRN"));
                    data.contact     = safe(settings.get("contact_no"));
                    data.principal   = safe(settings.get("principal_name"));
                    if (shs && (!data.track.isBlank() || !data.strand.isBlank()))
                        data.sectionLabel = data.gradeLevel + " - " + data.strand + " - " + data.section;
                    else
                        data.sectionLabel = data.gradeLevel.replace("Grade ", "") + " - " + data.section;
                    try (PreparedStatement subjects = conn.prepareStatement(subjectSql)) {
                        subjects.setInt(1, rs.getInt("enroll_id"));
                        try (ResultSet sub = subjects.executeQuery()) {
                            while (sub.next())
                                data.subjects.add(new CorSubject(
                                    safe(sub.getString("subj_name")),
                                    safe(sub.getString("name")),
                                    safe(sub.getString("schedule")),
                                    data.sectionLabel,
                                    safe(sub.getString("units"))));
                        }
                    }
                    return data;
                }
            }
        }
    }

    private JPanel corCertificatePanel(CorData data, double scale) {
        if (data.message != null) {
            JPanel document = new JPanel(new BorderLayout());
            document.setBackground(Color.WHITE);
            document.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
            document.add(new JTextAreaLike(data.message), BorderLayout.CENTER);
            return document;
        }
        JPanel document = new JPanel(new GridBagLayout());
        document.setBackground(Color.WHITE);
        document.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.BLACK, 2),
            BorderFactory.createEmptyBorder(s(26,scale), s(30,scale), s(26,scale), s(30,scale))));
        document.setPreferredSize(new Dimension(s(820,scale), s(1060,scale)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        int logoSize = s(92,scale), logoSlot = s(118,scale);
        header.add(logoSlot(LOGO,       logoSize, logoSlot, FlowLayout.LEFT),  BorderLayout.WEST);
        JPanel schoolHeader = new JPanel(new GridLayout(3, 1, 0, s(2,scale)));
        schoolHeader.setOpaque(false);
        for (JLabel line : new JLabel[]{
            corLabel("Republic of the Philippines",          s(22,scale), Font.PLAIN),
            corLabel("KATIPUNAN NATIONAL HIGH SCHOOL",       s(20,scale), Font.BOLD),
            corLabel("Katipunan, Carmen, Bohol",             s(16,scale), Font.PLAIN)}) {
            line.setHorizontalAlignment(SwingConstants.CENTER);
            schoolHeader.add(line);
        }
        header.add(schoolHeader, BorderLayout.CENTER);
        header.add(logoSlot(CARMEN_LOGO, logoSize, logoSlot, FlowLayout.RIGHT), BorderLayout.EAST);
        document.add(header, gbc);

        gbc.gridy++; gbc.insets = new Insets(s(48,scale), 0, 0, 0);
        JLabel title = corLabel("CERTIFICATE OF REGISTRATION", s(39,scale), Font.BOLD);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        document.add(title, gbc);

        gbc.gridy++; gbc.insets = new Insets(s(7,scale), 0, 0, 0);
        JLabel year = corLabel("School Year: " + data.schoolYear, s(18,scale), Font.PLAIN);
        year.setHorizontalAlignment(SwingConstants.CENTER);
        document.add(year, gbc);

        gbc.gridy++; gbc.insets = new Insets(s(62,scale), s(30,scale), 0, s(30,scale));
        document.add(corInfoPanel(data, scale), gbc);

        gbc.gridy++; gbc.insets = new Insets(s(50,scale), s(20,scale), 0, s(20,scale));
        JScrollPane subjectsTable = corSubjectsTable(data, scale);
        subjectsTable.setPreferredSize(new Dimension(s(760,scale), s(220,scale)));
        document.add(subjectsTable, gbc);

        gbc.gridy++; gbc.insets = new Insets(s(48,scale), 0, 0, 0);
        JLabel valid = corLabel("This COR is valid for the entire school year.", s(22,scale), Font.PLAIN);
        valid.setHorizontalAlignment(SwingConstants.CENTER);
        document.add(valid, gbc);

        gbc.gridy++; gbc.insets = new Insets(s(64,scale), 0, 0, s(36,scale));
        JPanel signature = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        signature.setOpaque(false);
        JPanel signatureText = new JPanel();
        signatureText.setLayout(new BoxLayout(signatureText, BoxLayout.Y_AXIS));
        signatureText.setOpaque(false);
        for (JLabel l : new JLabel[]{
            corLabel(data.principal, s(18,scale), Font.PLAIN),
            corLabel("__________________________________________________", s(20,scale), Font.PLAIN),
            corLabel("Principal's Signature", s(17,scale), Font.PLAIN)}) {
            l.setHorizontalAlignment(SwingConstants.CENTER);
            l.setAlignmentX(Component.CENTER_ALIGNMENT);
            signatureText.add(l);
            signatureText.add(Box.createVerticalStrut(s(2,scale)));
        }
        signature.add(signatureText);
        document.add(signature, gbc);
        return document;
    }

    private JPanel corInfoPanel(CorData data, double scale) {
        JPanel info = new JPanel(new GridLayout(1, 2, s(42,scale), 0));
        info.setOpaque(false);
        JPanel left = new JPanel(new GridLayout(4, 1, 0, s(10,scale)));
        left.setOpaque(false);
        left.add(corLabel("Student Name: " + data.studentName, s(21,scale), Font.PLAIN));
        left.add(corLabel("Grade Level: "  + data.gradeLevel.replace("Grade ", ""), s(21,scale), Font.PLAIN));
        left.add(corLabel("Section: "      + (data.shs ? data.section + " - " + data.track + " - " + data.strand : data.section), s(21,scale), Font.PLAIN));
        left.add(corLabel("LRN: "          + data.lrn, s(21,scale), Font.PLAIN));
        JPanel right = new JPanel(new GridLayout(1, 1, 0, 0));
        right.setOpaque(false);
        JLabel contact = corLabel("<html><div style='text-align:center'>School Contact Number:<br>" + safe(data.contact) + "</div></html>", s(20,scale), Font.PLAIN);
        contact.setHorizontalAlignment(SwingConstants.CENTER);
        right.add(contact);
        info.add(left); info.add(right);
        return info;
    }

    private JScrollPane corSubjectsTable(CorData data, double scale) {
        String[] columns = data.shs
            ? new String[]{"Subject", "Teacher", "Schedule", "Section", "Units"}
            : new String[]{"Subject", "Teacher", "Schedule", "Section"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            private static final long serialVersionUID = 1L;
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (CorSubject sub : data.subjects)
            model.addRow(data.shs
                ? new Object[]{sub.subject, sub.teacher, sub.schedule, sub.section, sub.units}
                : new Object[]{sub.subject, sub.teacher, sub.schedule, sub.section});
        JTable table = new JTable(model);
        table.setFont(new Font("Serif", Font.PLAIN, s(19,scale)));
        table.setRowHeight(s(48,scale));
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setShowGrid(true); table.setGridColor(Color.BLACK);
        table.setForeground(Color.BLACK); table.setBackground(Color.WHITE);
        table.setFocusable(false); table.setRowSelectionAllowed(false);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getTableHeader().setFont(new Font("Serif", Font.BOLD, s(21,scale)));
        table.getTableHeader().setBackground(Color.WHITE);
        table.getTableHeader().setForeground(Color.BLACK);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setPreferredSize(new Dimension(1, s(36,scale)));
        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        center.setVerticalAlignment(SwingConstants.CENTER);
        center.setFont(new Font("Serif", Font.PLAIN, s(19,scale)));
        for (int i = 0; i < table.getColumnCount(); i++) table.getColumnModel().getColumn(i).setCellRenderer(center);
        table.getColumnModel().getColumn(0).setPreferredWidth(s(data.shs ? 165 : 180, scale));
        table.getColumnModel().getColumn(1).setPreferredWidth(s(data.shs ? 205 : 220, scale));
        table.getColumnModel().getColumn(2).setPreferredWidth(s(data.shs ? 205 : 220, scale));
        table.getColumnModel().getColumn(3).setPreferredWidth(s(data.shs ? 135 : 140, scale));
        if (data.shs) table.getColumnModel().getColumn(4).setPreferredWidth(s(50, scale));
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        scroll.getViewport().setBackground(Color.WHITE);
        scroll.setPreferredSize(new Dimension(s(760,scale), Math.min(s(330,scale), s(37,scale) + Math.max(1, data.subjects.size()) * s(48,scale))));
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setWheelScrollingEnabled(true);
        return scroll;
    }

    private String reportCardText(boolean shs, String lrn, Login user) {
        String role = user.getRole() == null ? "" : user.getRole().toLowerCase();
        String teacherFilter = "teacher".equals(role)
            ? (shs ? " AND o.teacher_id=" + user.getTeacherId() : " AND o.teacher_id=" + user.getTeacherId()) : "";
        String gradesSql = shs
            ? "SELECT sub.subj_code,sub.subj_name,g.prelim,g.midterm,g.finals,g.average,g.remarks " +
              "FROM shs_grades g JOIN shs_subjects_offerings o ON o.offering_id=g.offering_id " +
              "JOIN shs_subjects sub ON sub.subj_id=o.subj_id WHERE g.student_id=?" + teacherFilter + " ORDER BY sub.subj_code"
            : "SELECT sub.subj_code,sub.subj_name,g.first_grading,g.second_grading,g.third_grading,g.fourth_grading,g.average,g.remarks " +
              "FROM jhs_grades g JOIN jhs_subjects_offerings o ON o.subj_id=g.subj_id " +
              "JOIN jhs_subjects sub ON sub.subj_id=g.subj_id WHERE g.student_id=?" + teacherFilter + " ORDER BY sub.subj_code";
        try (Connection conn = DBConnection.getConnection()) {
            String studentSql = shs
                ? "SELECT s.student_id,s.LRN,s.last_name,s.first_name,s.middle_name,s.gender,s.grade_level,s.track,s.strand,sec.section_name,s.status " +
                  "FROM shs_students s JOIN shs_sections sec ON sec.section_id=s.section_id WHERE s.LRN=? LIMIT 1"
                : "SELECT s.student_id,s.LRN,s.last_name,s.first_name,s.middle_name,s.gender,s.grade_level,'' track,'' strand,sec.section_name,s.status " +
                  "FROM jhs_students s JOIN jhs_sections sec ON sec.section_id=s.section_id WHERE s.LRN=? LIMIT 1";
            Map<String, String> settings = corSettings(conn);
            try (PreparedStatement student = conn.prepareStatement(studentSql)) {
                student.setString(1, lrn);
                try (ResultSet rs = student.executeQuery()) {
                    if (!rs.next()) return "No report card record found for LRN " + lrn + ".";
                    StringBuilder out = new StringBuilder();
                    out.append(settings.get("school_name")).append('\n');
                    out.append(settings.get("school_address")).append('\n');
                    out.append("REPORT CARD - ").append(shs ? "SENIOR HIGH SCHOOL" : "JUNIOR HIGH SCHOOL").append("\n\n");
                    out.append(String.format("%-16s: %s%n", "LRN",        rs.getString("LRN")));
                    out.append(String.format("%-16s: %s, %s %s%n", "Name",
                        rs.getString("last_name").toUpperCase(),
                        rs.getString("first_name").toUpperCase(),
                        safe(rs.getString("middle_name")).toUpperCase()));
                    out.append(String.format("%-16s: Grade %d%n", "Grade Level", rs.getInt("grade_level")));
                    if (shs) out.append(String.format("%-16s: %s - %s%n", "Track/Strand", rs.getString("track"), rs.getString("strand")));
                    out.append(String.format("%-16s: %s%n", "Section", rs.getString("section_name")));
                    out.append(String.format("%-16s: %s%n%n", "Status", rs.getString("status").toUpperCase()));
                    if (shs)
                        out.append(String.format("%-10s %-34s %8s %8s %8s %8s %-10s%n", "CODE", "SUBJECT", "PRELIM", "MIDTERM", "FINALS", "FINAL", "REMARKS"));
                    else
                        out.append(String.format("%-10s %-30s %5s %5s %5s %5s %7s %-10s%n", "CODE", "SUBJECT", "1ST", "2ND", "3RD", "4TH", "FINAL", "REMARKS"));
                    double sum = 0; int count = 0;
                    try (PreparedStatement grades = conn.prepareStatement(gradesSql)) {
                        grades.setInt(1, rs.getInt("student_id"));
                        try (ResultSet g = grades.executeQuery()) {
                            while (g.next()) {
                                count++; double average = g.getDouble("average"); sum += average;
                                if (shs)
                                    out.append(String.format("%-10s %-34s %8.0f %8.0f %8.0f %8.0f %-10s%n",
                                        g.getString("subj_code"), g.getString("subj_name"),
                                        g.getDouble("prelim"), g.getDouble("midterm"), g.getDouble("finals"), average, g.getString("remarks")));
                                else
                                    out.append(String.format("%-10s %-30s %5.0f %5.0f %5.0f %5.0f %7.0f %-10s%n",
                                        g.getString("subj_code"), g.getString("subj_name"),
                                        g.getDouble("first_grading"), g.getDouble("second_grading"),
                                        g.getDouble("third_grading"), g.getDouble("fourth_grading"), average, g.getString("remarks")));
                            }
                        }
                    }
                    double fa = count == 0 ? 0 : Math.round((sum / count) * 100.0) / 100.0;
                    out.append("\nGENERAL AVERAGE: ").append(String.format("%.2f", fa));
                    out.append("   REMARKS: ").append(fa >= 75 ? "PASSED" : "FAILED").append("\n\n");
                    out.append("_______________________                 _______________________\n");
                    out.append(settings.get("principal_name")).append("                 Class Adviser\n");
                    return out.toString();
                }
            }
        } catch (SQLException ex) {
            return "Report Card cannot be loaded.\n\n" + ex.getMessage();
        }
    }

    // =========================================================
    //  GRADING TABLE
    // =========================================================

    private JPanel gradingTable(TableConfig config, String where, boolean jhs, Login user) {
        JPanel panel = crudPage(config, where, true, user);
        JButton formula = button("Compute Formula", GOOD);
        formula.addActionListener(e -> {
            JTextField id = new JTextField(), quizzes = new JTextField(),
                       projects = new JTextField(), exams = new JTextField();
            JPanel form = smallForm(
                new String[]{"Grade ID", "Quizzes (30%)", "Projects (30%)", "Exams (40%)"},
                new JComponent[]{id, quizzes, projects, exams});
            if (JOptionPane.showConfirmDialog(panel, form, "Compute Final Grade", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
                return;
            double q = parseDouble(quizzes.getText()), p = parseDouble(projects.getText()), x = parseDouble(exams.getText());
            double finalGrade = Math.round(((q * .30) + (p * .30) + (x * .40)) * 100.0) / 100.0;
            String remarks = finalGrade >= 75 ? "Passed" : "Failed";
            String sql = jhs
                ? "UPDATE jhs_grades SET first_grading=?, second_grading=?, third_grading=?, fourth_grading=?, average=?, remarks=? WHERE grade_id=?"
                : "UPDATE shs_grades SET prelim=?, midterm=?, finals=?, average=?, remarks=? WHERE grade_id=?";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setDouble(1, q); pst.setDouble(2, p); pst.setDouble(3, x);
                if (jhs) {
                    pst.setDouble(4, finalGrade); pst.setDouble(5, finalGrade);
                    pst.setString(6, remarks); pst.setInt(7, Integer.parseInt(id.getText().trim()));
                } else {
                    pst.setDouble(4, finalGrade);
                    pst.setString(5, remarks); pst.setInt(6, Integer.parseInt(id.getText().trim()));
                }
                pst.executeUpdate();
                info(panel, "Final grade: " + finalGrade + " - " + remarks);
            } catch (Exception ex) { error(panel, ex.getMessage()); }
        });
        Component footer = ((BorderLayout) panel.getLayout()).getLayoutComponent(BorderLayout.SOUTH);
        if (footer instanceof JPanel) ((JPanel) footer).add(formula);
        else panel.add(formula, BorderLayout.SOUTH);
        return panel;
    }

    // =========================================================
    //  GLOBAL SEARCH (uses LRN instead of student_no)
    // =========================================================

    private void globalSearch(String query) {
        String q = sql(query.trim());
        if (q.isEmpty()) { showPage("Home"); return; }
        JFrame result = new JFrame("Search Results");
        result.setSize(950, 520);
        result.setLocationRelativeTo(this);
        result.add(tabbed("Search",
            readOnlyPage("Students",
                "SELECT LRN,last_name,first_name,grade_level,status,'JHS' level FROM jhs_students " +
                "WHERE LRN LIKE '%" + q + "%' OR last_name LIKE '%" + q + "%' OR first_name LIKE '%" + q + "%' " +
                "UNION ALL " +
                "SELECT LRN,last_name,first_name,grade_level,status,'SHS' level FROM shs_students " +
                "WHERE LRN LIKE '%" + q + "%' OR last_name LIKE '%" + q + "%' OR first_name LIKE '%" + q + "%'"),
            tabbed("Academic",
                readOnlyPage("Subjects",
                    "SELECT subj_code,subj_name,grade_level,'JHS' level FROM jhs_subjects " +
                    "WHERE subj_code LIKE '%" + q + "%' OR subj_name LIKE '%" + q + "%' " +
                    "UNION ALL " +
                    "SELECT subj_code,subj_name,semester,'SHS' level FROM shs_subjects " +
                    "WHERE subj_code LIKE '%" + q + "%' OR subj_name LIKE '%" + q + "%'"),
                readOnlyPage("Teachers",
                    "SELECT teacher_id,name,subject_taught,contact_no,email,level FROM teachers " +
                    "WHERE name LIKE '%" + q + "%' OR subject_taught LIKE '%" + q + "%' OR email LIKE '%" + q + "%'"))));
        result.setVisible(true);
    }

    // =========================================================
    //  HELPER METHODS
    // =========================================================

    private int createTeacher(Connection conn, String name, String contact, String email) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement(
                "INSERT INTO teachers(name,subject_taught,contact_no,email,level) VALUES (?,?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, name); pst.setString(2, "To Be Assigned");
            pst.setString(3, contact); pst.setString(4, email); pst.setString(5, "BOTH");
            pst.executeUpdate();
            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("Teacher account was not created.");
    }

    private static String normalizeSignupRole(String selectedRole) {
        String role = safe(selectedRole).trim().toLowerCase();
        if ("regular admin".equals(role)) return "regular admin";
        if ("super admin".equals(role)) return "super admin";
        return role;
    }

    private static String signupRoleToDbRole(String signupRole) {
        return signupRole.contains("admin") ? "admin" : signupRole;
    }

    private static String signupAdminPermission(String signupRole) {
        if ("super admin".equals(signupRole)) return "SUPER_ADMIN";
        if ("regular admin".equals(signupRole)) return "AUTHORIZED";
        return "AUTHORIZED";
    }

    private void submitInitialStudentEnrollment(Connection conn, int userId, String username, String email) throws SQLException {
        while (true) {
            Object choice = JOptionPane.showInputDialog(
                this,
                "Select the enrollment form to continue.",
                "Enrollment Form",
                JOptionPane.QUESTION_MESSAGE,
                null,
                new String[]{"Junior High School Form", "Senior High School Form"},
                "Junior High School Form");
            if (choice == null) {
                warn(this, "The enrollment form cannot be skipped. Please complete it to finish your registration.");
                continue;
            }
            if (choice.toString().startsWith("Junior")) {
                if (submitInitialJhsEnrollment(conn, userId, username, email)) return;
            } else if (submitInitialShsEnrollment(conn, userId, username, email)) {
                return;
            }
        }
    }

    private boolean submitInitialJhsEnrollment(Connection conn, int userId, String username, String email) throws SQLException {
        JTextField lrn = new JTextField();
        JTextField lastName = new JTextField();
        JTextField firstName = new JTextField();
        JTextField middleName = new JTextField();
        JComboBox<String> gender = combo(new String[]{"Male", "Female"});
        JSpinner birthdate = new JSpinner(new SpinnerDateModel(new java.util.Date(), null, null, Calendar.DAY_OF_MONTH));
        birthdate.setEditor(new JSpinner.DateEditor(birthdate, "yyyy-MM-dd"));
        JTextField address = new JTextField();
        JTextField contact = new JTextField();
        JComboBox<String> gradeLevel = combo(new String[]{"Grade 7", "Grade 8", "Grade 9", "Grade 10"});
        JTextField guardianName = new JTextField();
        JTextField guardianContact = new JTextField();

        JPanel form = smallForm(
            new String[]{"LRN", "Last Name", "First Name", "Middle Name", "Gender", "Date of Birth",
                "Residential Address", "Contact Number", "Grade Level", "Parent or Guardian Name",
                "Parent or Guardian Contact Number"},
            new JComponent[]{lrn, lastName, firstName, middleName, gender, birthdate, address, contact,
                gradeLevel, guardianName, guardianContact});
        if (JOptionPane.showConfirmDialog(this, dialogScroll(form), "Junior High School Enrollment Form",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            warn(this, "The enrollment form cannot be skipped. Please complete it to finish your registration.");
            return false;
        }

        String lrnValue = lrn.getText().trim();
        validateStudentEnrollmentFields(conn, lrnValue, lastName.getText(), firstName.getText(), middleName.getText(),
            address.getText(), contact.getText(), guardianName.getText(), guardianContact.getText());
        int grade = Integer.parseInt(gradeLevel.getSelectedItem().toString().replace("Grade", "").trim());
        int sectionId = findJhsSectionForGrade(conn, grade);
        if (sectionId == 0)
            throw new SQLException("No JHS section is available yet for Grade " + grade + ".");

        String studentNo = generateStudentNumber(userId, "JHS");
        Date enrolledDate = Date.valueOf(LocalDate.now());
        String schoolYear = firstEnrollmentSchoolYear(conn);
        int syId = firstEnrollmentSchoolYearId(conn);

        try (PreparedStatement pst = conn.prepareStatement(
                "INSERT INTO jhs_students(student_id, student_no, LRN, last_name, first_name, middle_name, gender, birthdate, address, contact_no, guardian_name, guardian_contact, grade_level, section_id, date_enrolled, status) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")) {
            pst.setInt(1, userId);
            pst.setString(2, studentNo);
            pst.setString(3, lrnValue);
            pst.setString(4, lastName.getText().trim());
            pst.setString(5, firstName.getText().trim());
            pst.setString(6, middleName.getText().trim());
            pst.setString(7, String.valueOf(gender.getSelectedItem()));
            pst.setDate(8, spinnerDateValue(birthdate));
            pst.setString(9, address.getText().trim());
            pst.setString(10, contact.getText().trim());
            pst.setString(11, guardianName.getText().trim());
            pst.setString(12, guardianContact.getText().trim());
            pst.setInt(13, grade);
            pst.setInt(14, sectionId);
            pst.setDate(15, enrolledDate);
            pst.setString(16, "PENDING");
            pst.executeUpdate();
        }
        try (PreparedStatement pst = conn.prepareStatement(
                "INSERT INTO jhs_enrollment(student_no, LRN, school_year, semester, date_enrolled, status, student_id, " + schoolYearIdColumn(conn) + ") " +
                "VALUES (?,?,?,?,?,?,?,?)")) {
            pst.setString(1, studentNo);
            pst.setString(2, lrnValue);
            pst.setString(3, schoolYear);
            pst.setString(4, "1st Semester");
            pst.setDate(5, enrolledDate);
            pst.setString(6, "PENDING");
            pst.setInt(7, userId);
            pst.setInt(8, syId);
            pst.executeUpdate();
        }
        updateStudentUserDetails(conn, userId, buildFullName(firstName.getText(), middleName.getText(), lastName.getText()),
            email, contact.getText().trim(), "JHS");
        return true;
    }

    private boolean submitInitialShsEnrollment(Connection conn, int userId, String username, String email) throws SQLException {
        JTextField lrn = new JTextField();
        JTextField lastName = new JTextField();
        JTextField firstName = new JTextField();
        JTextField middleName = new JTextField();
        JComboBox<String> gender = combo(new String[]{"Male", "Female"});
        JSpinner birthdate = new JSpinner(new SpinnerDateModel(new java.util.Date(), null, null, Calendar.DAY_OF_MONTH));
        birthdate.setEditor(new JSpinner.DateEditor(birthdate, "yyyy-MM-dd"));
        JTextField address = new JTextField();
        JTextField contact = new JTextField();
        JComboBox<String> gradeLevel = combo(new String[]{"Grade 11", "Grade 12"});
        JComboBox<String> track = combo(new String[]{"Academic", "TVL", "Sports", "Arts and Design"});
        JComboBox<String> strand = combo(strandsForTrack("Academic"));
        track.addActionListener(e -> resetComboItems(strand, strandsForTrack(String.valueOf(track.getSelectedItem()))));
        JTextField guardianName = new JTextField();
        JTextField guardianContact = new JTextField();

        JPanel form = smallForm(
            new String[]{"LRN", "Last Name", "First Name", "Middle Name", "Gender", "Date of Birth",
                "Residential Address", "Contact Number", "Grade Level", "Track", "Strand",
                "Parent or Guardian Name", "Parent or Guardian Contact Number"},
            new JComponent[]{lrn, lastName, firstName, middleName, gender, birthdate, address, contact,
                gradeLevel, track, strand, guardianName, guardianContact});
        if (JOptionPane.showConfirmDialog(this, dialogScroll(form), "Senior High School Enrollment Form",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            warn(this, "The enrollment form cannot be skipped. Please complete it to finish your registration.");
            return false;
        }

        String lrnValue = lrn.getText().trim();
        validateStudentEnrollmentFields(conn, lrnValue, lastName.getText(), firstName.getText(), middleName.getText(),
            address.getText(), contact.getText(), guardianName.getText(), guardianContact.getText());
        String trackValue = String.valueOf(track.getSelectedItem());
        String strandValue = String.valueOf(strand.getSelectedItem());
        int grade = Integer.parseInt(gradeLevel.getSelectedItem().toString().replace("Grade", "").trim());
        int sectionId = findShsSection(conn, grade, trackValue, strandValue);
        if (sectionId == 0)
            throw new SQLException("No SHS section is available yet for Grade " + grade + ", " + trackValue + " - " + strandValue + ".");

        String studentNo = generateStudentNumber(userId, "SHS");
        Date enrolledDate = Date.valueOf(LocalDate.now());
        String schoolYear = firstEnrollmentSchoolYear(conn);
        int syId = firstEnrollmentSchoolYearId(conn);

        try (PreparedStatement pst = conn.prepareStatement(
                "INSERT INTO shs_students(student_id, student_no, LRN, last_name, first_name, middle_name, gender, birthdate, address, contact_no, guardian_name, guardian_contact, grade_level, track, strand, section_id, date_enrolled, status) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")) {
            pst.setInt(1, userId);
            pst.setString(2, studentNo);
            pst.setString(3, lrnValue);
            pst.setString(4, lastName.getText().trim());
            pst.setString(5, firstName.getText().trim());
            pst.setString(6, middleName.getText().trim());
            pst.setString(7, String.valueOf(gender.getSelectedItem()));
            pst.setDate(8, spinnerDateValue(birthdate));
            pst.setString(9, address.getText().trim());
            pst.setString(10, contact.getText().trim());
            pst.setString(11, guardianName.getText().trim());
            pst.setString(12, guardianContact.getText().trim());
            pst.setInt(13, grade);
            pst.setString(14, trackValue);
            pst.setString(15, strandValue);
            pst.setInt(16, sectionId);
            pst.setDate(17, enrolledDate);
            pst.setString(18, "PENDING");
            pst.executeUpdate();
        }
        try (PreparedStatement pst = conn.prepareStatement(
                "INSERT INTO shs_enrollment(student_no, LRN, school_year, semester, date_enrolled, status, student_id, " + schoolYearIdColumn(conn) + ", track, strand) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?)")) {
            pst.setString(1, studentNo);
            pst.setString(2, lrnValue);
            pst.setString(3, schoolYear);
            pst.setString(4, "1st Semester");
            pst.setDate(5, enrolledDate);
            pst.setString(6, "PENDING");
            pst.setInt(7, userId);
            pst.setInt(8, syId);
            pst.setString(9, trackValue);
            pst.setString(10, strandValue);
            pst.executeUpdate();
        }
        updateStudentUserDetails(conn, userId, buildFullName(firstName.getText(), middleName.getText(), lastName.getText()),
            email, contact.getText().trim(), "SHS");
        return true;
    }

    private void validateStudentEnrollmentFields(Connection conn, String lrn, String lastName, String firstName, String middleName,
                                                 String address, String contact, String guardianName, String guardianContact) throws SQLException {
        if (!lrn.matches("\\d{12}"))
            throw new SQLException("LRN must be exactly 12 digits.");
        if (safe(lastName).isBlank() || safe(firstName).isBlank() || safe(middleName).isBlank() ||
                safe(address).isBlank() || safe(contact).isBlank() || safe(guardianName).isBlank() || safe(guardianContact).isBlank())
            throw new SQLException("Please complete all enrollment fields.");
        if (exists(conn, "SELECT 1 FROM jhs_students WHERE LRN=? UNION SELECT 1 FROM shs_students WHERE LRN=?", lrn, lrn))
            throw new SQLException("The LRN already exists.");
    }

    private static Date spinnerDateValue(JSpinner spinner) {
        java.util.Date value = (java.util.Date) spinner.getValue();
        return new Date(value.getTime());
    }

    private static String[] strandsForTrack(String track) {
        String normalized = safe(track);
        if ("TVL".equalsIgnoreCase(normalized)) return new String[]{"ICT", "HE"};
        if ("Sports".equalsIgnoreCase(normalized)) return new String[]{"Sports"};
        if ("Arts and Design".equalsIgnoreCase(normalized)) return new String[]{"Arts and Design"};
        return new String[]{"STEM", "ABM", "HUMSS", "GAS"};
    }

    private static void resetComboItems(JComboBox<String> box, String[] items) {
        box.removeAllItems();
        for (String item : items) box.addItem(item);
        if (box.getItemCount() > 0) box.setSelectedIndex(0);
    }

    private static String buildFullName(String firstName, String middleName, String lastName) {
        String middle = safe(middleName).isBlank() ? "" : " " + middleName.trim();
        return firstName.trim() + middle + " " + lastName.trim();
    }

    private static String generateStudentNumber(int userId, String level) {
        return level + "-" + String.format("%06d", userId);
    }

    private static int findJhsSectionForGrade(Connection conn, int grade) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement(
                "SELECT section_id FROM jhs_sections WHERE grade_level=? ORDER BY section_id LIMIT 1")) {
            pst.setInt(1, grade);
            try (ResultSet rs = pst.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    private static int findShsSection(Connection conn, int grade, String track, String strand) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement(
                "SELECT section_id FROM shs_sections WHERE grade_level=? AND track=? AND strand=? ORDER BY section_id LIMIT 1")) {
            pst.setInt(1, grade);
            pst.setString(2, track);
            pst.setString(3, strand);
            try (ResultSet rs = pst.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    private static String schoolYearIdColumn(Connection conn) throws SQLException {
        return hasColumn(conn, "school_years", "sy_id") ? "sy_id" : "school_year_id";
    }

    private static String firstEnrollmentSchoolYear(Connection conn) throws SQLException {
        String sql = "SELECT school_year FROM school_years WHERE semester='1st Semester' " +
            (hasColumn(conn, "school_years", "is_active") ? "ORDER BY is_active DESC, " : "ORDER BY ") +
            schoolYearIdColumn(conn) + " DESC LIMIT 1";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getString(1);
        }
        int year = LocalDate.now().getYear();
        return year + "-" + (year + 1);
    }

    private static int firstEnrollmentSchoolYearId(Connection conn) throws SQLException {
        String sql = "SELECT " + schoolYearIdColumn(conn) + " FROM school_years WHERE semester='1st Semester' " +
            (hasColumn(conn, "school_years", "is_active") ? "ORDER BY is_active DESC, " : "ORDER BY ") +
            schoolYearIdColumn(conn) + " DESC LIMIT 1";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        }
        throw new SQLException("No school year is available yet for 1st Semester enrollment.");
    }

    private static void updateStudentUserDetails(Connection conn, int userId, String fullName, String email, String contact, String userType) throws SQLException {
        StringBuilder sql = new StringBuilder("UPDATE users SET full_name=?, email=?");
        if (hasColumn(conn, "users", "contact_no")) sql.append(", contact_no=?");
        if (hasColumn(conn, "users", "user_type")) sql.append(", user_type=?");
        sql.append(" WHERE user_id=?");
        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            pst.setString(1, fullName);
            pst.setString(2, email);
            int index = 3;
            if (hasColumn(conn, "users", "contact_no")) pst.setString(index++, contact);
            if (hasColumn(conn, "users", "user_type")) pst.setString(index++, userType);
            pst.setInt(index, userId);
            pst.executeUpdate();
        }
    }

    private void submitNextTermEnrollment(Connection conn, int userId) throws SQLException {
        if (!isEnrollmentOpen())
            throw new SQLException("Enrollment is currently closed.");

        String lrn = "";
        String studentNo = "";
        String userType = "";
        String track = "";
        String strand = "";
        String fullName = "";
        String studentSql =
            "SELECT 'JHS' AS user_type, student_no, LRN, CONCAT(first_name,' ',middle_name,' ',last_name) AS full_name, '' AS track, '' AS strand " +
            "FROM jhs_students WHERE student_id=? " +
            "UNION ALL " +
            "SELECT 'SHS', student_no, LRN, CONCAT(first_name,' ',middle_name,' ',last_name), track, strand " +
            "FROM shs_students WHERE student_id=? LIMIT 1";
        try (PreparedStatement pst = conn.prepareStatement(studentSql)) {
            pst.setInt(1, userId);
            pst.setInt(2, userId);
            try (ResultSet rs = pst.executeQuery()) {
                if (!rs.next())
                    throw new SQLException("No saved student profile was found for this account.");
                userType = rs.getString("user_type");
                studentNo = rs.getString("student_no");
                lrn = rs.getString("LRN");
                track = safe(rs.getString("track"));
                strand = safe(rs.getString("strand"));
                fullName = safe(rs.getString("full_name")).replaceAll("\\s+", " ").trim();
            }
        }

        List<String> schoolYears = new ArrayList<>();
        List<String> semesters = new ArrayList<>();
        String termSql = "SELECT " + schoolYearIdColumn(conn) + ", school_year, semester FROM school_years " +
            (hasColumn(conn, "school_years", "is_active") ? "WHERE is_active=1 " : "") +
            "ORDER BY " + schoolYearIdColumn(conn) + " DESC";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(termSql)) {
            while (rs.next()) {
                String schoolYear = safe(rs.getString("school_year"));
                String semester = safe(rs.getString("semester"));
                if (!schoolYears.contains(schoolYear)) schoolYears.add(schoolYear);
                if (!semesters.contains(semester)) semesters.add(semester);
            }
        }
        if (schoolYears.isEmpty())
            throw new SQLException("No open enrollment term is available in school_years.");

        JLabel fullNameLabel = valueLabel(fullName);
        JLabel lrnLabel = valueLabel(lrn);
        JLabel userTypeLabel = valueLabel(userType);
        JComboBox<String> schoolYear = combo(schoolYears.toArray(new String[0]));
        JComboBox<String> semester = combo(semesters.toArray(new String[0]));

        JPanel form = smallForm(
            new String[]{"Full Name", "LRN", "Student Type", "School Year", "Semester"},
            new JComponent[]{fullNameLabel, lrnLabel, userTypeLabel, schoolYear, semester});
        if (JOptionPane.showConfirmDialog(this, dialogScroll(form), "Student Enrollment",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION)
            return;

        if (schoolYear.getSelectedItem() == null || semester.getSelectedItem() == null)
            throw new SQLException("Please select a school year and semester.");
        String selectedSchoolYear = String.valueOf(schoolYear.getSelectedItem()).trim();
        String selectedSemester = String.valueOf(semester.getSelectedItem()).trim();
        int syId = resolveSchoolYearId(conn, selectedSchoolYear, selectedSemester);
        Date today = Date.valueOf(LocalDate.now());

        if ("SHS".equalsIgnoreCase(userType)) {
            if (exists(conn, "SELECT 1 FROM shs_enrollment WHERE student_id=? AND sy_id=? AND semester=?", userId, syId, selectedSemester))
                throw new SQLException("An SHS enrollment record for the selected term already exists.");
            try (PreparedStatement pst = conn.prepareStatement(
                    "INSERT INTO shs_enrollment(student_no, LRN, school_year, semester, date_enrolled, status, student_id, sy_id, track, strand) VALUES (?,?,?,?,?,?,?,?,?,?)")) {
                pst.setString(1, studentNo);
                pst.setString(2, lrn);
                pst.setString(3, selectedSchoolYear);
                pst.setString(4, selectedSemester);
                pst.setDate(5, today);
                pst.setString(6, "PENDING");
                pst.setInt(7, userId);
                pst.setInt(8, syId);
                pst.setString(9, track);
                pst.setString(10, strand);
                pst.executeUpdate();
            }
        } else {
            if (exists(conn, "SELECT 1 FROM jhs_enrollment WHERE student_id=? AND sy_id=? AND semester=?", userId, syId, selectedSemester))
                throw new SQLException("A JHS enrollment record for the selected term already exists.");
            try (PreparedStatement pst = conn.prepareStatement(
                    "INSERT INTO jhs_enrollment(student_no, LRN, school_year, semester, date_enrolled, status, student_id, sy_id) VALUES (?,?,?,?,?,?,?,?)")) {
                pst.setString(1, studentNo);
                pst.setString(2, lrn);
                pst.setString(3, selectedSchoolYear);
                pst.setString(4, selectedSemester);
                pst.setDate(5, today);
                pst.setString(6, "PENDING");
                pst.setInt(7, userId);
                pst.setInt(8, syId);
                pst.executeUpdate();
            }
        }
        syncStudentStatusByStudentId(conn, userId, "PENDING");
    }

    private static JLabel valueLabel(String text) {
        JLabel label = new JLabel(safe(text));
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        return label;
    }

    private static String[] extractSemesters(List<String> labels) {
        List<String> terms = new ArrayList<>();
        for (String label : labels) {
            String[] parts = label.split("\\|", 2);
            if (parts.length == 2) {
                String semester = parts[1].trim();
                if (!terms.contains(semester)) terms.add(semester);
            }
        }
        return terms.toArray(new String[0]);
    }

    private static int resolveSchoolYearId(Connection conn, String schoolYear, String semester) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement(
                "SELECT " + schoolYearIdColumn(conn) + " FROM school_years WHERE school_year=? AND semester=? " +
                (hasColumn(conn, "school_years", "is_active") ? "ORDER BY is_active DESC, " : "ORDER BY ") +
                schoolYearIdColumn(conn) + " DESC LIMIT 1")) {
            pst.setString(1, schoolYear);
            pst.setString(2, semester);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("The selected school year and semester are not open for enrollment.");
    }

    private int createUser(Connection conn, String fullName, String username, String password,
                           String role, String email, String contact, Integer teacherId,
                           String accountStatus, String adminPermission, String userType) throws SQLException {
        boolean hasFullName  = hasColumn(conn, "users", "full_name");
        boolean hasContact   = hasColumn(conn, "users", "contact_no");
        boolean hasStatus    = hasColumn(conn, "users", "account_status");
        boolean hasPerm      = hasColumn(conn, "users", "admin_permission");
        boolean hasUserType  = hasColumn(conn, "users", "user_type");

        StringBuilder cols = new StringBuilder(), marks = new StringBuilder();
        List<Object> params = new ArrayList<>();

        if (hasFullName)  { cols.append("full_name,");        marks.append("?,"); params.add(fullName); }
        cols.append("username,");  marks.append("?,"); params.add(username);
        cols.append("password,");  marks.append("?,"); params.add(hashPassword(password));
        cols.append("role,");      marks.append("?,"); params.add(role);
        cols.append("email,");     marks.append("?,"); params.add(email);
        if (hasContact)   { cols.append("contact_no,");       marks.append("?,"); params.add(contact); }
        cols.append("teacher_id,"); marks.append("?,"); params.add(teacherId);
        if (hasStatus)    { cols.append("account_status,");   marks.append("?,"); params.add(accountStatus); }
        if (hasPerm)      { cols.append("admin_permission,"); marks.append("?,"); params.add(adminPermission); }
        if (hasUserType)  { cols.append("user_type,");        marks.append("?,"); params.add(userType); }

        String colsSql  = cols.toString().replaceAll(",$", "");
        String marksSql = marks.toString().replaceAll(",$", "");
        try (PreparedStatement pst = conn.prepareStatement(
                "INSERT INTO users (" + colsSql + ") VALUES (" + marksSql + ")", Statement.RETURN_GENERATED_KEYS)) {
            for (int i = 0; i < params.size(); i++) {
                if (params.get(i) == null) pst.setNull(i + 1, Types.NULL);
                else pst.setObject(i + 1, params.get(i));
            }
            pst.executeUpdate();
            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("User account was not created.");
    }

    private static String[] allowedRoleOptions(Login currentUser) {
        if (currentUser != null && currentUser.isSuperAdmin()) return new String[]{"Admin"};
        return new String[]{"Teacher", "Student"};
    }

    private static boolean canManageUserRole(Login currentUser, String targetRole) {
        if (currentUser == null || targetRole == null) return true;
        String role = safe(targetRole).toLowerCase();
        if (!"admin".equalsIgnoreCase(currentUser.getRole())) return false;
        if (currentUser.isSuperAdmin()) return "admin".equals(role);
        return "teacher".equals(role) || "student".equals(role);
    }

    private static String authorizationMessageForRole(Login currentUser, String targetRole) {
        if (currentUser != null && currentUser.isSuperAdmin())
            return "Super Admin may only add, approve, or change the status of administrator accounts.";
        return "Regular admins may only add, approve, or change the status of teacher and student accounts.";
    }

    private static String roleScopedPermission(String role, String permission) {
        if ("admin".equalsIgnoreCase(role)) return safe(permission).isBlank() ? "PENDING" : permission;
        return "AUTHORIZED";
    }

    private static boolean isReadOnlyField(Login currentUser, String table, String column) {
        if (column == null) return false;
        if (isFixedDetailField(table, column) || isSystemKeyField(table, column)) return true;
        if (currentUser == null) return false;
        if ("teacher".equalsIgnoreCase(currentUser.getRole()))
            return !isTeacherEditableField(table, column);
        if ("student".equalsIgnoreCase(currentUser.getRole()))
            return true;
        return false;
    }

    private static boolean canUseAction(Login currentUser, TableConfig config, String action) {
        if (currentUser == null) return true;
        String role = safe(currentUser.getRole()).toLowerCase();
        if ("student".equals(role)) return false;
        if ("teacher".equals(role))
            return "edit".equals(action) && isTeacherEditableTable(config.table);
        if ("admin".equals(role)) {
            if (currentUser.isSuperAdmin()) return true;
            return false;
        }
        return false;
    }

    private static boolean isTeacherEditableTable(String table) {
        return "jhs_grades".equals(table) || "shs_grades".equals(table);
    }

    private static boolean isTeacherEditableField(String table, String column) {
        if ("jhs_grades".equals(table))
            return Arrays.asList("first_grading", "second_grading", "third_grading", "fourth_grading").contains(column);
        if ("shs_grades".equals(table))
            return Arrays.asList("prelim", "midterm", "finals").contains(column);
        return false;
    }

    private static boolean isFixedDetailField(String table, String column) {
        if ("users".equals(table))
            return Arrays.asList("full_name", "email", "contact_no", "teacher_id").contains(column);
        if ("teachers".equals(table))
            return Arrays.asList("name", "contact_no", "email").contains(column);
        if ("jhs_students".equals(table) || "shs_students".equals(table))
            return Arrays.asList("student_no", "LRN", "last_name", "first_name", "middle_name", "gender", "birthdate",
                "address", "contact_no", "guardian_name", "guardian_contact").contains(column);
        if (table.endsWith("_grades"))
            return "student_id".equals(column);
        if (table.endsWith("_enrollment"))
            return Arrays.asList("student_no", "LRN", "student_id", "sy_id").contains(column);
        if (table.endsWith("_subjects_offerings"))
            return "teacher_id".equals(column);
        return false;
    }

    private static boolean isSystemKeyField(String table, String column) {
        if ("users".equals(table)) return false;
        if (column.endsWith("_id")) return true;
        return "subj_id".equals(column) || "offering_id".equals(column) || "LRN".equals(column);
    }

    private void syncStatusAfterMutation(Connection conn, String table, List<String> cols, List<Object> vals, Object id) throws SQLException {
        Map<String, Object> changed = new LinkedHashMap<>();
        for (int i = 0; i < cols.size(); i++) changed.put(cols.get(i), vals.get(i));
        if ("users".equals(table)) {
            Object userId = id != null ? id : firstGeneratedId(conn, "users");
            if (userId != null) syncUserStatus(conn, Integer.parseInt(String.valueOf(userId)));
            return;
        }
        if ("jhs_students".equals(table) || "shs_students".equals(table)) {
            String lrn = stringValue(changed.get("LRN"));
            if (lrn.isBlank() && id != null) lrn = studentLrnById(conn, table, id);
            if (!lrn.isBlank() && changed.containsKey("status"))
                syncStudentStatusByLrn(conn, lrn, stringValue(changed.get("status")));
            return;
        }
        if ("jhs_enrollment".equals(table) || "shs_enrollment".equals(table)) {
            Object studentId = changed.get("student_id");
            String status = stringValue(changed.get("status"));
            if (!status.isBlank() && studentId != null)
                syncEnrollmentStatus(conn, table, Integer.parseInt(String.valueOf(studentId)), status);
        }
    }

    private static Integer firstGeneratedId(Connection conn, String table) throws SQLException {
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT MAX(" + ("users".equals(table) ? "user_id" : "student_id") + ") id FROM " + table)) {
            return rs.next() ? rs.getInt("id") : null;
        }
    }

    private static String studentLrnById(Connection conn, String table, Object id) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement("SELECT LRN FROM " + table + " WHERE student_id=?")) {
            pst.setObject(1, id);
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next() ? safe(rs.getString("LRN")) : "";
            }
        }
    }

    private static void syncUserStatus(Connection conn, int userId) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement(
                "SELECT role, account_status FROM users WHERE user_id=?")) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                if (!rs.next()) return;
                if ("student".equalsIgnoreCase(rs.getString("role")))
                    syncStudentStatusByStudentId(conn, userId, rs.getString("account_status"));
            }
        }
    }

    private static void syncStudentStatusByStudentId(Connection conn, int studentId, String status) throws SQLException {
        if (studentId <= 0 || safe(status).isBlank()) return;
        try (PreparedStatement pst = conn.prepareStatement(
                "SELECT LRN FROM jhs_students WHERE student_id=? UNION ALL SELECT LRN FROM shs_students WHERE student_id=? LIMIT 1")) {
            pst.setInt(1, studentId);
            pst.setInt(2, studentId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) syncStudentStatusByLrn(conn, rs.getString(1), status);
            }
        }
    }

    private static void syncStudentStatusByLrn(Connection conn, String lrn, String status) throws SQLException {
        if (safe(lrn).isBlank() || safe(status).isBlank()) return;
        updateStatusByLrn(conn, "jhs_students", lrn, status);
        updateStatusByLrn(conn, "shs_students", lrn, status);
        updateUserAccountStatus(conn, lrn, toAccountStatus(status));
        syncEnrollmentRows(conn, "jhs_enrollment", "jhs_students", lrn, status);
        syncEnrollmentRows(conn, "shs_enrollment", "shs_students", lrn, status);
    }

    private static void syncEnrollmentStatus(Connection conn, String enrollmentTable, int studentId, String status) throws SQLException {
        String studentTable = enrollmentTable.startsWith("jhs_") ? "jhs_students" : "shs_students";
        try (PreparedStatement pst = conn.prepareStatement("SELECT LRN FROM " + studentTable + " WHERE student_id=?")) {
            pst.setInt(1, studentId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) syncStudentStatusByLrn(conn, rs.getString("LRN"), status);
            }
        }
    }

    private static void updateStatusByLrn(Connection conn, String table, String lrn, String status) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement("UPDATE " + table + " SET status=? WHERE LRN=?")) {
            pst.setString(1, status);
            pst.setString(2, lrn);
            pst.executeUpdate();
        }
    }

    private static void syncEnrollmentRows(Connection conn, String enrollmentTable, String studentTable, String lrn, String status) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement(
                "UPDATE " + enrollmentTable + " e JOIN " + studentTable + " s ON s.student_id=e.student_id " +
                "SET e.status=?, e.LRN=s.LRN WHERE s.LRN=?")) {
            pst.setString(1, status);
            pst.setString(2, lrn);
            pst.executeUpdate();
        }
    }

    private static void updateUserAccountStatus(Connection conn, String lrn, String accountStatus) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement(
                "UPDATE users SET account_status=? WHERE role='student' AND user_id IN (" +
                "SELECT student_id FROM jhs_students WHERE LRN=? UNION SELECT student_id FROM shs_students WHERE LRN=?)")) {
            pst.setString(1, accountStatus);
            pst.setString(2, lrn);
            pst.setString(3, lrn);
            pst.executeUpdate();
        }
    }

    private static String toAccountStatus(String status) {
        String normalized = safe(status).toUpperCase();
        if ("PENDING".equals(normalized)) return "PENDING";
        if ("ACTIVE".equals(normalized) || "ENROLLED".equals(normalized) || "APPROVED".equals(normalized)) return "ACTIVE";
        return "INACTIVE";
    }

    private static String stringValue(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private boolean fullNameExists(Connection conn, String fullName, int excludeUserId) throws SQLException {
        String sql = excludeUserId > 0
            ? "SELECT 1 FROM users WHERE full_name=? AND user_id != ?"
            : "SELECT 1 FROM users WHERE full_name=?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, fullName);
            if (excludeUserId > 0) pst.setInt(2, excludeUserId);
            try (ResultSet rs = pst.executeQuery()) { return rs.next(); }
        }
    }

    private void updateHierarchyLabel(JLabel hierarchyInfo) {
        int superAdmins = countUsers(
            "SELECT COUNT(*) FROM users WHERE role='admin' AND (admin_permission='SUPER_ADMIN' OR user_id=1)");
        int admins = countUsers(
            "SELECT COUNT(*) FROM users WHERE role='admin' AND NOT (admin_permission='SUPER_ADMIN' OR user_id=1)");
        int teachers = countUsers("SELECT COUNT(*) FROM users WHERE role='teacher'");
        int students = countUsers("SELECT COUNT(*) FROM users WHERE role='student'");
        hierarchyInfo.setText(
            "<html><b>Hierarchy:</b> " +
            "1. Super Admin (" + superAdmins + ") &nbsp;&nbsp; " +
            "2. Admin (" + admins + ") &nbsp;&nbsp; " +
            "3. Teacher (" + teachers + ") &nbsp;&nbsp; " +
            "4. Student (" + students + ")" +
            "</html>");
    }

    private static int countUsers(String sql) {
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException ex) {
            return 0;
        }
    }

    private static void hideColumn(JTable table, int col) {
        TableColumn column = table.getColumnModel().getColumn(col);
        column.setMinWidth(0); column.setMaxWidth(0); column.setWidth(0); column.setPreferredWidth(0);
    }

    private static int getIntCell(JTable table, int modelRow, int col) {
        Object val = table.getModel().getValueAt(modelRow, col);
        if (val == null) return 0;
        try { return Integer.parseInt(val.toString()); } catch (NumberFormatException ex) { return 0; }
    }

    private static String getStringCell(JTable table, int modelRow, int col) {
        Object val = table.getModel().getValueAt(modelRow, col);
        return val == null ? "" : val.toString();
    }

    private static void setComboValue(JComboBox<String> box, String value) {
        for (int i = 0; i < box.getItemCount(); i++) {
            if (String.valueOf(box.getItemAt(i)).equalsIgnoreCase(value)) {
                box.setSelectedIndex(i); return;
            }
        }
    }

    private static void updateStudentContactByLrn(Connection conn, String table, String lrn,
            String address, String contact, String email, String guardian,
            String guardianContact, String status) throws SQLException {
        String statusSql = status == null ? "" : ", status=?";
        try (PreparedStatement pst = conn.prepareStatement(
                "UPDATE " + table + " SET address=?, contact_no=?, email=?, guardian_name=?, guardian_contact=?" +
                statusSql + " WHERE LRN=?")) {
            pst.setString(1, address.trim()); pst.setString(2, contact.trim());
            pst.setString(3, email.trim());   pst.setString(4, guardian.trim());
            pst.setString(5, guardianContact.trim());
            if (status == null) pst.setString(6, lrn);
            else { pst.setString(6, status); pst.setString(7, lrn); }
            pst.executeUpdate();
        }
    }

    private static void updateUserProfile(Connection conn, int userId, String username, String email, String contact) throws SQLException {
        boolean contactColumn = hasColumn(conn, "users", "contact_no");
        String sql = contactColumn
            ? "UPDATE users SET username=?, email=?, contact_no=? WHERE user_id=?"
            : "UPDATE users SET username=?, email=? WHERE user_id=?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, username); pst.setString(2, email);
            if (contactColumn) { pst.setString(3, contact); pst.setInt(4, userId); }
            else pst.setInt(3, userId);
            pst.executeUpdate();
        }
    }

    // =========================================================
    //  INPUT HELPERS
    // =========================================================

    private JComponent inputFor(TableConfig config, FieldDef f) {
        if (f.type == FieldType.DATE) {
            JSpinner spinner = new JSpinner(new SpinnerDateModel(new java.util.Date(), null, null, Calendar.DAY_OF_MONTH));
            spinner.setEditor(new JSpinner.DateEditor(spinner, "yyyy-MM-dd"));
            spinner.setPreferredSize(new Dimension(260, 38));
            return spinner;
        }
        String[] opts = optionsFor(config.table, f.column);
        if (opts.length > 0 || isForeignKeyField(config.table, f.column)) {
            if (!f.required) opts = withBlankOption(opts);
            JComboBox<String> box = combo(opts);
            box.setPreferredSize(new Dimension(260, 38));
            return box;
        }
        JTextField input = new JTextField();
        styleInput(input);
        return input;
    }

    private String[] optionsFor(String table, String column) {
        if ("role".equals(column))           return new String[]{"admin", "teacher", "student"};
        if ("account_status".equals(column)) return new String[]{"ACTIVE", "INACTIVE", "PENDING"};
        if ("admin_permission".equals(column)) return new String[]{"PENDING", "AUTHORIZED", "SUPER_ADMIN"};
        if ("gender".equals(column))         return new String[]{"Male", "Female"};
        // Status in correct order per requirements
        if ("status".equals(column))         return new String[]{"PENDING", "NOT ENROLLED", "ENROLLED", "ACTIVE", "INACTIVE", "DROPPED", "GRADUATED"};
        if ("grade_level".equals(column) && table.startsWith("jhs_")) return new String[]{"7", "8", "9", "10"};
        if ("grade_level".equals(column) && table.startsWith("shs_")) return new String[]{"11", "12"};
        if ("track".equals(column))   return distinctOrDefault("SELECT DISTINCT track FROM shs_sections UNION SELECT DISTINCT track FROM shs_subjects", new String[]{"Academic", "TVL", "Sports", "Arts and Design"});
        if ("strand".equals(column))  return distinctOrDefault("SELECT DISTINCT strand FROM shs_sections UNION SELECT DISTINCT strand FROM shs_subjects", new String[]{"STEM", "ABM", "HUMSS", "GAS", "ICT", "HE"});
        if ("semester".equals(column)) return new String[]{"1st Semester", "2nd Semester"};
        if ("school_year".equals(column)) return schoolYears();
        if ("user_type".equals(column)) return new String[]{"JHS", "SHS"};
        if ("level".equals(column))   return new String[]{"JHS", "SHS", "BOTH"};
        if ("section_id".equals(column) && table.startsWith("jhs_")) return idOptions("SELECT section_id, CONCAT(section_name, ' - Grade ', grade_level) label FROM jhs_sections ORDER BY grade_level, section_name");
        if ("section_id".equals(column) && table.startsWith("shs_")) return idOptions("SELECT section_id, CONCAT(section_name, ' - ', strand, ' Grade ', grade_level) label FROM shs_sections ORDER BY grade_level, section_name");
        if ("subj_id".equals(column) && table.startsWith("jhs_"))    return idOptions("SELECT subj_id, CONCAT(subj_code, ' - ', subj_name) label FROM jhs_subjects ORDER BY subj_code");
        if ("subj_id".equals(column) && table.startsWith("shs_"))    return idOptions("SELECT subj_id, CONCAT(subj_code, ' - ', subj_name) label FROM shs_subjects ORDER BY subj_code");
        if ("teacher_id".equals(column)) return idOptions("SELECT teacher_id, name label FROM teachers ORDER BY name");
        if ("offering_id".equals(column)) return idOptions("SELECT offering_id, CONCAT(s.subj_code, ' - ', sec.section_name, ' - ', o.school_year) label FROM shs_subjects_offerings o JOIN shs_subjects s ON s.subj_id=o.subj_id JOIN shs_sections sec ON sec.section_id=o.section_id ORDER BY offering_id");
        if ("student_id".equals(column) && table.startsWith("jhs_")) return idOptions("SELECT student_id, CONCAT(LRN, ' - ', last_name, ', ', first_name) label FROM jhs_students ORDER BY last_name, first_name");
        if ("student_id".equals(column) && table.startsWith("shs_")) return idOptions("SELECT student_id, CONCAT(LRN, ' - ', last_name, ', ', first_name) label FROM shs_students ORDER BY last_name, first_name");
        if ("LRN".equals(column) && table.startsWith("jhs_")) return distinctOrDefault("SELECT LRN FROM jhs_students ORDER BY LRN", new String[0]);
        if ("LRN".equals(column) && table.startsWith("shs_")) return distinctOrDefault("SELECT LRN FROM shs_students ORDER BY LRN", new String[0]);
        return new String[0];
    }

    private static String[] withBlankOption(String[] options) {
        String[] values = new String[options.length + 1];
        values[0] = "";
        System.arraycopy(options, 0, values, 1, options.length);
        return values;
    }

    private static String inputText(JComponent input) {
        if (input instanceof JTextField)  return ((JTextField) input).getText();
        if (input instanceof JComboBox)   { Object v = ((JComboBox<?>) input).getSelectedItem(); return v == null ? "" : v.toString(); }
        if (input instanceof JSpinner) {
            Object v = ((JSpinner) input).getValue();
            if (v instanceof java.util.Date) return new SimpleDateFormat("yyyy-MM-dd").format((java.util.Date) v);
            return String.valueOf(v);
        }
        if (input instanceof JLabel) return ((JLabel) input).getText();
        return "";
    }

    private static void setInputValue(JComponent input, Object value) {
        String text = value == null ? "" : String.valueOf(value);
        if (input instanceof JTextField) { ((JTextField) input).setText(text); }
        else if (input instanceof JComboBox) {
            JComboBox<?> box = (JComboBox<?>) input;
            for (int i = 0; i < box.getItemCount(); i++) {
                if (String.valueOf(box.getItemAt(i)).equals(text) || String.valueOf(box.getItemAt(i)).startsWith(text + " - ")) {
                    box.setSelectedIndex(i); break;
                }
            }
        } else if (input instanceof JSpinner) {
            try {
                java.util.Date date = value instanceof java.sql.Date
                    ? new java.util.Date(((java.sql.Date) value).getTime())
                    : java.util.Date.from(LocalDate.parse(text).atStartOfDay(ZoneId.systemDefault()).toInstant());
                ((JSpinner) input).setValue(date);
            } catch (Exception ignored) {}
        }
    }

    // =========================================================
    //  NAVIGATION / PAGE HELPERS
    // =========================================================

    private void showPage(String name) {
        String pageName = resolvePageName(name);
        cards.show(mainPanel, pageName);
        navButtons.forEach((page, button) -> setNavActive(button, page.equals(pageName)));
    }

    private String resolvePageName(String name) {
        if (navButtons.containsKey(name)) return name;
        Map<String, String> aliases = new LinkedHashMap<>();
        aliases.put("Home",       "Dashboard");
        aliases.put("Teachers",   "School Management");
        aliases.put("Students",   "School Management");
        aliases.put("Subjects",   "Subject Management");
        aliases.put("Schedules",  "Subject Management");
        aliases.put("Enrollment", "Enrollment Management");
        aliases.put("COR",        navButtons.containsKey("COR Management") ? "COR Management" : "My COR");
        aliases.put("Report Card",navButtons.containsKey("Report Card Management") ? "Report Card Management" : "My Report Card");
        aliases.put("Grades",     "My Report Card");
        aliases.put("Grading",    navButtons.containsKey("Report Card Management") ? "Report Card Management" : "Report Card");
        aliases.put("Account",    navButtons.containsKey("Settings") ? "Settings" : "Personal Information");
        return aliases.getOrDefault(name, name);
    }

    private String[] menuItems(Login user) {
        String role = user.getRole();
        if ("teacher".equalsIgnoreCase(role))
            return new String[]{"Dashboard", "My Classes", "My Subjects", "COR", "Report Card"};
        if ("student".equalsIgnoreCase(role))
            return isEnrollmentOpen()
                ? new String[]{"Dashboard", "Enrollment", "My COR", "My Report Card", "Personal Information"}
                : new String[]{"Dashboard", "My COR", "My Report Card", "Personal Information"};
        return new String[]{"Dashboard", "User Management", "School Management", "Subject Management",
            "Section Management", "Enrollment Management", "COR Management", "Report Card Management", "Settings"};
    }

    // =========================================================
    //  SCROLL / LAYOUT HELPERS
    // =========================================================

    private static JPanel page(String title) {
        JPanel page = new JPanel(new BorderLayout(14, 14));
        page.setBackground(BG);
        page.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        page.add(label(title, 20, Font.BOLD, INK), BorderLayout.NORTH);
        return page;
    }

    private static JScrollPane moduleScroll(Component view) {
        JScrollPane scroll = contentScroll(view);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(BG);
        return scroll;
    }

    private static JScrollPane dialogScroll(Component view) {
        JScrollPane scroll = contentScroll(view);
        scroll.setPreferredSize(new Dimension(520, 460));
        scroll.setBorder(BorderFactory.createLineBorder(BORDER));
        scroll.getViewport().setBackground(Color.WHITE);
        return scroll;
    }

    private static JScrollPane tableScroll(JTable table) {
        JScrollPane scroll = contentScroll(table);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER));
        scroll.getViewport().setBackground(Color.WHITE);
        scroll.getViewport().addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) { fitTableColumns(table); }
        });
        SwingUtilities.invokeLater(() -> fitTableColumns(table));
        return scroll;
    }

    private static JScrollPane contentScroll(Component view) {
        JScrollPane scroll = new JScrollPane(view);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setWheelScrollingEnabled(true);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getVerticalScrollBar().setBlockIncrement(80);
        scroll.getHorizontalScrollBar().setUnitIncrement(16);
        scroll.getHorizontalScrollBar().setBlockIncrement(80);
        scroll.addMouseWheelListener(e -> {
            if (!e.isShiftDown()) return;
            int step = e.getUnitsToScroll() * scroll.getHorizontalScrollBar().getUnitIncrement();
            scroll.getHorizontalScrollBar().setValue(scroll.getHorizontalScrollBar().getValue() + step);
            e.consume();
        });
        return scroll;
    }

    // =========================================================
    //  TABLE STYLING
    // =========================================================

    private static void styleTable(JTable table, TableConfig config) {
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setForeground(INK);
        table.setGridColor(new Color(205, 214, 226));
        table.setSelectionBackground(new Color(190, 218, 252));
        table.setSelectionForeground(INK);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        table.getTableHeader().setBackground(HEADER_BLUE);
        table.getTableHeader().setForeground(INK);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setPreferredSize(new Dimension(1, 34));
        if (table.getTableHeader().getDefaultRenderer() instanceof DefaultTableCellRenderer)
            ((DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        table.setFillsViewportHeight(true);
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;
            public Component getTableCellRendererComponent(JTable t, Object value, boolean selected, boolean focus, int row, int column) {
                Component c = super.getTableCellRendererComponent(t, value, selected, focus, row, column);
                if (!selected) { c.setBackground(row % 2 == 0 ? Color.WHITE : ROW_BLUE); c.setForeground(INK); }
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                setHorizontalAlignment(SwingConstants.CENTER);
                return c;
            }
        });
        applyFullHeaders(table, config);
        fitTableColumns(table);
    }

    private static void applyFullHeaders(JTable table, TableConfig config) {
        if (config == null) return;
        Map<String, String> labels = new LinkedHashMap<>();
        labels.put(config.primaryKey, titleFromColumn(config.primaryKey));
        for (FieldDef f : config.fields) labels.put(f.column, f.label);
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            TableColumn col = table.getColumnModel().getColumn(i);
            Object id = col.getIdentifier();
            String key = id == null ? String.valueOf(col.getHeaderValue()) : id.toString();
            col.setIdentifier(key);
            col.setHeaderValue(labels.getOrDefault(key, key));
        }
    }

    private static void fitTableColumns(JTable table) {
        int totalWidth = 0;
        int[] widths = new int[table.getColumnModel().getColumnCount()];
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            TableColumn col = table.getColumnModel().getColumn(i);
            int width = Math.max(110, textWidth(table.getTableHeader().getFont(), String.valueOf(col.getHeaderValue())) + 28);
            for (int row = 0; row < Math.min(table.getRowCount(), 40); row++) {
                Object value = table.getValueAt(row, i);
                if (value != null) width = Math.max(width, textWidth(table.getFont(), value.toString()) + 28);
            }
            widths[i] = width; totalWidth += width;
        }
        int viewportWidth = table.getParent() == null ? 0 : table.getParent().getWidth();
        if (viewportWidth > totalWidth && widths.length > 0) {
            int extra = viewportWidth - totalWidth, each = extra / widths.length, remainder = extra % widths.length;
            for (int i = 0; i < widths.length; i++) widths[i] += each + (i < remainder ? 1 : 0);
        }
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            TableColumn col = table.getColumnModel().getColumn(i);
            col.setMinWidth(Math.min(widths[i], 160));
            col.setPreferredWidth(widths[i]);
        }
    }

    private static int textWidth(Font font, String text) {
        return new JLabel().getFontMetrics(font).stringWidth(text == null ? "" : text);
    }

    private static String titleFromColumn(String column) {
        String[] parts = column.split("_");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (out.length() > 0) out.append(' ');
            out.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return out.toString();
    }

    // =========================================================
    //  STAT CARDS / CHART
    // =========================================================

    private static JPanel stat(String title, String value) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(18, 18, 18, 18)));
        JLabel icon = label(cardIcon(title), 30, Font.PLAIN, NAVY);
        icon.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 14));
        card.add(icon, BorderLayout.WEST);
        JPanel text = new JPanel(new BorderLayout(0, 4));
        text.setOpaque(false);
        text.add(label(title, 13, Font.BOLD, MUTED), BorderLayout.NORTH);
        text.add(label(value == null || value.isBlank() ? "0" : value, 24, Font.BOLD, NAVY), BorderLayout.CENTER);
        card.add(text, BorderLayout.CENTER);
        return card;
    }

    private static String cardIcon(String title) {
        if (title.contains("Active Sections") || title.contains("Subjects") || title.contains("Taken")) return "\uD83D\uDCD6";
        if (title.contains("Sections") || title.contains("Students")) return "\uD83D\uDC65";
        if (title.contains("Teachers") || title.contains("Profile"))  return "\uD83D\uDC64";
        if (title.contains("Status"))  return "\uD83D\uDCCB";
        if (title.contains("Average") || title.contains("Performance")) return "\uD83D\uDCC8";
        return "\uD83D\uDC64";
    }

    // =========================================================
    //  LOGO HELPERS
    // =========================================================

    private static JLabel logoLabel(int size) { return logoLabel(LOGO, size); }

    private static JPanel logoSlot(String resource, int logoSize, int slotSize, int align) {
        JPanel slot = new JPanel(new FlowLayout(align, 0, 0));
        slot.setOpaque(false);
        slot.setPreferredSize(new Dimension(slotSize, logoSize));
        slot.setMinimumSize(new Dimension(slotSize, logoSize));
        slot.add(logoLabel(resource, logoSize));
        return slot;
    }

    private static JLabel logoLabel(String resource, int size) {
        java.net.URL url = Menu.class.getResource(resource);
        if (url == null) return label("KNHS", Math.max(12, size / 3), Font.BOLD, Color.WHITE);
        Image img = new ImageIcon(url).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH);
        JLabel logo = new JLabel(new ImageIcon(img));
        logo.setPreferredSize(new Dimension(size, size));
        logo.setMinimumSize(new Dimension(size, size));
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        logo.setVerticalAlignment(SwingConstants.CENTER);
        return logo;
    }

    // =========================================================
    //  NAV BUTTON HELPERS
    // =========================================================

    private static JButton navButton(String text) {
        JButton b = new JButton(menuIcon(text) + "  " + text);
        b.setFont(new Font("Arial", Font.BOLD, 13));
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setMaximumSize(new Dimension(196, 42));
        b.setPreferredSize(new Dimension(196, 42));
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setBackground(NAVY); b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.putClientProperty("navText", text);
        b.putClientProperty("active", Boolean.FALSE);
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { if (!Boolean.TRUE.equals(b.getClientProperty("active"))) b.setBackground(ACTIVE_DARK); }
            public void mouseExited(MouseEvent e)  { setNavActive(b, Boolean.TRUE.equals(b.getClientProperty("active"))); }
        });
        return b;
    }

    private static void setNavActive(JButton button, boolean active) {
        button.putClientProperty("active", active);
        button.setBackground(active ? ACTIVE : NAVY);
        button.setForeground(active ? INK : Color.WHITE);
        button.setOpaque(true);
    }

    private static String menuIcon(String text) {
        switch (text) {
            case "Home": return "\uD83C\uDFE0";
            case "Teachers": return "\uD83D\uDC65";
            case "Students": return "\uD83D\uDC64";
            case "Enrollment": return "\uD83D\uDCD6";
            case "Subjects": return "\uD83D\uDCC4";
            case "Grading": case "Grades": return "\u2B50";
            case "Schedules": return "\uD83D\uDCC5";
            case "COR": case "Report Card": return "\uD83D\uDCC4";
            case "Account": return "\uD83D\uDC64";
            case "Logout": return "\u27A1\uFE0F";
            default: return "\u2022";
        }
    }

    // =========================================================
    //  BUTTON / LABEL / FORM HELPERS
    // =========================================================

    private static JButton button(String text, Color color) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.PLAIN, 13));
        b.setBackground(color); b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(9, 14, 9, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addHover(b, color, color.brighter());
        return b;
    }

    private static JButton linkButton(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.PLAIN, 13));
        b.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));
        b.setContentAreaFilled(false); b.setForeground(Color.LIGHT_GRAY);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addHover(b, Color.WHITE, new Color(235, 244, 255));
        return b;
    }

    private static JButton iconButton(javax.swing.Icon icon) {
        JButton b = new JButton(icon);
        b.setPreferredSize(new Dimension(38, 36));
        b.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        b.setBackground(Color.WHITE); b.setContentAreaFilled(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                b.setContentAreaFilled(true); b.setBackground(new Color(235, 244, 255));
                if (b.getIcon() instanceof EyeIcon) b.setIcon(((EyeIcon) b.getIcon()).withColor(ACTIVE));
            }
            public void mouseExited(MouseEvent e) {
                b.setContentAreaFilled(false); b.setBackground(Color.WHITE);
                if (b.getIcon() instanceof EyeIcon) b.setIcon(((EyeIcon) b.getIcon()).withColor(MUTED));
            }
        });
        return b;
    }

    private static void addHover(JComponent c, Color normal, Color hover) {
        c.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { c.setBackground(hover); c.setOpaque(true); }
            public void mouseExited(MouseEvent e)  { c.setBackground(normal); }
        });
    }

    private static JLabel label(String text, int size, int style, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Arial", style, size));
        l.setForeground(color);
        return l;
    }

    private static JLabel formLabel(String text) {
        JLabel l = label(text, 12, Font.PLAIN, Color.DARK_GRAY);
        l.setBorder(BorderFactory.createEmptyBorder(6, 0, 4, 0));
        return l;
    }

    private static void styleInput(JTextField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER), BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        field.setPreferredSize(new Dimension(260, 38));
        field.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(ACTIVE), BorderFactory.createEmptyBorder(8, 10, 8, 10))); }
            public void mouseExited(MouseEvent e)  { field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER), BorderFactory.createEmptyBorder(8, 10, 8, 10))); }
        });
    }

    private static JComboBox<String> combo(String[] options) {
        JComboBox<String> box = new JComboBox<>(options);
        box.setFont(new Font("Arial", Font.BOLD, 13));
        box.setBackground(Color.WHITE);
        box.setBorder(BorderFactory.createLineBorder(BORDER));
        return box;
    }

    private static GridBagConstraints formGbc() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.insets = new Insets(3, 4, 5, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        return gbc;
    }

    private static void addFormRow(JPanel form, GridBagConstraints gbc, String labelText, JComponent input) {
        form.add(formLabel(labelText), gbc); gbc.gridy++;
        form.add(input, gbc);               gbc.gridy++;
    }

    private static String formLabelText(TableConfig config, FieldDef field) {
        if (field.type == FieldType.DOUBLE && (config.table.endsWith("_grades") || field.column.contains("grading")))
            return field.label + " (0 to 100)";
        if (field.type == FieldType.DATE) return field.label + " (yyyy-MM-dd)";
        // For LRN field: always show validation hint, no optional tag
        if ("LRN".equals(field.column)) return field.label + " (12 digits only)";
        // Remove "(Optional)" for admin_permission
        if ("admin_permission".equals(field.column)) return "Admin Permission";
        String[] options = optionsPreview(config.table, field.column);
        if (options.length > 0) return field.label + " (" + String.join(", ", options) + ")";
        if (!field.required) return field.label + " (Optional)";
        return field.label;
    }

    private static String[] optionsPreview(String table, String column) {
        if ("role".equals(column))           return new String[]{"admin", "teacher", "student"};
        if ("account_status".equals(column)) return new String[]{"ACTIVE", "INACTIVE", "PENDING"};
        if ("admin_permission".equals(column)) return new String[]{"PENDING", "AUTHORIZED", "SUPER_ADMIN"};
        if ("gender".equals(column))         return new String[]{"Male", "Female"};
        if ("status".equals(column))         return new String[]{"PENDING", "NOT ENROLLED", "ENROLLED", "ACTIVE", "INACTIVE", "DROPPED", "GRADUATED"};
        if ("grade_level".equals(column) && table.startsWith("jhs_")) return new String[]{"7", "8", "9", "10"};
        if ("grade_level".equals(column) && table.startsWith("shs_")) return new String[]{"11", "12"};
        if ("semester".equals(column))       return new String[]{"1st Semester", "2nd Semester"};
        if ("user_type".equals(column))      return new String[]{"JHS", "SHS"};
        if ("level".equals(column))          return new String[]{"JHS", "SHS", "BOTH"};
        return new String[0];
    }

    private static JPanel smallForm(String[] labels, JComponent[] inputs) {
        JPanel panel = new JPanel(new GridLayout(0, 1, 4, 5));
        panel.setBackground(Color.WHITE);
        for (int i = 0; i < labels.length; i++) {
            panel.add(formLabel(labels[i]));
            if (inputs[i] instanceof JTextField) styleInput((JTextField) inputs[i]);
            panel.add(inputs[i]);
        }
        return panel;
    }

    // =========================================================
    //  TABBED HELPER
    // =========================================================

    private static JPanel tabbed(String title, JPanel first, JPanel second) {
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab(tabName(title, 1), first);
        tabs.addTab(tabName(title, 2), second);
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG);
        panel.add(tabs, BorderLayout.CENTER);
        return panel;
    }

    private static String tabName(String fallback, int index) {
        if ("Students".equals(fallback) || "Enrollment".equals(fallback) ||
            "Grades".equals(fallback)   || "Schedules".equals(fallback))
            return (index == 1 ? "JHS " : "SHS ") + fallback;
        return index == 1 ? fallback + " A" : fallback + " B";
    }

    // =========================================================
    //  RECENT ACTIVITY SQL (uses LRN)
    // =========================================================

    private static String recentActivitySql(String role, Login user) {
        if ("teacher".equals(role))
            return "SELECT s.date_enrolled AS Date, 'Student Assigned' AS Activity, s.LRN AS LRN, " +
                "CONCAT(s.first_name,' ',s.last_name) AS 'Student Name', sub.subj_name AS Subject, " +
                "sec.section_name AS Section, 'View / Grade' AS 'Action Made' " +
                "FROM jhs_students s JOIN jhs_sections sec ON sec.section_id=s.section_id " +
                "JOIN jhs_subjects_offerings o ON o.section_id=s.section_id " +
                "JOIN jhs_subjects sub ON sub.subj_id=o.subj_id WHERE o.teacher_id=" + user.getTeacherId() +
                " UNION ALL " +
                "SELECT s.date_enrolled, 'Student Assigned', s.LRN, CONCAT(s.first_name,' ',s.last_name), " +
                "sub.subj_name, sec.section_name, 'View / Grade' " +
                "FROM shs_students s JOIN shs_sections sec ON sec.section_id=s.section_id " +
                "JOIN shs_subjects_offerings o ON o.section_id=s.section_id " +
                "JOIN shs_subjects sub ON sub.subj_id=o.subj_id WHERE o.teacher_id=" + user.getTeacherId() +
                " ORDER BY Date DESC LIMIT 8";
        String currentLrn = sql(studentLrnForUser(user.getUserId()));
        if ("student".equals(role))
            return "SELECT date_enrolled AS Date, 'Enrollment Update' AS Activity, LRN AS LRN, " +
                "CONCAT(first_name,' ',last_name) AS 'Full Name', grade_level AS 'Grade Level', status AS Status " +
                "FROM jhs_students WHERE LRN='" + currentLrn + "' " +
                "UNION ALL " +
                "SELECT date_enrolled, 'Enrollment Update', LRN, CONCAT(first_name,' ',last_name), grade_level, status " +
                "FROM shs_students WHERE LRN='" + currentLrn + "'";
        return "SELECT date_enrolled AS Date, 'New Enrollment' AS 'Activity Type', LRN AS LRN, " +
            "CONCAT(first_name,' ',last_name) AS 'Full Name', grade_level AS 'Grade Level', status AS Status " +
            "FROM jhs_students UNION ALL " +
            "SELECT date_enrolled, 'New Enrollment', LRN, CONCAT(first_name,' ',last_name), grade_level, status " +
            "FROM shs_students ORDER BY Date DESC LIMIT 8";
    }

    // =========================================================
    //  DB UTILITY METHODS
    // =========================================================

    private static String rowsAsText(String query) {
        StringBuilder out = new StringBuilder();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            ResultSetMetaData md = rs.getMetaData();
            while (rs.next()) {
                for (int i = 1; i <= md.getColumnCount(); i++)
                    out.append(md.getColumnLabel(i)).append(": ").append(rs.getObject(i) == null ? "" : rs.getObject(i)).append('\n');
                out.append('\n');
            }
            if (out.length() == 0) out.append("No profile record found.");
        } catch (SQLException ex) { out.append(ex.getMessage()); }
        out.append("\nMy Activity Log\nRecent account and class activity appears in the dashboard.");
        return out.toString();
    }

    private static String scalar(String sql) {
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? String.valueOf(rs.getObject(1)) : "0";
        } catch (SQLException ex) { return "0"; }
    }

    private static String scalarText(String sql) {
        String value = scalar(sql); return "0".equals(value) ? "N/A" : value;
    }

    private static String averageAll() {
        return scalarText("SELECT ROUND(AVG(avg_grade),2) FROM (SELECT average avg_grade FROM jhs_grades UNION ALL SELECT average FROM shs_grades) x");
    }

    private static String averageTeacher(int teacherId) {
        return scalarText("SELECT ROUND(AVG(g.average),2) FROM jhs_grades g JOIN jhs_subjects_offerings o ON o.subj_id=g.subj_id WHERE o.teacher_id=" + teacherId);
    }

    private static String averageStudentByLrn(String lrn) {
        String s = sql(lrn);
        return scalarText("SELECT ROUND(AVG(avg_grade),2) FROM (" +
            "SELECT g.average avg_grade FROM jhs_grades g JOIN jhs_students s ON s.student_id=g.student_id WHERE s.LRN='" + s + "' " +
            "UNION ALL " +
            "SELECT g.average FROM shs_grades g JOIN shs_students s ON s.student_id=g.student_id WHERE s.LRN='" + s + "') x");
    }

    private static Object value(FieldDef f, String raw) {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty() && !f.required) return null;
        if (f.type == FieldType.INT)    return text.isEmpty() ? null : Integer.parseInt(text.split(" - ", 2)[0].trim());
        if (f.type == FieldType.DOUBLE) return text.isEmpty() ? null : Double.parseDouble(text);
        if (f.type == FieldType.DATE)   return text.isEmpty() ? null : Date.valueOf(text);
        return text;
    }

    private static String[] idOptions(String sql) {
        List<String> values = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) values.add(rs.getInt(1) + " - " + rs.getString(2));
        } catch (SQLException ignored) {}
        return values.toArray(new String[0]);
    }

    private static void validateForeignKeys(TableConfig config, List<String> cols, List<Object> vals) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            for (int i = 0; i < cols.size(); i++) {
                String[] reference = referenceFor(config.table, cols.get(i));
                if (reference == null) continue;
                Object val = vals.get(i);
                FieldDef field = fieldByColumn(config, cols.get(i));
                if (val == null) {
                    if (field == null || field.required) throw new SQLException("Selected record does not exist! Add it first.");
                    continue;
                }
                if (!exists(conn, "SELECT 1 FROM " + reference[0] + " WHERE " + reference[1] + "=?", val))
                    throw new SQLException("Selected record does not exist! Add it first.");
            }
        }
    }

    private static boolean isForeignKeyField(String table, String column) { return referenceFor(table, column) != null; }

    private static String[] referenceFor(String table, String column) {
        if ("jhs_students".equals(table) && "section_id".equals(column))                return new String[]{"jhs_sections", "section_id"};
        if ("shs_students".equals(table) && "section_id".equals(column))                return new String[]{"shs_sections", "section_id"};
        if ("jhs_subjects_offerings".equals(table) && "subj_id".equals(column))         return new String[]{"jhs_subjects", "subj_id"};
        if ("jhs_subjects_offerings".equals(table) && "section_id".equals(column))      return new String[]{"jhs_sections", "section_id"};
        if ("jhs_subjects_offerings".equals(table) && "teacher_id".equals(column))      return new String[]{"teachers", "teacher_id"};
        if ("shs_subjects_offerings".equals(table) && "subj_id".equals(column))         return new String[]{"shs_subjects", "subj_id"};
        if ("shs_subjects_offerings".equals(table) && "section_id".equals(column))      return new String[]{"shs_sections", "section_id"};
        if ("shs_subjects_offerings".equals(table) && "teacher_id".equals(column))      return new String[]{"teachers", "teacher_id"};
        if ("jhs_enrollment".equals(table) && "student_id".equals(column))              return new String[]{"jhs_students", "student_id"};
        if ("shs_enrollment".equals(table) && "student_id".equals(column))              return new String[]{"shs_students", "student_id"};
        if ("jhs_grades".equals(table) && "student_id".equals(column))                 return new String[]{"jhs_students", "student_id"};
        if ("jhs_grades".equals(table) && "subj_id".equals(column))                    return new String[]{"jhs_subjects", "subj_id"};
        if ("shs_grades".equals(table) && "student_id".equals(column))                 return new String[]{"shs_students", "student_id"};
        if ("shs_grades".equals(table) && "offering_id".equals(column))                return new String[]{"shs_subjects_offerings", "offering_id"};
        if ("users".equals(table) && "teacher_id".equals(column))                      return new String[]{"teachers", "teacher_id"};
        return null;
    }

    private static FieldDef fieldByColumn(TableConfig config, String column) {
        for (FieldDef field : config.fields) if (field.column.equals(column)) return field;
        return null;
    }

    private static String[] distinctOrDefault(String sql, String[] fallback) {
        List<String> values = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) { String v = rs.getString(1); if (v != null && !v.isBlank()) values.add(v); }
        } catch (SQLException ignored) {}
        return values.isEmpty() ? fallback : values.toArray(new String[0]);
    }

    private static String[] schoolYears() {
        List<String> values = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT DISTINCT school_year FROM school_years ORDER BY " + (hasColumn(conn, "school_years", "sy_id") ? "sy_id" : "school_year_id") + " DESC")) {
            while (rs.next()) {
                String value = safe(rs.getString(1));
                if (!value.isBlank() && !values.contains(value)) values.add(value);
            }
        } catch (SQLException ignored) {}
        if (!values.isEmpty()) return values.toArray(new String[0]);
        int y = LocalDate.now().getYear();
        return new String[]{(y - 1) + "-" + y, y + "-" + (y + 1), (y + 1) + "-" + (y + 2)};
    }

    private static boolean isEnrollmentOpen() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = hasColumn(conn, "school_years", "is_active")
                ? "SELECT 1 FROM school_years WHERE is_active=1 LIMIT 1"
                : "SELECT 1 FROM school_years LIMIT 1";
            return exists(conn, sql);
        } catch (SQLException ex) {
            return false;
        }
    }

    private static String studentLrnForUser(int userId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(
                 "SELECT LRN FROM jhs_students WHERE student_id=? UNION ALL SELECT LRN FROM shs_students WHERE student_id=? LIMIT 1")) {
            pst.setInt(1, userId);
            pst.setInt(2, userId);
            try (ResultSet rs = pst.executeQuery()) { return rs.next() ? safe(rs.getString(1)) : ""; }
        } catch (SQLException ex) {
            return "";
        }
    }

    private static boolean exists(Connection conn, String sql, Object... values) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            for (int i = 0; i < values.length; i++) pst.setObject(i + 1, values[i]);
            try (ResultSet rs = pst.executeQuery()) { return rs.next(); }
        }
    }

    private static int findUserIdByEmail(Connection conn, String email) throws SQLException {
        try (PreparedStatement pst = conn.prepareStatement("SELECT user_id FROM users WHERE email=?")) {
            pst.setString(1, email);
            try (ResultSet rs = pst.executeQuery()) { return rs.next() ? rs.getInt("user_id") : 0; }
        }
    }

    private static int firstInt(Connection conn, String sql) throws SQLException {
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private static boolean hasColumn(Connection conn, String table, String column) throws SQLException {
        try (ResultSet rs = conn.getMetaData().getColumns(null, null, table, column)) { return rs.next(); }
    }

    private static String[] splitName(String fullName) {
        String[] parts = fullName == null ? new String[0] : fullName.trim().split("\\s+");
        String first  = parts.length > 0 ? parts[0] : "Student";
        String last   = parts.length > 1 ? parts[parts.length - 1] : "Account";
        String middle = parts.length > 2 ? String.join(" ", Arrays.copyOfRange(parts, 1, parts.length - 1)) : "";
        return new String[]{last, first, middle};
    }

    private static void computeJhs(List<Object> vals, List<String> cols) {
        if (!cols.contains("average")) {
            double a = num(vals, cols, "first_grading"), b = num(vals, cols, "second_grading"), c = num(vals, cols, "third_grading");
            double avg = Math.round(((a * .30) + (b * .30) + (c * .40)) * 100.0) / 100.0;
            vals.add(avg); vals.add(avg >= 75 ? "Passed" : "Failed");
            cols.add("average"); cols.add("remarks");
        }
    }

    private static void computeShs(List<Object> vals, List<String> cols) {
        if (!cols.contains("average")) {
            double a = num(vals, cols, "prelim"), b = num(vals, cols, "midterm"), c = num(vals, cols, "finals");
            double avg = Math.round(((a + b + c) / 3.0) * 100.0) / 100.0;
            vals.add(avg); vals.add(avg >= 75 ? "Passed" : "Failed");
            cols.add("average"); cols.add("remarks");
        }
    }

    private static double num(List<Object> vals, List<String> cols, String col) {
        int idx = cols.indexOf(col);
        return idx < 0 || vals.get(idx) == null ? 0 : ((Number) vals.get(idx)).doubleValue();
    }

    private static void bind(PreparedStatement pst, List<Object> values) throws SQLException {
        for (int i = 0; i < values.size(); i++) {
            if (values.get(i) == null) pst.setNull(i + 1, Types.NULL);
            else pst.setObject(i + 1, values.get(i));
        }
    }

    private static double parseDouble(String value) {
        return value == null || value.trim().isEmpty() ? 0 : Double.parseDouble(value.trim());
    }

    private static String sql(String text)  { return text == null ? "" : text.replace("'", "''"); }
    private static String safe(String text) { return text == null ? "" : text; }

    private static boolean passwordMatches(String rawPassword, String storedPassword) {
        if (storedPassword == null) return false;
        return storedPassword.equals(rawPassword) || storedPassword.equals(hashPassword(rawPassword));
    }

    private static String hashPassword(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(hash.length * 2);
            for (byte b : hash) out.append(String.format("%02x", b));
            return out.toString();
        } catch (NoSuchAlgorithmException ex) { throw new IllegalStateException("SHA-256 is not available.", ex); }
    }

    private static String formatDate(Date date) {
        return date == null ? "" : new SimpleDateFormat("MMMM dd, yyyy").format(date);
    }

    private static String titleCase(String text) {
        if (text == null || text.isBlank()) return "";
        return text.substring(0, 1).toUpperCase() + text.substring(1).toLowerCase();
    }

    private static String fullName(String firstName, String middleName, String lastName) {
        String middle = safe(middleName);
        return (safe(firstName) + (middle.isBlank() ? " " : " " + middle + " ") + safe(lastName)).trim();
    }

    private static int s(int value, double scale) { return Math.max(1, (int) Math.round(value * scale)); }

    private static JLabel corLabel(String text, int size, int style) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Serif", style, size));
        label.setForeground(Color.BLACK);
        return label;
    }

    private static Map<String, String> corSettings(Connection conn) throws SQLException {
        Map<String, String> settings = new LinkedHashMap<>();
        settings.put("school_name",    "KATIPUNAN NATIONAL HIGH SCHOOL");
        settings.put("school_address", "KATIPUNAN, CARMEN");
        settings.put("contact_no",     "0917-000-0001");
        settings.put("email",          "info@knhs.edu.ph");
        settings.put("school_head",    "PRINCIPAL IV");
        settings.put("principal_name", "MARIA S. SANTOS, EdD");
        settings.put("issued_date",    "2026-01-01");
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM cor_settings ORDER BY cor_id DESC LIMIT 1")) {
            if (rs.next())
                for (String key : new ArrayList<>(settings.keySet()))
                    settings.put(key, rs.getString(key));
        }
        return settings;
    }

    // =========================================================
    //  SEED REQUIRED USERS
    // =========================================================

    private void seedRequiredUsers() {
        try (Connection conn = DBConnection.getConnection()) {
            boolean hasFullName = hasColumn(conn, "users", "full_name");
            boolean hasContact  = hasColumn(conn, "users", "contact_no");
            boolean hasStatus   = hasColumn(conn, "users", "account_status");
            boolean hasPerm     = hasColumn(conn, "users", "admin_permission");

            // Only seed if NO users exist at all
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM users")) {
                if (rs.next() && rs.getInt(1) > 0) return;
            }

            // Seed the Super Admin only
            createUser(conn, "KNHS Administrator", "admin", "admin123",
                       "admin", "admin@knhs.local", "09170000000",
                       null, "ACTIVE", "SUPER_ADMIN", null);
        } catch (SQLException ignored) {}
    }

    // =========================================================
    //  FONT DEFAULTS
    // =========================================================

    private static void applyFontDefaults() {
        Font font = new Font("Arial", Font.BOLD, 13);
        String[] keys = {"Button.font", "Label.font", "TextField.font", "PasswordField.font",
            "Table.font", "TableHeader.font", "ComboBox.font", "TabbedPane.font",
            "OptionPane.messageFont", "OptionPane.buttonFont"};
        for (String key : keys) UIManager.put(key, font);
    }

    // =========================================================
    //  DIALOG HELPERS
    // =========================================================

    private static void info(Component parent, String message)  { JOptionPane.showMessageDialog(parent, message, "KNHS", JOptionPane.INFORMATION_MESSAGE); }
    private static void warn(Component parent, String message)  { JOptionPane.showMessageDialog(parent, message, "KNHS", JOptionPane.WARNING_MESSAGE); }
    private static void error(Component parent, String message) { JOptionPane.showMessageDialog(parent, message, "KNHS", JOptionPane.ERROR_MESSAGE); }
    private static void confirmExit(Component parent) {
        if (JOptionPane.showConfirmDialog(parent, "Exit KNHS?", "Confirm Exit", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            System.exit(0);
    }

    // =========================================================
    //  INNER CLASSES / ENUMS
    // =========================================================

    private enum FieldType { STRING, INT, DOUBLE, DATE }

    private static final class FieldDef {
        final String column, label;
        final FieldType type;
        final boolean required, calculated;
        FieldDef(String column, String label, FieldType type) { this(column, label, type, true, false); }
        FieldDef(String column, String label, FieldType type, boolean required) { this(column, label, type, required, false); }
        FieldDef(String column, String label, FieldType type, boolean required, boolean calculated) {
            this.column = column; this.label = label; this.type = type;
            this.required = required; this.calculated = calculated;
        }
        static FieldDef calculated(String column, String label, FieldType type) { return new FieldDef(column, label, type, false, true); }
    }

    private static final class TableConfig {
        final String table, primaryKey, title, singular;
        final List<FieldDef> fields;
        TableConfig(String table, String primaryKey, String title, String singular, FieldDef... fields) {
            this.table = table; this.primaryKey = primaryKey;
            this.title = title; this.singular = singular;
            this.fields = Arrays.asList(fields);
        }
        String selectSql(String where) {
            List<String> cols = new ArrayList<>();
            cols.add(primaryKey);
            for (FieldDef f : fields) cols.add(f.column);
            return "SELECT " + String.join(",", cols) + " FROM " + table +
                (where == null || where.isBlank() ? "" : " WHERE " + where);
        }
    }

    private static final class PromptField extends JTextField {
        private static final long serialVersionUID = 1L;
        private final String prompt;
        PromptField(String prompt) { this.prompt = prompt; }
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getText() != null && !getText().isEmpty()) return;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(MUTED); g2.setFont(getFont());
            Insets insets = getInsets();
            int y = (getHeight() - g2.getFontMetrics().getHeight()) / 2 + g2.getFontMetrics().getAscent();
            g2.drawString(prompt, insets.left, y);
            g2.dispose();
        }
    }

    private static final class JTextAreaLike extends javax.swing.JTextArea {
        private static final long serialVersionUID = 1L;
        JTextAreaLike(String text) {
            super(text);
            setEditable(false); setLineWrap(true); setWrapStyleWord(true);
            setFont(new Font("Arial", Font.BOLD, 14));
            setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        }
    }

    private static final class CorData {
        String message, schoolYear, studentName, gradeLevel, section, track, strand, sectionLabel, lrn, contact, principal;
        boolean shs;
        final List<CorSubject> subjects = new ArrayList<>();
        static CorData message(String text) { CorData d = new CorData(); d.message = text; return d; }
    }

    private static final class CorSubject {
        final String subject, teacher, schedule, section, units;
        CorSubject(String subject, String teacher, String schedule, String section, String units) {
            this.subject = subject; this.teacher = teacher; this.schedule = schedule;
            this.section = section; this.units = units;
        }
    }

    private static final class EyeIcon implements javax.swing.Icon {
        private final boolean open; private final Color color;
        EyeIcon(boolean open, Color color) { this.open = open; this.color = color; }
        EyeIcon withColor(Color c) { return new EyeIcon(open, c); }
        public int getIconWidth() { return 20; }
        public int getIconHeight() { return 20; }
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            int cx = x + 10, cy = y + 10;
            g2.drawArc(x + 2, y + 5, 16, 10, 0, 180);
            g2.drawArc(x + 2, y + 5, 16, 10, 180, 180);
            if (open) g2.fillOval(cx - 3, cy - 3, 6, 6);
            else g2.drawLine(x + 4, y + 16, x + 17, y + 3);
            g2.dispose();
        }
    }

    private static final class BarChartPanel extends JPanel {
        private static final long serialVersionUID = 1L;
        private final String role;
        BarChartPanel(String role) {
            this.role = role;
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)));
        }
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(INK); g2.setFont(new Font("Arial", Font.BOLD, 16));
            g2.drawString("admin".equals(role) ? "Enrollment Grade 7-12" : "student".equals(role) ? "My Academic Progress" : "My Class Performance", 24, 34);
            int[] values = chartValues(role);
            int base = getHeight() - 60, max = 1;
            for (int v : values) max = Math.max(max, v);
            int groupWidth = (getWidth() - 120) / Math.max(1, values.length);
            int barWidth = Math.min(100, groupWidth - 40);
            String[] labels = {"JHS", "SHS"};
            for (int i = 0; i < values.length; i++) {
                int h = values[i] * (getHeight() - 120) / max;
                int x = 40 + i * groupWidth, y = base - h;
                g2.setColor(i % 2 == 0 ? ACTIVE : NAVY);
                g2.fillRoundRect(x, y, Math.max(24, barWidth), Math.max(6, h), 10, 10);
                g2.setColor(INK); g2.setFont(new Font("Arial", Font.PLAIN, 12));
                String lbl = "admin".equals(role) && values.length == 2 ? labels[i] + " (" + values[i] + ")" : String.valueOf(values[i]);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(lbl, x + Math.max(0, (barWidth - fm.stringWidth(lbl)) / 2), y - 8);
            }
        }
        private static int[] chartValues(String role) {
            if ("admin".equals(role)) {
                int jhs = 0, shs = 0;
                try (Connection conn = DBConnection.getConnection(); Statement st = conn.createStatement()) {
                    try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM jhs_students")) { if (rs.next()) jhs = Math.max(0, rs.getInt(1)); }
                    try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM shs_students")) { if (rs.next()) shs = Math.max(0, rs.getInt(1)); }
                } catch (SQLException ignored) {}
                return new int[]{jhs, shs};
            }
            List<Integer> values = new ArrayList<>();
            try (Connection conn = DBConnection.getConnection(); Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery("SELECT ROUND(AVG(avg_grade)) FROM (SELECT average avg_grade FROM jhs_grades UNION ALL SELECT average FROM shs_grades) x")) {
                while (rs.next()) values.add(Math.max(0, rs.getInt(1)));
            } catch (SQLException ignored) {}
            if (values.isEmpty()) values.add(0);
            return values.stream().mapToInt(Integer::intValue).toArray();
        }
    }

    // =========================================================
    //  TABLE CONFIGS (student_no removed, LRN only)
    // =========================================================

    private static final Map<String, TableConfig> TABLES = new LinkedHashMap<>();
    static {
        TABLES.put("jhs_students", new TableConfig("jhs_students", "student_id", "JHS Students", "JHS Student",
            new FieldDef("student_no",      "Student No",      FieldType.STRING),
            new FieldDef("LRN",             "LRN",             FieldType.STRING),
            new FieldDef("last_name",       "Last Name",       FieldType.STRING),
            new FieldDef("first_name",      "First Name",      FieldType.STRING),
            new FieldDef("middle_name",     "Middle Name",     FieldType.STRING, false),
            new FieldDef("gender",          "Gender",          FieldType.STRING),
            new FieldDef("birthdate",       "Birthdate",       FieldType.DATE),
            new FieldDef("address",         "Address",         FieldType.STRING),
            new FieldDef("contact_no",      "Contact No",      FieldType.STRING, false),
            new FieldDef("guardian_name",   "Guardian Name",   FieldType.STRING),
            new FieldDef("guardian_contact","Guardian Contact",FieldType.STRING, false),
            new FieldDef("grade_level",     "Grade Level",     FieldType.INT),
            new FieldDef("section_id",      "Section ID",      FieldType.INT),
            new FieldDef("date_enrolled",   "Date Enrolled",   FieldType.DATE),
            new FieldDef("status",          "Status",          FieldType.STRING)));

        TABLES.put("jhs_sections", new TableConfig("jhs_sections", "section_id", "JHS Sections", "JHS Section",
            new FieldDef("section_name", "Section Name", FieldType.STRING),
            new FieldDef("grade_level",  "Grade Level",  FieldType.INT),
            new FieldDef("adviser_name", "Adviser Name", FieldType.STRING, false),
            new FieldDef("room_number",  "Room Number",  FieldType.STRING, false)));

        TABLES.put("jhs_subjects", new TableConfig("jhs_subjects", "subj_id", "JHS Subjects", "JHS Subject",
            new FieldDef("subj_code",   "Subject Code", FieldType.STRING),
            new FieldDef("subj_name",   "Subject Name", FieldType.STRING),
            new FieldDef("grade_level", "Grade Level",  FieldType.INT),
            new FieldDef("description", "Description",  FieldType.STRING, false)));

        TABLES.put("jhs_subjects_offerings", new TableConfig("jhs_subjects_offerings", "offering_id", "JHS Offerings", "JHS Offering",
            new FieldDef("subj_id",     "Subject ID",   FieldType.INT),
            new FieldDef("section_id",  "Section ID",   FieldType.INT),
            new FieldDef("teacher_id",  "Teacher ID",   FieldType.INT),
            new FieldDef("school_year", "School Year",  FieldType.STRING),
            new FieldDef("semester",    "Semester",     FieldType.STRING)));

        TABLES.put("jhs_enrollment", new TableConfig("jhs_enrollment", "enroll_id", "JHS Enrollment", "JHS Enrollment",
            new FieldDef("student_no",      "Student No",      FieldType.STRING),
            new FieldDef("LRN",           "LRN",           FieldType.STRING),
            new FieldDef("school_year",   "School Year",   FieldType.STRING),
            new FieldDef("semester",      "Semester",      FieldType.STRING),
            new FieldDef("date_enrolled", "Date Enrolled", FieldType.DATE),
            new FieldDef("status",        "Status",        FieldType.STRING),
            new FieldDef("student_id",    "Student ID",    FieldType.INT),
            new FieldDef("sy_id",         "School Year ID",FieldType.INT)));

        TABLES.put("jhs_grades", new TableConfig("jhs_grades", "grade_id", "JHS Grades", "JHS Grade",
            new FieldDef("student_id",      "Student ID",      FieldType.INT),
            new FieldDef("subj_id",         "Subject ID",      FieldType.INT),
            new FieldDef("first_grading",   "First Grading",   FieldType.DOUBLE),
            new FieldDef("second_grading",  "Second Grading",  FieldType.DOUBLE),
            new FieldDef("third_grading",   "Third Grading",   FieldType.DOUBLE),
            new FieldDef("fourth_grading",  "Fourth Grading",  FieldType.DOUBLE),
            FieldDef.calculated("average",  "Average",         FieldType.DOUBLE),
            FieldDef.calculated("remarks",  "Remarks",         FieldType.STRING)));

        TABLES.put("shs_students", new TableConfig("shs_students", "student_id", "SHS Students", "SHS Student",
            new FieldDef("student_no",      "Student No",      FieldType.STRING),
            new FieldDef("LRN",             "LRN",             FieldType.STRING),
            new FieldDef("last_name",       "Last Name",       FieldType.STRING),
            new FieldDef("first_name",      "First Name",      FieldType.STRING),
            new FieldDef("middle_name",     "Middle Name",     FieldType.STRING, false),
            new FieldDef("gender",          "Gender",          FieldType.STRING),
            new FieldDef("birthdate",       "Birthdate",       FieldType.DATE),
            new FieldDef("address",         "Address",         FieldType.STRING),
            new FieldDef("contact_no",      "Contact No",      FieldType.STRING, false),
            new FieldDef("guardian_name",   "Guardian Name",   FieldType.STRING),
            new FieldDef("guardian_contact","Guardian Contact",FieldType.STRING, false),
            new FieldDef("grade_level",     "Grade Level",     FieldType.INT),
            new FieldDef("track",           "Track",           FieldType.STRING),
            new FieldDef("strand",          "Strand",          FieldType.STRING),
            new FieldDef("section_id",      "Section ID",      FieldType.INT),
            new FieldDef("date_enrolled",   "Date Enrolled",   FieldType.DATE),
            new FieldDef("status",          "Status",          FieldType.STRING)));

        TABLES.put("shs_sections", new TableConfig("shs_sections", "section_id", "SHS Sections", "SHS Section",
            new FieldDef("section_name", "Section Name", FieldType.STRING),
            new FieldDef("grade_level",  "Grade Level",  FieldType.INT),
            new FieldDef("track",        "Track",        FieldType.STRING),
            new FieldDef("strand",       "Strand",       FieldType.STRING),
            new FieldDef("adviser_name", "Adviser Name", FieldType.STRING, false),
            new FieldDef("room_number",  "Room Number",  FieldType.STRING, false)));

        TABLES.put("shs_subjects", new TableConfig("shs_subjects", "subj_id", "SHS Subjects", "SHS Subject",
            new FieldDef("subj_code", "Subject Code", FieldType.STRING),
            new FieldDef("subj_name", "Subject Name", FieldType.STRING),
            new FieldDef("track",     "Track",        FieldType.STRING),
            new FieldDef("strand",    "Strand",       FieldType.STRING),
            new FieldDef("semester",  "Semester",     FieldType.STRING),
            new FieldDef("units",     "Units",        FieldType.INT)));

        TABLES.put("shs_subjects_offerings", new TableConfig("shs_subjects_offerings", "offering_id", "SHS Offerings", "SHS Offering",
            new FieldDef("subj_id",     "Subject ID",  FieldType.INT),
            new FieldDef("section_id",  "Section ID",  FieldType.INT),
            new FieldDef("teacher_id",  "Teacher ID",  FieldType.INT),
            new FieldDef("school_year", "School Year", FieldType.STRING),
            new FieldDef("semester",    "Semester",    FieldType.STRING)));

        TABLES.put("shs_enrollment", new TableConfig("shs_enrollment", "enroll_id", "SHS Enrollment", "SHS Enrollment",
            new FieldDef("student_no",      "Student No",      FieldType.STRING),
            new FieldDef("LRN",           "LRN",           FieldType.STRING),
            new FieldDef("school_year",   "School Year",   FieldType.STRING),
            new FieldDef("semester",      "Semester",      FieldType.STRING),
            new FieldDef("track",         "Track",         FieldType.STRING),
            new FieldDef("strand",        "Strand",        FieldType.STRING),
            new FieldDef("date_enrolled", "Date Enrolled", FieldType.DATE),
            new FieldDef("status",        "Status",        FieldType.STRING),
            new FieldDef("student_id",    "Student ID",    FieldType.INT),
            new FieldDef("sy_id",         "School Year ID",FieldType.INT)));

        TABLES.put("shs_grades", new TableConfig("shs_grades", "grade_id", "SHS Grades", "SHS Grade",
            new FieldDef("student_id",  "Student ID",  FieldType.INT),
            new FieldDef("offering_id", "Offering ID", FieldType.INT),
            new FieldDef("prelim",      "Prelim",      FieldType.DOUBLE),
            new FieldDef("midterm",     "Midterm",     FieldType.DOUBLE),
            new FieldDef("finals",      "Finals",      FieldType.DOUBLE),
            FieldDef.calculated("average", "Average",  FieldType.DOUBLE),
            FieldDef.calculated("remarks", "Remarks",  FieldType.STRING)));

        TABLES.put("teachers", new TableConfig("teachers", "teacher_id", "Teachers", "Teacher",
            new FieldDef("name",          "Full Name",    FieldType.STRING),
            new FieldDef("subject_taught","Subject Taught",FieldType.STRING),
            new FieldDef("contact_no",    "Contact No",   FieldType.STRING),
            new FieldDef("email",         "Email",        FieldType.STRING, false),
            new FieldDef("level",         "Level",        FieldType.STRING)));

        TABLES.put("users", new TableConfig("users", "user_id", "Users", "User",
            new FieldDef("full_name",        "Full Name",        FieldType.STRING),
            new FieldDef("username",         "Username",         FieldType.STRING),
            new FieldDef("password",         "Password",         FieldType.STRING),
            new FieldDef("role",             "Role",             FieldType.STRING),
            new FieldDef("email",            "Email",            FieldType.STRING),
            new FieldDef("contact_no",       "Contact No",       FieldType.STRING, false),
            new FieldDef("teacher_id",       "Teacher ID",       FieldType.INT,    false),
            new FieldDef("account_status",   "Account Status",   FieldType.STRING),
            new FieldDef("admin_permission", "Admin Permission", FieldType.STRING, false),
            new FieldDef("user_type",        "User Type",        FieldType.STRING, false)));
    }
}
