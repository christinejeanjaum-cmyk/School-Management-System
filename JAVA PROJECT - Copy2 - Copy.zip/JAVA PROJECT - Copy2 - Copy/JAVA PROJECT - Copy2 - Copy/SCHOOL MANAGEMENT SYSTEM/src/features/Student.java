package features;

import db.DBConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Student {
    public boolean addJhsStudent(String studentNo, String lrn, String lastName, String firstName, String middleName,
                                 String gender, Date birthdate, String address, String contactNo,
                                 String guardianName, String guardianContact, int gradeLevel,
                                 int sectionId, Date dateEnrolled, String status) {
        String sql = "INSERT INTO jhs_students(student_no, LRN, last_name, first_name, middle_name, gender, birthdate, address, contact_no, guardian_name, guardian_contact, grade_level, section_id, date_enrolled, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            bindJhsValues(pst, studentNo, lrn, lastName, firstName, middleName, gender, birthdate, address,
                contactNo, guardianName, guardianContact, gradeLevel, sectionId, dateEnrolled, status);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateJhsStudent(int studentId, String studentNo, String lrn, String lastName, String firstName,
                                    String middleName, String gender, Date birthdate, String address,
                                    String contactNo, String guardianName, String guardianContact,
                                    int gradeLevel, int sectionId, Date dateEnrolled, String status) {
        String sql = "UPDATE jhs_students SET student_no=?, LRN=?, last_name=?, first_name=?, middle_name=?, gender=?, birthdate=?, address=?, contact_no=?, guardian_name=?, guardian_contact=?, grade_level=?, section_id=?, date_enrolled=?, status=? WHERE student_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            bindJhsValues(pst, studentNo, lrn, lastName, firstName, middleName, gender, birthdate, address,
                contactNo, guardianName, guardianContact, gradeLevel, sectionId, dateEnrolled, status);
            pst.setInt(16, studentId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean addShsStudent(String studentNo, String lrn, String lastName, String firstName, String middleName,
                                 String gender, Date birthdate, String address, String contactNo,
                                 String guardianName, String guardianContact, int gradeLevel,
                                 String track, String strand, int sectionId, Date dateEnrolled, String status) {
        String sql = "INSERT INTO shs_students(student_no, LRN, last_name, first_name, middle_name, gender, birthdate, address, contact_no, guardian_name, guardian_contact, grade_level, track, strand, section_id, date_enrolled, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            bindShsValues(pst, studentNo, lrn, lastName, firstName, middleName, gender, birthdate, address,
                contactNo, guardianName, guardianContact, gradeLevel, track, strand, sectionId, dateEnrolled, status);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateShsStudent(int studentId, String studentNo, String lrn, String lastName, String firstName,
                                    String middleName, String gender, Date birthdate, String address,
                                    String contactNo, String guardianName, String guardianContact,
                                    int gradeLevel, String track, String strand, int sectionId,
                                    Date dateEnrolled, String status) {
        String sql = "UPDATE shs_students SET student_no=?, LRN=?, last_name=?, first_name=?, middle_name=?, gender=?, birthdate=?, address=?, contact_no=?, guardian_name=?, guardian_contact=?, grade_level=?, track=?, strand=?, section_id=?, date_enrolled=?, status=? WHERE student_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            bindShsValues(pst, studentNo, lrn, lastName, firstName, middleName, gender, birthdate, address,
                contactNo, guardianName, guardianContact, gradeLevel, track, strand, sectionId, dateEnrolled, status);
            pst.setInt(18, studentId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean deleteStudent(String level, int studentId) {
        String table = "SHS".equalsIgnoreCase(level) ? "shs_students" : "jhs_students";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM " + table + " WHERE student_id=?")) {
            pst.setInt(1, studentId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    private void bindJhsValues(PreparedStatement pst, String studentNo, String lrn, String lastName, String firstName,
                               String middleName, String gender, Date birthdate, String address,
                               String contactNo, String guardianName, String guardianContact,
                               int gradeLevel, int sectionId, Date dateEnrolled, String status) throws SQLException {
        pst.setString(1, studentNo);
        pst.setString(2, lrn);
        pst.setString(3, lastName);
        pst.setString(4, firstName);
        pst.setString(5, middleName);
        pst.setString(6, gender);
        pst.setDate(7, birthdate);
        pst.setString(8, address);
        pst.setString(9, contactNo);
        pst.setString(10, guardianName);
        pst.setString(11, guardianContact);
        pst.setInt(12, gradeLevel);
        pst.setInt(13, sectionId);
        pst.setDate(14, dateEnrolled);
        pst.setString(15, status);
    }

    private void bindShsValues(PreparedStatement pst, String studentNo, String lrn, String lastName, String firstName,
                               String middleName, String gender, Date birthdate, String address,
                               String contactNo, String guardianName, String guardianContact,
                               int gradeLevel, String track, String strand, int sectionId,
                               Date dateEnrolled, String status) throws SQLException {
        pst.setString(1, studentNo);
        pst.setString(2, lrn);
        pst.setString(3, lastName);
        pst.setString(4, firstName);
        pst.setString(5, middleName);
        pst.setString(6, gender);
        pst.setDate(7, birthdate);
        pst.setString(8, address);
        pst.setString(9, contactNo);
        pst.setString(10, guardianName);
        pst.setString(11, guardianContact);
        pst.setInt(12, gradeLevel);
        pst.setString(13, track);
        pst.setString(14, strand);
        pst.setInt(15, sectionId);
        pst.setDate(16, dateEnrolled);
        pst.setString(17, status);
    }
}
