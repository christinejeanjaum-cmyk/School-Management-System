package features;

import db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Section {
    public boolean addJhsSection(String sectionName, int gradeLevel, String adviserName, String roomNumber) {
        String sql = "INSERT INTO jhs_sections(section_name, grade_level, adviser_name, room_number) VALUES (?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, sectionName);
            pst.setInt(2, gradeLevel);
            pst.setString(3, adviserName);
            pst.setString(4, roomNumber);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateJhsSection(int sectionId, String sectionName, int gradeLevel, String adviserName, String roomNumber) {
        String sql = "UPDATE jhs_sections SET section_name=?, grade_level=?, adviser_name=?, room_number=? WHERE section_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, sectionName);
            pst.setInt(2, gradeLevel);
            pst.setString(3, adviserName);
            pst.setString(4, roomNumber);
            pst.setInt(5, sectionId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean addShsSection(String sectionName, int gradeLevel, String track, String strand, String adviserName, String roomNumber) {
        String sql = "INSERT INTO shs_sections(section_name, grade_level, track, strand, adviser_name, room_number) VALUES (?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, sectionName);
            pst.setInt(2, gradeLevel);
            pst.setString(3, track);
            pst.setString(4, strand);
            pst.setString(5, adviserName);
            pst.setString(6, roomNumber);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateShsSection(int sectionId, String sectionName, int gradeLevel, String track, String strand, String adviserName, String roomNumber) {
        String sql = "UPDATE shs_sections SET section_name=?, grade_level=?, track=?, strand=?, adviser_name=?, room_number=? WHERE section_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, sectionName);
            pst.setInt(2, gradeLevel);
            pst.setString(3, track);
            pst.setString(4, strand);
            pst.setString(5, adviserName);
            pst.setString(6, roomNumber);
            pst.setInt(7, sectionId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean deleteSection(String level, int sectionId) {
        String table = "SHS".equalsIgnoreCase(level) ? "shs_sections" : "jhs_sections";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM " + table + " WHERE section_id=?")) {
            pst.setInt(1, sectionId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }
}
