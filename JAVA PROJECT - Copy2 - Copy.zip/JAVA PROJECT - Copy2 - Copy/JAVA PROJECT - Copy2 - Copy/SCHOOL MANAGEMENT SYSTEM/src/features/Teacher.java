package features;

import db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Teacher {
    public boolean addTeacher(String name, String subjectTaught, String contactNo, String email, String level) {
        String sql = "INSERT INTO teachers(name, subject_taught, contact_no, email, level) VALUES (?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, name);
            pst.setString(2, subjectTaught);
            pst.setString(3, contactNo);
            pst.setString(4, email);
            pst.setString(5, level);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateTeacher(int teacherId, String name, String subjectTaught, String contactNo, String email, String level) {
        String sql = "UPDATE teachers SET name=?, subject_taught=?, contact_no=?, email=?, level=? WHERE teacher_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, name);
            pst.setString(2, subjectTaught);
            pst.setString(3, contactNo);
            pst.setString(4, email);
            pst.setString(5, level);
            pst.setInt(6, teacherId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean deleteTeacher(int teacherId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM teachers WHERE teacher_id=?")) {
            pst.setInt(1, teacherId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }
}
