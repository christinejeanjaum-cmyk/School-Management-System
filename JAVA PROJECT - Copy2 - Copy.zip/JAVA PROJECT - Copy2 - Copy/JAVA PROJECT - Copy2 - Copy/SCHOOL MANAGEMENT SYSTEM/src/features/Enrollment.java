package features;

import db.DBConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Enrollment {
    public boolean addJhsEnrollment(String studentNo, String lrn, String schoolYear, String semester,
                                    Date dateEnrolled, String status, int studentId, int syId) {
        String sql = "INSERT INTO jhs_enrollment(student_no, LRN, school_year, semester, date_enrolled, status, student_id, sy_id) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, studentNo);
            pst.setString(2, lrn);
            pst.setString(3, schoolYear);
            pst.setString(4, semester);
            pst.setDate(5, dateEnrolled);
            pst.setString(6, status);
            pst.setInt(7, studentId);
            pst.setInt(8, syId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateJhsEnrollment(int enrollmentId, String studentNo, String lrn, String schoolYear, String semester,
                                       Date dateEnrolled, String status, int studentId, int syId) {
        String sql = "UPDATE jhs_enrollment SET student_no=?, LRN=?, school_year=?, semester=?, date_enrolled=?, status=?, student_id=?, sy_id=? WHERE enroll_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, studentNo);
            pst.setString(2, lrn);
            pst.setString(3, schoolYear);
            pst.setString(4, semester);
            pst.setDate(5, dateEnrolled);
            pst.setString(6, status);
            pst.setInt(7, studentId);
            pst.setInt(8, syId);
            pst.setInt(9, enrollmentId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean addShsEnrollment(String studentNo, String lrn, String schoolYear, String semester,
                                    Date dateEnrolled, String status, int studentId, int syId,
                                    String track, String strand) {
        String sql = "INSERT INTO shs_enrollment(student_no, LRN, school_year, semester, date_enrolled, status, student_id, sy_id, track, strand) VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, studentNo);
            pst.setString(2, lrn);
            pst.setString(3, schoolYear);
            pst.setString(4, semester);
            pst.setDate(5, dateEnrolled);
            pst.setString(6, status);
            pst.setInt(7, studentId);
            pst.setInt(8, syId);
            pst.setString(9, track);
            pst.setString(10, strand);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateShsEnrollment(int enrollmentId, String studentNo, String lrn, String schoolYear, String semester,
                                       Date dateEnrolled, String status, int studentId, int syId,
                                       String track, String strand) {
        String sql = "UPDATE shs_enrollment SET student_no=?, LRN=?, school_year=?, semester=?, date_enrolled=?, status=?, student_id=?, sy_id=?, track=?, strand=? WHERE enroll_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, studentNo);
            pst.setString(2, lrn);
            pst.setString(3, schoolYear);
            pst.setString(4, semester);
            pst.setDate(5, dateEnrolled);
            pst.setString(6, status);
            pst.setInt(7, studentId);
            pst.setInt(8, syId);
            pst.setString(9, track);
            pst.setString(10, strand);
            pst.setInt(11, enrollmentId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean deleteEnrollment(String level, int enrollmentId) {
        String table = "SHS".equalsIgnoreCase(level) ? "shs_enrollment" : "jhs_enrollment";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM " + table + " WHERE enroll_id=?")) {
            pst.setInt(1, enrollmentId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }
}
