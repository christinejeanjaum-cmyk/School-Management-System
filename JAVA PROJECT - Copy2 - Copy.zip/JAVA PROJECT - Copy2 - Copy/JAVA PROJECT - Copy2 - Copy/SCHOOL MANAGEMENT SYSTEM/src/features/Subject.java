package features;

import db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Subject {
    public boolean addJhsSubject(String subjectCode, String subjectName, int gradeLevel, String description) {
        String sql = "INSERT INTO jhs_subjects(subj_code, subj_name, grade_level, description) VALUES (?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, subjectCode);
            pst.setString(2, subjectName);
            pst.setInt(3, gradeLevel);
            pst.setString(4, description);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateJhsSubject(int subjectId, String subjectCode, String subjectName, int gradeLevel, String description) {
        String sql = "UPDATE jhs_subjects SET subj_code=?, subj_name=?, grade_level=?, description=? WHERE subj_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, subjectCode);
            pst.setString(2, subjectName);
            pst.setInt(3, gradeLevel);
            pst.setString(4, description);
            pst.setInt(5, subjectId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean addShsSubject(String subjectCode, String subjectName, String track, String strand, int semester, int units) {
        String sql = "INSERT INTO shs_subjects(subj_code, subj_name, track, strand, semester, units) VALUES (?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, subjectCode);
            pst.setString(2, subjectName);
            pst.setString(3, track);
            pst.setString(4, strand);
            pst.setInt(5, semester);
            pst.setInt(6, units);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateShsSubject(int subjectId, String subjectCode, String subjectName, String track, String strand, int semester, int units) {
        String sql = "UPDATE shs_subjects SET subj_code=?, subj_name=?, track=?, strand=?, semester=?, units=? WHERE subj_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, subjectCode);
            pst.setString(2, subjectName);
            pst.setString(3, track);
            pst.setString(4, strand);
            pst.setInt(5, semester);
            pst.setInt(6, units);
            pst.setInt(7, subjectId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean deleteSubject(String level, int subjectId) {
        String table = "SHS".equalsIgnoreCase(level) ? "shs_subjects" : "jhs_subjects";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM " + table + " WHERE subj_id=?")) {
            pst.setInt(1, subjectId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }
}
