package features;

import db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Grades {
    public boolean encodeShsGrade(int studentId, int offeringId, double prelim, double midterm, double finals) {
        double average = computeAverage(prelim, midterm, finals);
        String remarks = average >= 75 ? "Passed" : "Failed";
        String sql = "INSERT INTO shs_grades(student_id, offering_id, prelim, midterm, finals, average, remarks) VALUES (?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, studentId);
            pst.setInt(2, offeringId);
            pst.setDouble(3, prelim);
            pst.setDouble(4, midterm);
            pst.setDouble(5, finals);
            pst.setDouble(6, average);
            pst.setString(7, remarks);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateShsGrade(int gradeId, int studentId, int offeringId, double prelim, double midterm, double finals) {
        double average = computeAverage(prelim, midterm, finals);
        String remarks = average >= 75 ? "Passed" : "Failed";
        String sql = "UPDATE shs_grades SET student_id=?, offering_id=?, prelim=?, midterm=?, finals=?, average=?, remarks=? WHERE grade_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, studentId);
            pst.setInt(2, offeringId);
            pst.setDouble(3, prelim);
            pst.setDouble(4, midterm);
            pst.setDouble(5, finals);
            pst.setDouble(6, average);
            pst.setString(7, remarks);
            pst.setInt(8, gradeId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean encodeJhsGrade(int studentId, int subjectId, double first, double second, double third, double fourth) {
        double average = computeAverage(first, second, third, fourth);
        String remarks = average >= 75 ? "Passed" : "Failed";
        String sql = "INSERT INTO jhs_grades(student_id, subj_id, first_grading, second_grading, third_grading, fourth_grading, average, remarks) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, studentId);
            pst.setInt(2, subjectId);
            pst.setDouble(3, first);
            pst.setDouble(4, second);
            pst.setDouble(5, third);
            pst.setDouble(6, fourth);
            pst.setDouble(7, average);
            pst.setString(8, remarks);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateJhsGrade(int gradeId, int studentId, int subjectId, double first, double second, double third, double fourth) {
        double average = computeAverage(first, second, third, fourth);
        String remarks = average >= 75 ? "Passed" : "Failed";
        String sql = "UPDATE jhs_grades SET student_id=?, subj_id=?, first_grading=?, second_grading=?, third_grading=?, fourth_grading=?, average=?, remarks=? WHERE grade_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, studentId);
            pst.setInt(2, subjectId);
            pst.setDouble(3, first);
            pst.setDouble(4, second);
            pst.setDouble(5, third);
            pst.setDouble(6, fourth);
            pst.setDouble(7, average);
            pst.setString(8, remarks);
            pst.setInt(9, gradeId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean deleteGrade(String level, int gradeId) {
        String table = "SHS".equalsIgnoreCase(level) ? "shs_grades" : "jhs_grades";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM " + table + " WHERE grade_id=?")) {
            pst.setInt(1, gradeId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public double computeAverage(double prelim, double midterm, double finals) {
        return Math.round(((prelim + midterm + finals) / 3.0) * 100.0) / 100.0;
    }

    public double computeAverage(double first, double second, double third, double fourth) {
        return Math.round(((first + second + third + fourth) / 4.0) * 100.0) / 100.0;
    }
}
