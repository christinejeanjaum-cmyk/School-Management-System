package features;

import db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SubjectOffering {
    public boolean addOffering(int subjectId, int sectionId, int teacherId, String schoolYear, int semester) {
        String sql = "INSERT INTO shs_subjects_offerings(subj_id, section_id, teacher_id, school_year, semester) VALUES (?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, subjectId);
            pst.setInt(2, sectionId);
            pst.setInt(3, teacherId);
            pst.setString(4, schoolYear);
            pst.setInt(5, semester);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateOffering(int offeringId, int subjectId, int sectionId, int teacherId, String schoolYear,
                                  int semester) {
        String sql = "UPDATE shs_subjects_offerings SET subj_id=?, section_id=?, teacher_id=?, school_year=?, semester=? WHERE offering_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, subjectId);
            pst.setInt(2, sectionId);
            pst.setInt(3, teacherId);
            pst.setString(4, schoolYear);
            pst.setInt(5, semester);
            pst.setInt(6, offeringId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean deleteOffering(int offeringId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM shs_subjects_offerings WHERE offering_id=?")) {
            pst.setInt(1, offeringId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }
}
