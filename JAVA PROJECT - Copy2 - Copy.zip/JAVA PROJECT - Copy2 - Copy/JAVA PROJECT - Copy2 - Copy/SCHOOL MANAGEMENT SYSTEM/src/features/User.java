package features;

import db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class User {
    public boolean addUser(String fullName, String username, String password, String role, String email,
                           String contactNo, Integer teacherId, String accountStatus) {
        String sql = "INSERT INTO users(full_name, username, password, role, email, contact_no, teacher_id, account_status) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, fullName);
            pst.setString(2, username);
            pst.setString(3, password);
            pst.setString(4, role);
            pst.setString(5, email);
            pst.setString(6, contactNo);
            if (teacherId == null) {
                pst.setNull(7, java.sql.Types.INTEGER);
            } else {
                pst.setInt(7, teacherId);
            }
            pst.setString(8, accountStatus);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean updateUser(int userId, String fullName, String username, String password, String role,
                              String email, String contactNo, Integer teacherId, String accountStatus) {
        String sql = "UPDATE users SET full_name=?, username=?, password=?, role=?, email=?, contact_no=?, teacher_id=?, account_status=? WHERE user_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, fullName);
            pst.setString(2, username);
            pst.setString(3, password);
            pst.setString(4, role);
            pst.setString(5, email);
            pst.setString(6, contactNo);
            if (teacherId == null) {
                pst.setNull(7, java.sql.Types.INTEGER);
            } else {
                pst.setInt(7, teacherId);
            }
            pst.setString(8, accountStatus);
            pst.setInt(9, userId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean deleteUser(int userId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM users WHERE user_id=?")) {
            pst.setInt(1, userId);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }
}
